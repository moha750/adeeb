/* ══ صوتُ «ركضة وطن» ═════════════════════════════════════════════════════
   كلُّ صوتٍ يُركَّبُ في المتصفِّحِ تركيبًا (Web Audio) ولا يُجلَبُ ملفًّا: فلا وزنَ يُضافُ إلى
   الصفحة، ولا طلبَ شبكةٍ تمنعُه سياسةُ الأمان، ولا ترخيصَ صوتٍ يُسألُ عنه.

   المنظومة:
     · ثلاثُ قنوات: المؤثّرات، والموسيقى، والأجواء — ثمّ محدِّدٌ (compressor) يمنعُ التشوّهَ حين
       تجتمعُ الأصوات، وصدًى قصيرٌ مولَّدٌ (convolver) للنغماتِ والتصفيق، وتوزيعٌ يمينًا ويسارًا
       بمسارِ الحدث (StereoPanner).
     · الموسيقى: إيقاعٌ خليجيٌّ أصيلُ التأليفِ هنا (طبلٌ ودُمّ، وتَكّ، وتصفيقُ جماعة، ورِقّ)، وباصّ،
       ولحنٌ مقطوفٌ كالعود على مقامِ الحجاز من «ري». يسرعُ قليلًا مع سرعةِ الجري، ويبطؤ ويُكتَمُ في
       التمهّل، ويُضافُ إليه بساطٌ هوائيٌّ في التحليق، ويلينُ في الليل، ويُختَمُ بقفلةٍ حجازيّةٍ عند
       السقوط. وتنخفضُ الموسيقى لحظةً تحتَ الأصواتِ الكبيرة (ducking) فلا تُطمَس.
     · الأجواء: ريحٌ تتبعُ السرعة وتعصفُ في التحليق، وطنينُ المغناطيس، وحفيفُ ما يمرُّ بجانبك من
       سيّاراتٍ وعوائق، وأبواقُ سيّاراتٍ بعيدةٍ كليالي اليومِ الوطنيّ.
     · المؤثّرات: لكلِّ خاصيّةٍ صوتُها، ودقّاتُ إنذارٍ في ثانيتيها الأخيرتين، والاصطدامُ بحسبِ ما
       صُدِم (حديدٌ أو خرسانةٌ أو قماش)، وصفّارةُ الشرطيّ، وتحطّمُ الدرع، ونغمةُ الرقمِ القياسيّ.

   والسياقُ لا يُفتَحُ إلّا بلمسةِ المستخدم (زرُّ «ابدأ») لأنّ الجوّالَ يمنعُ غيرَ ذلك، وكلُّ نداءٍ
   قبلَها يسقطُ صامتًا بلا خطأ. ولا شيءَ ممّا هنا يمسُّ اللبَّ الحتميّ: الصوتُ يُقرَأُ من فروقِ الحالةِ
   في حلقةِ الرسمِ ولا يُستدعى من داخلِ المحاكاة. */
var SND=(function(){
  var ctx=null, out=null, comp=null, rev=null, busS=null, busM=null, busA=null, musF=null, duck=null,
      noise=null, on=true, musOn=true, ready=false, hasPan=false;
  var LV={master:1.0, sfx:1.0, mus:0.34, amb:0.50};

  try{ if(localStorage.getItem("rw_snd")==="0") on=false;
       if(localStorage.getItem("rw_mus")==="0") musOn=false; }catch(e){}

  function mkNoise(){
    var n=Math.floor(ctx.sampleRate*1.0), b=ctx.createBuffer(1,n,ctx.sampleRate), d=b.getChannelData(0);
    /* ضوضاءٌ ورديّةٌ تقريبًا: أليَنُ من البيضاءِ وأشبهُ بالاحتكاكِ الحقيقيّ */
    var b0=0,b1=0,b2=0;
    for(var i=0;i<n;i++){
      var w=Math.random()*2-1;
      b0=0.99765*b0+w*0.0990460; b1=0.96300*b1+w*0.2965164; b2=0.57000*b2+w*1.0526913;
      d[i]=(b0+b1+b2+w*0.1848)*0.28;
    }
    return b;
  }
  /* صدًى مولَّد: ضوضاءٌ تخبو أُسّيًّا في قناتين غيرِ متطابقتين — غرفةٌ مفتوحةٌ قصيرة */
  function mkIR(sec,decay){
    var n=Math.floor(ctx.sampleRate*sec), b=ctx.createBuffer(2,n,ctx.sampleRate);
    for(var c=0;c<2;c++){ var d=b.getChannelData(c);
      for(var i=0;i<n;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/n,decay)*(i<ctx.sampleRate*0.012?0.3:1); }
    return b;
  }

  function init(){
    if(ready) return true;
    var AC=window.AudioContext||window.webkitAudioContext;
    if(!AC) return false;
    try{
      ctx=new AC();
      comp=ctx.createDynamicsCompressor();
      comp.threshold.value=-16; comp.knee.value=10; comp.ratio.value=5; comp.attack.value=0.004; comp.release.value=0.20;
      out=ctx.createGain(); out.gain.value=on?LV.master:0;
      /* بعدَ المحدِّدِ رفعٌ ثابتٌ يعوّضُ ما خفضَه، فالجوّالُ يسمعُ اللعبةَ بمستوى الألعاب لا أخفت */
      var mk=ctx.createGain(); mk.gain.value=1.35;
      out.connect(comp); comp.connect(mk); mk.connect(ctx.destination);
      rev=ctx.createConvolver(); rev.buffer=mkIR(1.5,3.2);
      var rg=ctx.createGain(); rg.gain.value=0.55; rev.connect(rg); rg.connect(out);
      busS=ctx.createGain(); busS.gain.value=LV.sfx; busS.connect(out);
      duck=ctx.createGain(); duck.gain.value=1;
      musF=ctx.createBiquadFilter(); musF.type="lowpass"; musF.frequency.value=16000; musF.Q.value=0.6;
      busM=ctx.createGain(); busM.gain.value=0;
      busM.connect(musF); musF.connect(duck); duck.connect(out);
      busA=ctx.createGain(); busA.gain.value=LV.amb; busA.connect(out);
      hasPan=!!ctx.createStereoPanner;
      noise=mkNoise(); ready=true;
      ambInit();
    }catch(e){ return false; }
    return true;
  }
  function wake(){ if(ctx&&ctx.state==="suspended") ctx.resume(); }

  /* ── أدواتُ التركيب ── */
  function dst(pan,dest,wet){
    var d=dest||busS, n=d;
    if(pan && hasPan){ var p=ctx.createStereoPanner(); p.pan.value=Math.max(-1,Math.min(1,pan)); p.connect(d); n=p; }
    if(wet){ var s=ctx.createGain(); s.gain.value=wet; s.connect(rev);
      var sp=ctx.createGain(); sp.gain.value=1; sp.connect(n); sp.connect(s); n=sp; }
    return n;
  }
  function env(g,t,a,d,peak){
    g.gain.setValueAtTime(0.0001,t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002,peak),t+a);
    g.gain.exponentialRampToValueAtTime(0.0001,t+a+d);
  }
  /* نغمةٌ بانزلاقِ تردّد: o = {t, pan, dest, wet} اختياريّة */
  function tone(type,f0,f1,a,d,peak,o){
    if(!ready) return; o=o||{};
    var t=o.t||ctx.currentTime, osc=ctx.createOscillator(), g=ctx.createGain();
    osc.type=type; osc.frequency.setValueAtTime(f0,t);
    if(f1!==f0) osc.frequency.exponentialRampToValueAtTime(Math.max(1,f1),t+a+d);
    if(o.det) osc.detune.value=o.det;
    env(g,t,a,d,peak); osc.connect(g); g.connect(dst(o.pan,o.dest,o.wet));
    osc.start(t); osc.stop(t+a+d+0.03);
  }
  function puff(dur,peak,type,f0,f1,q,o){
    if(!ready) return; o=o||{};
    var t=o.t||ctx.currentTime, s=ctx.createBufferSource(), f=ctx.createBiquadFilter(), g=ctx.createGain();
    s.buffer=noise; s.loop=true;
    f.type=type||"lowpass"; f.frequency.setValueAtTime(f0,t);
    if(f1&&f1!==f0) f.frequency.exponentialRampToValueAtTime(Math.max(40,f1),t+dur);
    if(q) f.Q.value=q;
    env(g,t,o.a||0.008,dur,peak);
    s.connect(f); f.connect(g); g.connect(dst(o.pan,o.dest,o.wet));
    s.start(t,Math.random()*0.5); s.stop(t+dur+0.05);
  }
  /* خفضُ الموسيقى لحظةً تحتَ صوتٍ كبير */
  function duckM(depth,hold){
    if(!ready) return; var t=ctx.currentTime, g=duck.gain;
    g.cancelScheduledValues(t); g.setValueAtTime(g.value,t);
    g.linearRampToValueAtTime(depth,t+0.03); g.setTargetAtTime(1,t+(hold||0.25),0.25);
  }

  /* ══ مقامُ الحجاز من «ري» ══ */
  var HZ=[293.66,311.13,369.99,392.00,440.00,466.16,523.25,587.33,622.25,739.99,783.99,880.00];
  function hz(deg,oct){ return HZ[deg]*(oct||1); }

  /* ══ الموسيقى ══════════════════════════════════════════════════════════════
     ستّ عشرةَ خطوةً في المازورة. الطبلُ (دُمّ) والتَّكُّ والتصفيقُ والرِّقُّ نمطٌ خليجيٌّ مؤلَّفٌ هنا،
     واللحنُ جملتانِ سؤالٌ وجواب، يليهما سكوتُ اللحنِ مازورتين والإيقاعُ وحدَه — حتّى لا يُملَّ في
     جولةٍ طويلة. */
  var M={on:false, timer:null, next:0, step:0, bar:0, bpm:104, tk:1, night:0, fly:0, slow:0};
  var DUM=[0,6,10], TAK=[4,12], CLAP=[4,12], RIQ=[2,6,10,14];
  /* اللحن: [خطوة، درجة، طولٌ بالخطوات] على ٣٢ خطوة (مازورتان) */
  var PH_A=[[0,4,2],[2,5,1],[3,4,1],[4,3,2],[6,2,2],[8,3,1],[9,4,1],[10,3,2],[12,2,2],[14,1,2],
            [16,0,4],[20,2,2],[22,3,2],[24,4,6]];
  var PH_B=[[0,7,2],[2,6,1],[3,5,1],[4,4,2],[6,5,1],[7,4,1],[8,3,2],[10,2,2],[12,3,1],[13,2,1],[14,1,2],
            [16,0,6],[24,2,1],[25,3,1],[26,2,1],[27,1,1],[28,0,4]];
  var PH_C=[[0,4,1],[1,5,1],[2,4,1],[3,3,1],[4,4,2],[6,7,2],[8,6,1],[9,5,1],[10,4,2],[12,3,2],[14,2,2],
            [16,3,2],[18,2,1],[19,1,1],[20,0,4],[24,4,2],[26,3,2],[28,2,2],[30,1,2]];
  var SONG=[null,null,PH_A,PH_A,PH_B,PH_B,PH_A,PH_A,PH_C,PH_C,PH_B,PH_B,null,null];  /* لكلِّ مازورةٍ نصفُ جملة */

  function dum(t,v){ tone("sine",96,46,0.004,0.30,0.55*v,{t:t,dest:busM});
    puff(0.035,0.18*v,"lowpass",900,300,0,{t:t,dest:busM}); }
  function tak(t,v){ tone("triangle",430,250,0.002,0.07,0.20*v,{t:t,dest:busM});
    puff(0.045,0.13*v,"bandpass",2400,1600,1.4,{t:t,dest:busM}); }
  function clap(t,v,pan,dest){ for(var i=0;i<3;i++)
      puff(0.07+i*0.03,0.16*v,"bandpass",1500-i*120,1100,1.1,{t:t+i*0.011,dest:dest||busM,wet:0.35,pan:pan}); }
  function riq(t,v){ puff(0.05,0.07*v,"highpass",7000,8000,0.7,{t:t,dest:busM,pan:0.25}); }
  function bass(t,f,len){ tone("triangle",f,f,0.006,len,0.26,{t:t,dest:busM}); tone("sine",f*0.5,f*0.5,0.006,len,0.16,{t:t,dest:busM}); }
  /* القطف: مُذبذِبانِ منشاريّانِ متباعدانِ قليلًا، ومرشِّحٌ يُغلَقُ سريعًا — ضربةُ ريشةٍ على وتر */
  function pluck(t,f,len,v){
    if(!ready) return;
    var g=ctx.createGain(), fl=ctx.createBiquadFilter(), d=Math.min(0.9,0.18+len*0.9);
    fl.type="lowpass"; fl.Q.value=4; fl.frequency.setValueAtTime(3600,t); fl.frequency.exponentialRampToValueAtTime(700,t+0.22);
    env(g,t,0.004,d,0.13*v);
    [0,7].forEach(function(dt){ var o=ctx.createOscillator(); o.type="sawtooth"; o.frequency.setValueAtTime(f*0.985,t);
      o.frequency.exponentialRampToValueAtTime(f,t+0.03); o.detune.value=dt; o.connect(fl); o.start(t); o.stop(t+d+0.05); });
    fl.connect(g); g.connect(dst(0.1,busM,0.30));
  }
  function pad(t,len){  /* بساطُ التحليق: خامسةٌ مفتوحةٌ عاليةٌ تتنفّس */
    if(!ready) return;
    [hz(0,2),hz(4,2),hz(0,4)].forEach(function(f,i){
      var o=ctx.createOscillator(), g=ctx.createGain(); o.type="triangle"; o.frequency.value=f; o.detune.value=(i-1)*6;
      g.gain.setValueAtTime(0.0001,t); g.gain.linearRampToValueAtTime(0.035,t+len*0.4); g.gain.linearRampToValueAtTime(0.0001,t+len);
      o.connect(g); g.connect(dst(i?(i===1?-0.4:0.4):0,busM,0.6)); o.start(t); o.stop(t+len+0.05); });
  }
  function mStep(s,t){
    var b=M.bar, spb=60/(M.bpm*M.tk), sx=spb/4, nv=1-0.45*M.night, fill=(b%8===7);
    if(DUM.indexOf(s)>=0 || (b%2===1 && s===8)) dum(t,1);
    if(TAK.indexOf(s)>=0) tak(t,1); else if(s===14) tak(t,0.45);
    if(CLAP.indexOf(s)>=0 && b>=2) clap(t,nv,-0.15);
    if(s===13 && b%2===1 && b>=2) clap(t,0.55*nv,0.2);
    if(RIQ.indexOf(s)>=0) riq(t,nv); else if(s%2===1) riq(t,0.35*nv);
    if(fill && s>=12) tak(t,0.7);                                     /* قفلةُ المازورةِ الثامنة */
    if(s===0) bass(t,hz(0,0.25),sx*5); else if(s===7) bass(t,hz(0,0.25),sx*2.5); else if(s===10) bass(t,hz(4,0.125),sx*5);
    var ph=SONG[b%SONG.length];
    if(ph){ var base=(b%2)*16;
      for(var i=0;i<ph.length;i++){ var n=ph[i]; if(n[0]-base===s) pluck(t,hz(n[1],1),n[2]*sx,1-0.25*M.night); } }
    if(s===0 && M.fly>0.5) pad(t,spb*4);
  }
  /* الجدولةُ تسبقُ الوقتَ بـ 0.35 ثانية، وتُستدعى من المؤقِّتِ ومن كلِّ إطارٍ معًا: إطارٌ متعثّرٌ في
     الجوّال (جمعُ مهملاتٍ أو بناءُ برنامج) أقصرُ من ذلك لا يُسقِطُ ضربة. وما فاتَ فعلًا (تعثّرٌ أطولُ)
     يُتجاوَزُ ولا يُعزَفُ متأخّرًا متراكمًا. */
  function mTick(){
    if(!ready || !M.on) return;
    if(M.hold){ M.next=ctx.currentTime+0.05; return; }                  /* العدُّ بعدَ التوقّف: الإيقاعُ ينتظر */
    var now=ctx.currentTime, la=now+0.35;
    if(M.next<now-0.05) M.next=now+0.02;
    while(M.next<la){ mStep(M.step,M.next); M.next+=60/(M.bpm*M.tk)/4; M.step=(M.step+1)%16; if(M.step===0) M.bar++; }
  }
  function musStart(){
    if(!ready) return;
    M.on=true; M.step=0; M.bar=0; M.next=ctx.currentTime+0.06;
    var g=busM.gain, t=ctx.currentTime; g.cancelScheduledValues(t); g.setValueAtTime(0.0001,t);
    g.linearRampToValueAtTime(musOn?LV.mus:0,t+0.4);
    if(!M.timer) M.timer=setInterval(mTick,25);
  }
  /* السقوط: يسكتُ الإيقاعُ وتنزلُ قفلةٌ حجازيّةٌ هادئة — صول، فا#، مي♭، ري */
  function musEnd(){
    if(!ready || !M.on) return;
    M.on=false; var t=ctx.currentTime+0.05;
    dum(t,1.1);
    [[3,0],[2,0.22],[1,0.44],[0,0.70]].forEach(function(n){ pluck(t+n[1],hz(n[0],1),n[0]?0.18:0.9,0.9); });
    var g=busM.gain; g.cancelScheduledValues(t+1.6); g.setValueAtTime(g.value,t+1.6); g.linearRampToValueAtTime(0.0001,t+2.4);
  }

  /* ══ الأجواء ══ */
  var A={wind:null, windF:null, hum:null, humO:null, lfo:null, hornT:0, rushT:0};
  function ambInit(){
    var s=ctx.createBufferSource(); s.buffer=noise; s.loop=true;
    A.windF=ctx.createBiquadFilter(); A.windF.type="bandpass"; A.windF.frequency.value=600; A.windF.Q.value=0.7;
    A.wind=ctx.createGain(); A.wind.gain.value=0;
    s.connect(A.windF); A.windF.connect(A.wind); A.wind.connect(busA); s.start();
    /* طنينُ المغناطيس: منشاريٌّ خفيضٌ بمرشِّحٍ وتذبذبٍ في الشدّة */
    A.humO=ctx.createOscillator(); A.humO.type="sawtooth"; A.humO.frequency.value=98;
    var hf=ctx.createBiquadFilter(); hf.type="lowpass"; hf.frequency.value=520;
    A.hum=ctx.createGain(); A.hum.gain.value=0;
    var trem=ctx.createGain(); trem.gain.value=0.5;
    A.lfo=ctx.createOscillator(); A.lfo.frequency.value=7; var lg=ctx.createGain(); lg.gain.value=0.5;
    A.lfo.connect(lg); lg.connect(trem.gain);
    A.humO.connect(hf); hf.connect(trem); trem.connect(A.hum); A.hum.connect(busA);
    A.humO.start(); A.lfo.start();
  }
  function setT(p,v,tc){ var t=ctx.currentTime; p.cancelScheduledValues(t); p.setTargetAtTime(v,t,tc||0.12); }
  /* بوقُ سيّارةٍ بعيد: نغمتانِ مربّعتانِ معًا (هكذا تُصنَعُ أبواقُ السيّارات) خلفَ مرشِّحٍ وصدى */
  function horn(pan){
    var t=ctx.currentTime, n=1+Math.floor(Math.random()*3), fr=0.92+Math.random()*0.16;
    for(var i=0;i<n;i++){ var t0=t+i*0.26, L=i===n-1?0.34:0.16;
      [370*fr,466*fr].forEach(function(f){
        var o=ctx.createOscillator(), fl=ctx.createBiquadFilter(), g=ctx.createGain();
        o.type="square"; o.frequency.value=f; fl.type="lowpass"; fl.frequency.value=1300;
        g.gain.setValueAtTime(0.0001,t0); g.gain.linearRampToValueAtTime(0.018,t0+0.02); g.gain.setValueAtTime(0.018,t0+L); g.gain.linearRampToValueAtTime(0.0001,t0+L+0.05);
        o.connect(fl); fl.connect(g); g.connect(dst(pan,busA,0.8)); o.start(t0); o.stop(t0+L+0.08); }); }
  }

  /* ══ الحالةُ في كلِّ إطار ══ */
  var U={play:false, dt:0, tick:0, flapS:0}, lastStep=0, stepLR=1;
  function update(o){
    if(!ready) return;
    U.dt=o.dt||0;
    var spd=o.spd||0, fly=o.fly||0, slow=o.slow||0, play=!!o.play;
    /* الريح */
    /* الريح: كانت في التحليقِ هسيسًا عريضًا يطمسُ الموسيقى وخفقَ الجناحين — صارت هبوبًا أضيقَ وأخفض */
    setT(A.wind.gain, play ? (0.024+spd*0.0012)*(1+0.6*fly)*(1-0.4*slow) : 0, 0.25);
    setT(A.windF.frequency, 420+spd*12+fly*380, 0.3); A.windF.Q.value=0.7+0.8*fly;
    setT(A.hum.gain, play && o.mag ? 0.045 : 0, 0.15);
    /* الموسيقى: السرعةُ ترفعُ الإيقاعَ قليلًا، والتمهّلُ يبطئُه ويكتمُه */
    M.bpm=104+16*Math.min(1,spd/55); M.fly=fly; M.night=o.night||0;
    var tk=1-0.28*slow; M.tk=tk;
    setT(musF.frequency, 16000-14800*slow, 0.2);
    /* دقّاتُ الإنذار: آخرُ ثانيتين من أيِّ خاصيّة */
    if(play && o.warn){ U.tick-=U.dt; if(U.tick<=0){ U.tick=0.30; tone("sine",1760,1760,0.002,0.05,0.07,{pan:0}); } }
    else U.tick=0;
    /* خفقُ الجناحين في التحليق: «فُوف» خافتةٌ عند كلِّ ضربةٍ إلى أسفل */
    if(play && fly>0.6 && o.flap!=null){ var s=o.flap<0?-1:1;
      if(U.flapS>0 && s<0){ puff(0.26,0.13*fly,"lowpass",620,150,0,{a:0.06}); tone("sine",95,70,0.04,0.2,0.05*fly); }
      U.flapS=s; }
    /* أبواقٌ بعيدة */
    if(play){ A.hornT-=U.dt; if(A.hornT<=0){ A.hornT=9+Math.random()*14; if(Math.random()<0.7) horn(Math.random()*1.6-0.8); } }
    U.play=play;
    mTick();
  }

  return {
    init:function(){ var r=init(); wake(); return r; },
    enabled:function(){ return on; },
    music:function(){ return musOn; },
    toggle:function(){
      on=!on; if(out) out.gain.value=on?LV.master:0;
      try{ localStorage.setItem("rw_snd",on?"1":"0"); }catch(e){}
      return on;
    },
    toggleMusic:function(){
      musOn=!musOn; if(busM && M.on) setT(busM.gain,musOn?LV.mus:0,0.1);
      try{ localStorage.setItem("rw_mus",musOn?"1":"0"); }catch(e){}
      return musOn;
    },
    update:update,
    _dbg:function(){ return {ready:ready, on:on, musOn:musOn, state:ctx&&ctx.state, t:ctx&&+ctx.currentTime.toFixed(2),
      mOn:M.on, bar:M.bar, step:M.step, next:+M.next.toFixed(2), busM:busM&&+busM.gain.value.toFixed(3), duck:duck&&+duck.gain.value.toFixed(2),
      out:out&&out.gain.value, musF:musF&&Math.round(musF.frequency.value), timer:!!M.timer}; },
    runStart:function(){
      if(!ready) return; musStart(); A.hornT=6+Math.random()*6;
      var self=this; setTimeout(function(){ if(U.play) self.whistle(-0.1); },900);
    },
    /* وقعُ القدم: ثقلٌ منخفضٌ وحفيفٌ قصير، وصريرٌ مطّاطيٌّ خفيفٌ للبذلة، وتتبادلُ القدمانِ طبقتَهما */
    step:function(spd){
      if(!ready) return; var t=ctx.currentTime;
      if(t-lastStep<0.09) return; lastStep=t; stepLR=-stepLR;
      var v=0.10+0.05*Math.min(1,(spd||18)/34), f=88*(stepLR>0?1:0.94);
      tone("sine",f,54,0.006,0.09,v,{pan:stepLR*0.12});
      puff(0.055,v*0.55,"lowpass",900,360,0,{pan:stepLR*0.12});
      if(Math.random()<0.35) tone("triangle",620+Math.random()*120,520,0.01,0.05,0.018);
    },
    /* القفزة: نفخةُ البذلةِ و«بوينغ» مطّاطيٌّ صاعد */
    jump:function(){
      tone("triangle",210,560,0.012,0.15,0.20);
      tone("sine",330,700,0.01,0.12,0.06,{det:18});
      puff(0.13,0.10,"bandpass",700,1700,3);
    },
    /* الهبوط: ارتطامٌ ثمّ ارتجاجُ البذلةِ المنفوخة */
    land:function(){
      tone("sine",150,52,0.006,0.24,0.26);
      puff(0.10,0.15,"lowpass",1200,260);
      tone("triangle",320,190,0.03,0.20,0.055);
      tone("sine",210,160,0.02,0.16,0.04,{t:ctx&&ctx.currentTime+0.07});
    },
    /* الانزلاق: البطنُ على الأسفلت — احتكاكٌ يهبطُ وهواءٌ يخرجُ من البذلة */
    slide:function(){ puff(0.42,0.17,"bandpass",1500,320,1.6); puff(0.30,0.05,"highpass",3000,1800,0.7); },
    /* التقاطُ حرف: درجاتُ الحجازِ صاعدةً بموضعِ الحرفِ في الكلمة، ويُسمَعُ من جهتِه */
    letter:function(i,pan){
      var f=hz([0,2,4,7,9][Math.min(4,i||0)],1);
      tone("triangle",f,f*1.02,0.006,0.20,0.16,{pan:pan,wet:0.3});
      tone("sine",f*2,f*2,0.004,0.10,0.05,{pan:pan});
    },
    /* نيلُ خاصيّة: أربعُ نغماتٍ حجازيّةٍ صاعدة وتصفيقة، ثمّ صوتُ الخاصيّةِ نفسِها */
    power:function(k){
      if(!ready) return; var t=ctx.currentTime; duckM(0.55,0.35);
      [0,2,4,7].forEach(function(d,i){ tone("triangle",hz(d,1),hz(d,1),0.006,0.26,0.15,{t:t+i*0.07,wet:0.35}); });
      clap(t+0.30,1.1,0,busS); clap(t+0.30,0.8,0.3,busS);
      if(k===0){ tone("sawtooth",110,440,0.05,0.45,0.06,{t:t+0.05});                          /* درع: همهمةٌ تعلو ثمّ لمعة */
        [587.33,880,1174.66].forEach(function(f,i){ tone("sine",f,f,0.02,0.6,0.05,{t:t+0.18+i*0.03,wet:0.5}); }); }
      else if(k===1){ puff(0.7,0.16,"bandpass",350,3200,1.2,{a:0.25});                    /* تحليق: اندفاعُ هواءٍ يصعد */
        tone("sine",300,900,0.1,0.55,0.07,{wet:0.4}); }
      else if(k===2){ tone("square",80,160,0.01,0.35,0.05);                                /* مغناطيس: شرارةٌ كهربائيّة */
        puff(0.3,0.08,"bandpass",4000,900,6); tone("sine",1318.5,1318.5,0.004,0.3,0.05,{t:t+0.2,wet:0.4}); }
      else { tone("sine",620,150,0.02,0.7,0.10,{wet:0.5});                                  /* تمهّل: الزمنُ يهبط */
        puff(0.6,0.06,"lowpass",2400,300,0,{a:0.1}); }
    },
    /* انتهاءُ خاصيّة: نغمتانِ تهبطان */
    powerEnd:function(){
      if(!ready) return; var t=ctx.currentTime;
      tone("triangle",hz(4,1),hz(4,1),0.005,0.14,0.08,{t:t}); tone("triangle",hz(2,1),hz(1,1),0.005,0.22,0.08,{t:t+0.1});
    },
    /* المصّاص: فرقعةُ «بوب» ثمّ رنينٌ حلوٌ سريعٌ يلمع */
    candy:function(pan){
      if(!ready) return; var t=ctx.currentTime;
      tone("sine",700,1400,0.002,0.05,0.12,{pan:pan});
      [0,0.05,0.10,0.15].forEach(function(dt,k){
        var f=[hz(7,1),hz(9,1),hz(11,1),hz(7,2)][k];
        tone("sine",f,f,0.004,0.18,0.12,{t:t+0.03+dt,pan:pan,wet:0.45}); tone("triangle",f*2,f*2,0.003,0.06,0.025,{t:t+0.03+dt,pan:pan}); });
    },
    /* حفيفُ ما يمرُّ بجانبك: سيّارةٌ أعلى وأطول، وعائقٌ أقصر. والطائرُ يسمعُه من تحتِه */
    pass:function(pan,car,under){
      if(!ready) return;
      var v=(car?0.11:0.05)*(under?0.8:1);
      puff(car?0.42:0.25,v,"bandpass",2200,380,1.3,{a:car?0.10:0.05,pan:pan});
      if(car) tone("sawtooth",150,95,0.08,0.35,0.018,{pan:pan});
    },
    /* الدرعُ يصدُّ صدمة: ارتطامٌ مكتوم، ثمّ زجاجٌ يتكسّرُ شظايا، ثمّ رنّةٌ تصعد */
    shield:function(){
      if(!ready) return; var t=ctx.currentTime; duckM(0.4,0.3);
      puff(0.16,0.22,"lowpass",2200,300);
      for(var i=0;i<7;i++){ var f=2600+Math.random()*3400;
        tone("sine",f,f*0.9,0.001,0.08+Math.random()*0.12,0.05,{t:t+0.02+i*0.022,pan:Math.random()*1.2-0.6,wet:0.4}); }
      puff(0.25,0.10,"highpass",5000,3000,0.8,{t:t+0.01});
      tone("sine",520,1560,0.006,0.30,0.12,{t:t+0.08,wet:0.4});
    },
    /* الاصطدام: بحسبِ ما صُدِم — حديدُ سيّارة، أو خرسانةُ صبّة، أو قماشُ لافتةٍ وعمودُها */
    crash:function(req){
      if(!ready) return; var t=ctx.currentTime; duckM(0.2,0.6);
      tone("sine",120,38,0.005,0.6,0.30);                                           /* الثقلُ المشترك */
      if(req==="block"){ puff(0.30,0.26,"highpass",1800,900,0.8);
        [310,437,588,741].forEach(function(f,i){ tone("square",f,f*0.92,0.002,0.18+i*0.05,0.035,{t:t+i*0.012,wet:0.3}); });
        puff(0.5,0.12,"lowpass",2600,220,0,{t:t+0.04}); }
      else if(req==="high"){ puff(0.12,0.22,"bandpass",1100,500,1.2);
        tone("sine",880,860,0.002,0.9,0.06,{wet:0.5}); tone("sine",1320,1300,0.002,0.6,0.03,{wet:0.5}); }
      else { puff(0.28,0.28,"lowpass",1600,180); tone("triangle",90,45,0.004,0.3,0.14); }
      tone("triangle",420,160,0.02,0.35,0.05,{t:t+0.08});                          /* البذلةُ تنفّسُ هواءها */
      musEnd();
    },
    /* صفّارةُ الشرطيّ: نغمتانِ حادّتانِ بارتعاشٍ سريع (كرةُ الصفّارةِ تدور) — نفختان قصيرتان */
    whistle:function(pan){
      if(!ready) return; var t=ctx.currentTime;
      [0,0.34].forEach(function(dt,j){ var t0=t+dt, L=j?0.32:0.16;
        var g=ctx.createGain(), am=ctx.createGain(), l=ctx.createOscillator(), lg=ctx.createGain();
        l.frequency.value=31; lg.gain.value=0.45; l.connect(lg); lg.connect(am.gain); am.gain.value=0.55;
        g.gain.setValueAtTime(0.0001,t0); g.gain.linearRampToValueAtTime(0.045,t0+0.015); g.gain.setValueAtTime(0.045,t0+L); g.gain.linearRampToValueAtTime(0.0001,t0+L+0.04);
        [2850,3120].forEach(function(f){ var o=ctx.createOscillator(); o.type="sine"; o.frequency.value=f; o.connect(am); o.start(t0); o.stop(t0+L+0.06); });
        am.connect(g); g.connect(dst(pan,busS,0.35)); l.start(t0); l.stop(t0+L+0.06); });
    },
    /* الإمساك: كفٌّ تقعُ على كتفٍ — ضربةٌ خافتةٌ ونغمةٌ هابطة، ثمّ نفخةُ صفّارةٍ واحدة */
    grab:function(){
      puff(0.11,0.13,"lowpass",1400,300);
      tone("triangle",300,150,0.012,0.22,0.11);
    },
    /* شاشةُ النهاية: رقمٌ قياسيٌّ جديد = تصفيقُ جماعةٍ وسلّمٌ حجازيٌّ صاعد */
    record:function(){
      if(!ready) return; var t=ctx.currentTime+0.1;
      [0,2,4,7,9,11].forEach(function(d,i){ tone("triangle",hz(d,1),hz(d,1),0.006,0.28,0.13,{t:t+i*0.09,wet:0.4}); });
      for(var i=0;i<6;i++) clap(t+0.1+i*0.16,1.2,(i%2?0.35:-0.35),busS);
    },
    /* لمسةُ زرّ */
    ui:function(){ tone("sine",1200,1500,0.002,0.04,0.05); },
    /* إمساكُ الموسيقى والأجواءِ أثناءَ العدّ، ثمّ إطلاقُها من أوّلِ الضربة */
    hold:function(h){
      if(!ready) return; h=!!h; if(M.hold===h) return; M.hold=h;
      setT(duck.gain,h?0.0001:1,0.05); setT(busA.gain,h?0:LV.amb,0.08);
      if(!h){ M.next=ctx.currentTime+0.04; }
    },
    /* نقرةُ العدّ: ٣ و٢ و١ بنغمةٍ واحدة، ثمّ نغمةُ الانطلاقِ أعلى مع تصفيقة */
    count:function(n){
      if(!ready) return;
      if(n>0){ tone("sine",880,880,0.004,0.16,0.14); tone("triangle",1760,1760,0.003,0.06,0.03); }
      else { var t=ctx.currentTime; tone("sine",1318.5,1318.5,0.004,0.28,0.16,{wet:0.3}); tone("triangle",hz(7,1),hz(7,1),0.004,0.3,0.08,{t:t+0.02}); clap(t+0.02,1,0,busS); }
    },
    /* تبديلُ المسار: حفيفٌ خفيفٌ جدًّا من الجهةِ التي ينتقلُ إليها */
    lane:function(dir){ puff(0.09,0.055,"bandpass",1100,2100,2.2,{pan:(dir||0)*0.35}); }
  };
})();
