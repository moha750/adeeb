/* ══ معالمُ الرياض ═══════════════════════════════════════════════════════
   ثلاثةُ معالمَ حقيقيّةٍ تُبنى هندسيًّا بمقاساتِها المنشورة، ثمّ تُصغَّرُ كلُّها بمعاملٍ
   واحد (SKY_S) فتبقى نِسَبُها فيما بينها كما في الواقع:
     · برجُ المملكة     302.3 م — مسقطٌ لوزيّ عرضُه 76.8، وفتحةٌ علويّةٌ على هيئةِ قطعٍ
                          مكافئٍ مقلوبٍ تبدأ حيث ينتهي الخرسانيُّ (≈180 م) ويعلوها جسرُ السماء
                          (65 م طولًا عند ≈300 م).
     · برجُ الفيصليّة   267 م — مربّعُ المسقط يستدقّ، أعمدةٌ أربعةٌ في أركانِه تلتقي فوق الكرةِ
                          الذهبيّة (عند ≈200 م)، وأربعُ أحزمةِ تقويةٍ على هيئةِ K، ثمّ فانوسٌ
                          وسنٌّ من الفولاذ.
     · برجُ صندوقِ الاستثمارات (KAFD) 385 م — مسقطٌ سداسيّ، وواجهةٌ مُضلَّعةٌ كالبلّور،
                          وتاجٌ مائلُ الأوجه.
   ثمّ أبراجٌ حقيقيّةٌ أخرى من مدنِ المملكة، كلٌّ بصورتِه المرجعيّةِ من ويكيميديا:
     · برجُ الساعةِ في مكّة (601 م) ومعه برجانِ من أبراجِ البيت.
     · برجُ المجدول (244 م، ملتوٍ مخطّطٌ بالكاسرات) وبرجُ رافال (308 م، بيضويٌّ بفلقتين
       وصاريين) وبرجُ التلفزيون (170 م) في الرياض.
     · برجُ «المقرّ» في جدّة (236 م، وجهٌ مائلٌ وقرصٌ في رأسِه).
     · برجُ المياهِ في الخُبَر (90 م تقريبًا).
     · وفي الشاشاتِ العريضةِ وحدَها (خارجَ إطارِ الجوّالِ القائم): برجا العليّا وبرجُ الظهران.
   والمقياسُ واحدٌ للجميع، إلّا برجَ الساعة: 601 م لا تتّسعُ لها السماءُ في الإطار، فيُصغَّرُ
   بمعاملٍ أصغرَ كأنّه أبعدُ — والعينُ لا تفرّقُ في أفقٍ ثابتٍ بين الأصغرِ والأبعد.

   المعاملُ 0.56: السماءُ فوقَ خطِّ الأفقِ في لقطةِ اللعبةِ تتّسعُ لنحوِ 250 م عندَ مسافةِ
   الأبراج، وعرضُ الإطارِ القائمِ ±150 م فقط — فصُغِّرت المعالمُ قليلًا لتتّسعَ لتسعةِ معالم.
   والإحداثيّاتُ داخلَ كلِّ معلمٍ بالمترِ الحقيقيّ — فالطابقُ طابقٌ بمقياسِه. */
var SKY_S=0.56;

/* خاماتُ المعالم: تُرسَمُ على لوحٍ كخاماتِ الأبراجِ الأخرى، وبالمقياسِ نفسِه (TU×TV). */
function skyTex(kind){
  var W=512,H=512,c=document.createElement("canvas"); c.width=W; c.height=H;
  var g=c.getContext("2d"), r,q,lg, rh=H/8, cw=W/8;
  if(kind==="kc"){                  /* زجاجُ المملكة: فضّيٌّ عاكسٌ بوصلاتٍ متلاصقة */
    lg=g.createLinearGradient(0,0,0,H);
    lg.addColorStop(0,"#B4C6D4"); lg.addColorStop(0.5,"#98AFC2"); lg.addColorStop(1,"#A9BDCD");
    g.fillStyle=lg; g.fillRect(0,0,W,H);
    for(r=0;r<8;r++){ g.fillStyle="rgba(70,90,110,.30)"; g.fillRect(0,r*rh+rh-2,W,2);
      g.fillStyle="rgba(235,242,248,.20)"; g.fillRect(0,r*rh,W,1.5);
      for(q=0;q<16;q++){ g.fillStyle="rgba(40,60,80,"+(0.02+0.07*Math.abs(Math.sin(q*1.7+r*0.9))).toFixed(3)+")";
        g.fillRect(q*W/16,r*rh,W/16,rh-2); } }
    for(q=0;q<16;q++){ g.fillStyle="rgba(210,224,236,.22)"; g.fillRect(q*W/16,0,1.5,H); }
  } else if(kind==="fs"){           /* الفيصليّة: كاسراتُ شمسٍ فضّيّةٌ عريضةٌ فوقَ زجاجٍ داكن — في الصورةِ
                                       تغلبُ الخطوطُ الأفقيّةُ على الواجهةِ كلِّها */
    g.fillStyle="#3E4751"; g.fillRect(0,0,W,H);
    for(r=0;r<8;r++){
      lg=g.createLinearGradient(0,r*rh,0,r*rh+rh*0.46);
      lg.addColorStop(0,"#F2F4F5"); lg.addColorStop(1,"#B9C0C6");
      g.fillStyle=lg; g.fillRect(0,r*rh,W,rh*0.46);                          /* الكاسرة */
      g.fillStyle="rgba(20,26,32,.45)"; g.fillRect(0,r*rh+rh*0.46,W,3);      /* ظلُّها على الزجاج */
      for(q=0;q<24;q++){ g.fillStyle="rgba(120,130,140,.45)"; g.fillRect(q*W/24,r*rh+rh*0.5,2,rh*0.5); } }
  } else if(kind==="gold"){         /* الكرة: زجاجٌ ذهبيٌّ بشبكةِ ألواح */
    lg=g.createLinearGradient(0,0,W,H);
    lg.addColorStop(0,"#F2D388"); lg.addColorStop(0.5,"#C9982F"); lg.addColorStop(1,"#E8C470");
    g.fillStyle=lg; g.fillRect(0,0,W,H);
    for(q=0;q<=16;q++){ g.fillStyle="rgba(92,64,16,.55)"; g.fillRect(q*W/16-1.5,0,3,H); g.fillRect(0,q*H/16-1.5,W,3); }
  } else if(kind==="pif"){          /* الصندوق: زجاجٌ رماديٌّ فضّيٌّ بشبكةٍ مثلّثيّةٍ دقيقة (الصورةُ نهارًا) */
    g.fillStyle="#8C99A4"; g.fillRect(0,0,W,H);
    for(r=0;r<8;r++){
      lg=g.createLinearGradient(0,r*rh,0,r*rh+rh);
      lg.addColorStop(0,"#AEB9C2"); lg.addColorStop(0.7,"#7E8B96"); lg.addColorStop(1,"#74818C");
      g.fillStyle=lg; g.fillRect(0,r*rh,W,rh-2);
      g.fillStyle="rgba(214,220,224,.60)"; g.fillRect(0,r*rh+rh-2,W,2); }
    g.strokeStyle="rgba(222,228,232,.55)"; g.lineWidth=2;
    for(q=-8;q<=16;q++){ g.beginPath(); g.moveTo(q*W/8,0); g.lineTo(q*W/8+W/2,H); g.stroke();
      g.beginPath(); g.moveTo(q*W/8,0); g.lineTo(q*W/8-W/2,H); g.stroke(); }
  } else if(kind==="sand"){         /* أبراجُ البيت: حجرٌ رمليٌّ بأضلاعٍ رأسيّةٍ ونوافذَ ضيّقة */
    g.fillStyle="#CDB68E"; g.fillRect(0,0,W,H);
    for(q=0;q<16;q++){ g.fillStyle="rgba(250,240,218,.55)"; g.fillRect(q*W/16,0,5,H);
      g.fillStyle="rgba(110,90,60,.30)"; g.fillRect(q*W/16+5,0,2,H); }
    for(r=0;r<8;r++) for(q=0;q<16;q++){ g.fillStyle="rgba(70,86,84,.65)"; g.fillRect(q*W/16+10,r*rh+rh*0.2,W/16-16,rh*0.55); }
  } else if(kind==="louver"){       /* المجدول: كاسراتٌ بيضاءُ كثيفةٌ على زجاجٍ داكن */
    g.fillStyle="#2F3A44"; g.fillRect(0,0,W,H);
    for(r=0;r<16;r++){ g.fillStyle="#EEF1F3"; g.fillRect(0,r*H/16,W,H/16*0.42);
      g.fillStyle="rgba(10,14,18,.45)"; g.fillRect(0,r*H/16+H/16*0.42,W,2); }
  } else if(kind==="face"){         /* وجهُ الساعة: قرصٌ أبيضُ بعلاماتِ الساعاتِ وعقربين — بلا كتابة */
    g.fillStyle="#E9E2CF"; g.fillRect(0,0,W,H);
    g.fillStyle="#F8F6F0"; g.beginPath(); g.arc(W/2,H/2,W*0.47,0,Math.PI*2); g.fill();
    g.strokeStyle="#B8913A"; g.lineWidth=14; g.beginPath(); g.arc(W/2,H/2,W*0.47,0,Math.PI*2); g.stroke();
    g.fillStyle="#1E2B26";
    for(q=0;q<12;q++){ g.save(); g.translate(W/2,H/2); g.rotate(q*Math.PI/6);
      g.fillRect(-7,-W*0.43,14,W*(q%3===0?0.10:0.06)); g.restore(); }
    g.lineCap="round"; g.strokeStyle="#1E2B26";
    g.lineWidth=16; g.beginPath(); g.moveTo(W/2,H/2); g.lineTo(W/2-W*0.20,H/2-W*0.12); g.stroke();
    g.lineWidth=11; g.beginPath(); g.moveTo(W/2,H/2); g.lineTo(W/2+W*0.24,H/2-W*0.30); g.stroke();
  } else {                          /* فولاذٌ داكن */
    g.fillStyle="#4A5058"; g.fillRect(0,0,W,H);
  }
  if(kind!=="face") grain(g,W,H,2400,0.04);
  var t=new T.CanvasTexture(c);
  if(kind!=="face") t.wrapS=t.wrapT=T.RepeatWrapping; t.colorSpace=T.SRGBColorSpace; t.anisotropy=8;
  return t;
}
FM.kc   =new T.MeshStandardMaterial({map:skyTex("kc"),  roughness:0.16,metalness:0.62,envMapIntensity:1.00,fog:false});
FM.fs   =new T.MeshStandardMaterial({map:skyTex("fs"),  roughness:0.38,metalness:0.40,envMapIntensity:0.55,fog:false});
FM.gold =new T.MeshStandardMaterial({map:skyTex("gold"),roughness:0.20,metalness:0.88,envMapIntensity:1.25,fog:false});
FM.pif  =new T.MeshStandardMaterial({map:skyTex("pif"), roughness:0.20,metalness:0.50,envMapIntensity:0.95,fog:false});
FM.conc =new T.MeshStandardMaterial({color:0xE4E3DE,roughness:0.55,metalness:0.10,envMapIntensity:0.45,fog:false});
FM.sand =new T.MeshStandardMaterial({map:skyTex("sand"),roughness:0.78,metalness:0.04,envMapIntensity:0.35,fog:false});
FM.sandp=new T.MeshStandardMaterial({color:0xC9B08A,roughness:0.82,metalness:0.02,envMapIntensity:0.30,fog:false});
FM.louver=new T.MeshStandardMaterial({map:skyTex("louver"),roughness:0.40,metalness:0.30,envMapIntensity:0.55,fog:false});
/* تنازعُ العمق: دقّةُ مخزنِ العمقِ عند 800 م ≈ 0.38 م (قربُ الكاميرا 0.1 وبعدُها 900)، وكان وجهُ
   الساعةِ فوقَ جدارِها بـ 0.1 م فقط بعد التصغير — فيتبادلان الظهورَ مع كلِّ حركةٍ للكاميرا ويَرمُشُ
   الوجه. فالوجوهُ وحلقاتُها أبعدُ عن الجدار (0.5 م بعد التصغير)، ومعها إزاحةُ عمقٍ في الخامةِ نفسِها. */
FM.face =new T.MeshStandardMaterial({map:skyTex("face"),roughness:0.55,metalness:0.0,emissive:0xFFFFFF,emissiveIntensity:0.18,fog:false,
                                     polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-8});
FM.ring =new T.MeshStandardMaterial({color:0xC9A24A,roughness:0.25,metalness:0.85,envMapIntensity:1.2,fog:false,
                                     polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-8});
FM.dome =new T.MeshStandardMaterial({color:0x2A4A3E,roughness:0.34,metalness:0.55,envMapIntensity:0.80,fog:false});
FM.red  =new T.MeshStandardMaterial({color:0xB8352C,roughness:0.55,metalness:0.10,fog:false});
FM.steel=new T.MeshStandardMaterial({color:0x4B525A,roughness:0.42,metalness:0.55,envMapIntensity:0.60,fog:false});
FM.lamp =new T.MeshStandardMaterial({color:0xFFF4D6,emissive:0xFFE6A8,emissiveIntensity:0.55,roughness:0.4,fog:false});
["kc","fs","gold","pif","conc","steel","lamp","sand","sandp","louver","face","ring","dome","red"].forEach(function(k){ BUCK[k]=[]; });

/* ── الليل: إضاءةُ المعالم ────────────────────────────────────────────────
   خامةُ إضاءةٍ (emissiveMap) بشبكةِ الواجهةِ نفسِها، سوداءُ نهارًا لأنّ لونَ الإضاءةِ
   صفرٌ حتّى يدخلَ الليل (انظرْ DN في اللعبة) — فلا يتغيّرُ النهارُ بكسلًا واحدًا.
   وفي اليومِ الوطنيّ تُضاءُ معالمُ الرياضِ بالأخضر: المملكةُ وبرجُ الصندوقِ وكرةُ
   الفيصليّة وقبّةُ برجِ الساعة. وما سواها نوافذُ مضاءةٌ بلا نظام، كما في أيِّ مدينة.
   مولّدُها منفصلٌ عن R، فلا يتغيّرُ ترتيبُ نسيجِ المدينةِ المبنيِّ بعدَها. */
var _nr=0x5EED1A>>>0;
function NR(){ _nr=(_nr*1664525+1013904223)>>>0; return _nr/4294967296; }
function skyNight(kind){
  var W=256,H=256,c=document.createElement("canvas"); c.width=W; c.height=H;
  var g=c.getContext("2d"), r,q,u, rh=H/8;
  g.fillStyle="#000"; g.fillRect(0,0,W,H);
  function warm(u){ return u<0.25?"#FFE2B0":(u<0.6?"#F2C27E":"#C98E4E"); }
  if(kind==="kc"){                  /* المملكة: غمرٌ أخضرُ وألواحٌ مضاءة */
    g.fillStyle="#0B4A24"; g.fillRect(0,0,W,H);
    for(r=0;r<8;r++) for(q=0;q<16;q++){ u=NR();
      if(u<0.34){ g.fillStyle=u<0.10?"#D8FFE0":"#39B865"; g.fillRect(q*W/16+1,r*rh+1,W/16-2,rh-3); } }
  } else if(kind==="pif"){          /* الصندوق: شبكتُه المثلّثيّةُ خطوطُ ضوءٍ خضراء */
    g.fillStyle="#06200F"; g.fillRect(0,0,W,H);
    g.strokeStyle="#46D27A"; g.lineWidth=2.2;
    for(q=-8;q<=16;q++){ g.beginPath(); g.moveTo(q*W/8,0); g.lineTo(q*W/8+W/2,H); g.stroke();
      g.beginPath(); g.moveTo(q*W/8,0); g.lineTo(q*W/8-W/2,H); g.stroke(); }
    for(r=0;r<8;r++){ g.fillStyle="#2E9E57"; g.fillRect(0,r*rh+rh-1,W,1.5); }
  } else if(kind==="gold"){         /* كرةُ الفيصليّة: خضراءُ متوهّجةٌ بشبكةِ ألواحِها */
    g.fillStyle="#3FD27E"; g.fillRect(0,0,W,H);
    for(q=0;q<=16;q++){ g.fillStyle="#0E5A2C"; g.fillRect(q*W/16-1,0,2,H); g.fillRect(0,q*H/16-1,W,2); }
  } else if(kind==="fs"){           /* الفيصليّة: الزجاجُ بين الكاسراتِ مضاءٌ طوابقَ طوابق */
    for(r=0;r<8;r++){ u=NR(); if(u<0.55){ g.fillStyle=warm(NR()); g.fillRect(0,r*rh+rh*0.5,W,rh*0.42); } }
  } else if(kind==="sand"){         /* أبراجُ البيت: نوافذُها الضيّقة */
    for(r=0;r<8;r++) for(q=0;q<16;q++){ u=NR();
      if(u<0.50){ g.fillStyle=warm(NR()); g.fillRect(q*W/16+5,r*rh+rh*0.2,W/16-8,rh*0.55); } }
  } else if(kind==="louver"){       /* المجدول: خطوطُ الزجاجِ بين الكاسراتِ البيضاء */
    for(r=0;r<16;r++){ u=NR(); if(u<0.6){ g.fillStyle=warm(NR()); g.fillRect(0,r*H/16+H/16*0.46,W,H/16*0.5); } }
  }
  var t=new T.CanvasTexture(c);
  t.wrapS=t.wrapT=T.RepeatWrapping; t.colorSpace=T.SRGBColorSpace; t.anisotropy=4;
  return t;
}
["kc","pif","gold","fs","sand","louver"].forEach(function(k){
  FM[k].emissiveMap=skyNight(k); FM[k].emissive.setRGB(0,0,0);
  dnTag(FM[k],{kc:[0.9,0.9,0.9],pif:[1.1,1.1,1.1],gold:[1.2,1.2,1.2],fs:[0.85,0.85,0.85],
               sand:[0.8,0.8,0.8],louver:[0.75,0.75,0.75]}[k]);
});
dnTag(FM.face,[1.35,1.33,1.25]);            /* وجوهُ الساعةِ تُضاءُ بيضاء */
dnTag(FM.ring,[0.30,0.22,0.06]);
dnTag(FM.dome,[0.04,0.50,0.22]);            /* القبّةُ خضراء */
dnTag(FM.lamp,[2.2,2.0,1.5]);
dnTag(FM.red, [0.95,0.07,0.04]);            /* ضوءُ تحذيرِ الطائرات */
dnTag(FM.conc,[0.10,0.09,0.07]);            /* الخرسانةُ تحت كشّافاتٍ دافئة */
dnTag(FM.sandp,[0.08,0.07,0.05]);

/* ── أدواتُ البناء ──────────────────────────────────────────────────────
   sLoft: شريطٌ ممسوحٌ بين صفوفِ نقاط (كلُّ صفٍّ مضلّعٌ أفقيٌّ عند ارتفاعٍ ما)،
   وإحداثيّاتُ الخامةِ بالمتر: u طولُ القوسِ على الصفّ، وv الارتفاع — كـ bx تمامًا.
   flat: أوجهٌ مستقلّةٌ بحوافَّ حادّة (البلّور)؛ وإلّا فالشريطُ أملسُ ناعمُ الظلّ. */
function sLoft(rows,closed,flat){
  var nr=rows.length, nc=rows[0].length, P=[], U=[], I=[], i, j;
  for(i=0;i<nr;i++){ var row=rows[i], acc=0;
    for(j=0;j<nc+(closed?1:0);j++){ var p=row[j%nc];
      if(j>0){ var o=row[j-1], dx=p[0]-o[0], dz=p[2]-o[2]; acc+=Math.sqrt(dx*dx+dz*dz); }
      P.push(p[0],p[1],p[2]); U.push(acc/TU,p[1]/TV); } }
  var w=nc+(closed?1:0);
  for(i=0;i<nr-1;i++) for(j=0;j<w-1;j++){
    var a=i*w+j, b=a+1, c2=a+w, d=c2+1;
    I.push(a,c2,b, b,c2,d); }
  var g=new T.BufferGeometry();
  g.setAttribute("position",new T.Float32BufferAttribute(P,3));
  g.setAttribute("uv",new T.Float32BufferAttribute(U,2));
  g.setIndex(I);
  if(flat){ g=g.toNonIndexed(); }
  g.computeVertexNormals();
  return g;
}
/* غطاءٌ مستوٍ لمضلّعٍ محدَّبٍ (أو نجميٍّ حولَ مركزِه) */
function sCap(pts,up){
  var cx=0,cy=0,cz=0,n=pts.length,P=[],U=[],i;
  for(i=0;i<n;i++){ cx+=pts[i][0]; cy+=pts[i][1]; cz+=pts[i][2]; } cx/=n; cy/=n; cz/=n;
  for(i=0;i<n;i++){ var a=pts[i], b=pts[(i+1)%n];
    if(up) P.push(cx,cy,cz, b[0],b[1],b[2], a[0],a[1],a[2]);
    else   P.push(cx,cy,cz, a[0],a[1],a[2], b[0],b[1],b[2]);
    U.push(cx/TU,cz/TU, b[0]/TU,b[2]/TU, a[0]/TU,a[2]/TU); }
  var g=new T.BufferGeometry();
  g.setAttribute("position",new T.Float32BufferAttribute(P,3));
  g.setAttribute("uv",new T.Float32BufferAttribute(U,2));
  g.computeVertexNormals(); return g;
}
function sPush(mat,g,M){ g.applyMatrix4(M); BUCK[mat].push(g); }
function sMat(x,z,ry,s){
  var M=new T.Matrix4().makeTranslation(x,0,z);
  M.multiply(new T.Matrix4().makeRotationY(ry));
  M.multiply(new T.Matrix4().makeScale(s,s,s));
  return M;
}
/* أنبوبٌ مستقيمٌ بين نقطتين (عمودٌ أو دعامة) بمقطعٍ مربّع */
function sBeam(mat,a,b,r,M){
  var dx=b[0]-a[0], dy=b[1]-a[1], dz=b[2]-a[2], L=Math.sqrt(dx*dx+dy*dy+dz*dz);
  var g=new T.BoxGeometry(r*2,L,r*2);
  var q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),new T.Vector3(dx/L,dy/L,dz/L));
  g.applyQuaternion(q); g.translate((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2);
  sPush(mat,g,M);
}

/* أنبوبٌ متّصلٌ مربّعُ المقطعِ على مسار — بدلَ صناديقَ متتاليةٍ متداخلةِ الأطراف: الصناديقُ
   المتجاورةُ على خطٍّ شبهِ مستقيمٍ تتراكبُ أوجهُها عند كلِّ مفصلٍ تراكبًا شبهَ مستوٍ، فيتنازعُ
   العمقَ عندها ويلمعُ المفصلُ نقاطًا مع كلِّ حركةٍ للكاميرا (قِيسَ على أعمدةِ الفيصليّة).
   pts: [[x,y,z,r],...]؛ dir="v" لمسارٍ صاعد (مقاطعُ أفقيّة)، و"h" لمسارٍ على x (مقاطعُ رأسيّة). */
function sTube(mat,pts,dir,M){
  var rows=pts.map(function(p){ var x=p[0], y=p[1], z=p[2], r=p[3], w=p[4]||r;
    return dir==="h" ? [[x,y+r,z+w],[x,y+r,z-w],[x,y-r,z-w],[x,y-r,z+w]]
                     : [[x+r,y,z+r],[x-r,y,z+r],[x-r,y,z-r],[x+r,y,z-r]]; });
  sPush(mat,sLoft(rows,true,true),M);
}

/* ── برجُ المملكة ─────────────────────────────────────────────────────────
   المسقطُ لوزةٌ طرفاها إلى الشرقِ والغرب: z = ±B·(1−(x/A)²)^0.75. وعرضُها A يثبتُ حتّى
   150 م ثمّ ينحني إلى الداخلِ انحناءً مكافئًا. والفتحةُ أسطوانةٌ مكافئةٌ تخترقُ العمقَ كلَّه:
   نصفُ عرضِها V = 32.5·√((h−183)/117)، فهي صفرٌ عند 183 م و32.5 عند 300 م — أي 65 م
   هي طولُ الجسرِ بعينِه. فيُبنى البرجُ نصفين متناظرين، كلٌّ منهما من x=V إلى x=A: تحتَ 183
   يلتقيانِ عند x=0 (فالوجهُ الداخليُّ مخفيٌّ)، وفوقَها ينفرجانِ فتظهرُ السماءُ من خلالِه.
   والترتيبُ حولَ المقطعِ بزاويةٍ متزايدة (من +x نحوَ +z) يجعلُ الوجوهَ إلى الخارج؛ والنصفُ
   الأيسرُ مرآةٌ فيُعكَسُ ترتيبُه. */
function kingdom(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), HT=302.3, H0=183, B=17.0, NA=14, i, k;
  function A(h){ return h<=150?38.4:38.4-3.0*Math.pow((h-150)/(HT-150),2); }
  function V(h){ return h<=H0?0:32.5*Math.sqrt(Math.min(1.02,(h-H0)/(300-H0))); }
  function Z(x,a){ var u=x/a; return B*Math.pow(Math.max(0,1-u*u),0.75); }
  var hs=[]; for(i=0;i<=40;i++) hs.push(H0*i/40);
  /* فوقَ بدايةِ الفتحةِ أكثفُ في أسفلِها حيث ينفرجُ القطعُ سريعًا */
  for(i=1;i<=40;i++){ var t=i/40; hs.push(H0+(HT-H0)*t*t*(3-2*t)*0.35+(HT-H0)*t*0.65); }
  [1,-1].forEach(function(sg){
    var north=[], south=[], inner=[];
    hs.forEach(function(h){
      var a=A(h), v=Math.min(V(h),a-3.2), rn=[], rs=[];
      for(k=0;k<=NA;k++){ var x=v+(a-v)*k/NA; rn.push([sg*x,h, Z(x,a)]); rs.push([sg*x,h,-Z(x,a)]); }
      north.push(rn.slice().reverse());           /* من الطرفِ نحوَ الداخل: زاويةٌ متزايدة */
      south.push(rs);                             /* من الداخلِ نحوَ الطرف */
      inner.push([[sg*v,h,Z(v,a)],[sg*v,h,-Z(v,a)]]);
    });
    function fix(rows){ return sg>0?rows:rows.map(function(r){ return r.slice().reverse(); }); }
    sPush("kc",sLoft(fix(north)),M);
    sPush("kc",sLoft(fix(south)),M);
    var inr=[]; for(var j=0;j<hs.length;j++) if(hs[j]>=H0-0.01) inr.push(inner[j]);
    sPush("kc",sLoft(fix(inr)),M);
    /* رأسُ الساق */
    var ht=hs[hs.length-1], at=A(ht), vt=Math.min(V(ht),at-3.2), cp=[], xx;
    for(k=0;k<=NA;k++){ xx=vt+(at-vt)*k/NA; cp.push([sg*xx,ht,-Z(xx,at)]); }
    for(k=NA-1;k>=0;k--){ xx=vt+(at-vt)*k/NA; cp.push([sg*xx,ht,Z(xx,at)]); }
    sPush("steel",sCap(sg>0?cp:cp.slice().reverse(),true),M);
  });
  /* جسرُ السماء: ممرٌّ فولاذيٌّ مغلقٌ منحنٍ قليلًا بين رأسَي الساقين */
  var seg=16, BR=[];
  for(i=0;i<=seg;i++){ var xb=-34.0+68.0*i/seg, sag=1.4*(1-Math.pow(2*i/seg-1,2)); BR.push([xb,298.4-sag,0,1.8,2.3]); }
  sTube("steel",BR,"h",M);
  /* الجناحانِ المتناظرانِ في القاعدة */
  bx("kc",-84,11,0,92,22,46,M,0); bx("kc",84,11,0,92,22,46,M,0);
  bx("roof",-84,22.6,0,93,1.2,47,M,0); bx("roof",84,22.6,0,93,1.2,47,M,0);
}

/* مضلّعُ مقطعٍ مربّعٍ مشطوفِ الأركان حولَ المحور، بزاويةٍ متزايدة (فالأوجهُ إلى الخارج) */
function sSq(h,bx2,bz2,c){ return [[ bx2,h, bz2-c],[ bx2-c,h, bz2],[-bx2+c,h, bz2],[-bx2,h, bz2-c],
                                    [-bx2,h,-bz2+c],[-bx2+c,h,-bz2],[ bx2-c,h,-bz2],[ bx2,h,-bz2+c]]; }
/* جسمٌ مجسَّمٌ بين مقطعين أفقيّين (منشورٌ أو هرمٌ ناقص) مع غطاء */
function sPrism(mat,h0,h1,bx0,bz0,bx1,bz1,c,M,capMat){
  sPush(mat,sLoft([sSq(h0,bx0,bz0,c),sSq(h1,bx1,bz1,c)],true,true),M);
  if(capMat) sPush(capMat,sCap(sSq(h1,bx1,bz1,c),true),M);
}

/* ── برجُ الفيصليّة ──────────────────────────────────────────────────────
   مبنيٌّ من صورةٍ أماميّةٍ بعيدة (ويكيميديا: Al-Faisaliyyah Tower.jpg) قِيسَت عليها النِّسَب:
   · الجسم: هرمٌ ناقصٌ مستقيمُ الأضلاع، عرضُه 66 م عند الأرض و33 م عند سطحِه (198 م)، واجهاتُه
     كاسراتٌ أفقيّةٌ فوقَ زجاجٍ داكن، وفي منتصفِ كلِّ وجهٍ عمودٌ أبيضُ رأسيّ، وأركانُه بيضاء.
   · أحزمةُ التقوية: عارضةٌ أفقيّةٌ بيضاءُ بين الركنين، وتحتَها V ضحلةٌ (6 م) تنزلُ إلى العمودِ الأوسط.
   · أعلى الجسمِ شريطٌ رماديٌّ مُصمَت (الطوابقُ الفنّيّة) عليه منصّةُ المشاهدةِ بسياجِها.
   · فوقَه ينكسرُ الخطّ: أعمدةُ الأركانِ الأربعةُ تصيرُ قضبانًا رفيعةً تلتقي بميلٍ أشدَّ عند 258 م.
     وفي داخلِها الكرةُ الذهبيّةُ جالسةً على المنصّة (قطرُها 24 م — نسبتُها إلى عرضِ الإطارِ في
     الصورةِ 0.74)، أوجهُها مثلّثاتٌ كالقبّةِ الجيوديسيّة، ثمّ خمسُ منصّاتٍ داكنةٍ تصغرُ صعودًا،
     ثمّ رأسٌ هرميٌّ مُصمَت، ثمّ سنٌّ حتّى 267 م. وصاري أوسطُ من الكرةِ إلى القمّة.
   (العرضُ عندَ الأرضِ أقلُّ ممّا تُظهرُه الصورةُ الملتقطةُ من تحت، لأنّ ميلَ الكاميرا يضخّمُه.) */
function faisaliah(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), TOP=198, APEX=258, i, k;
  function half(h){ return h<=TOP ? 33-16.5*h/TOP : 16.5*(APEX-h)/(APEX-TOP); }
  function fz(h){ return half(h)-2.2; }                      /* وجهُ الجسمِ خلفَ أعمدةِ الأركان */
  /* الجسم: كاسراتٌ ثمّ الشريطُ المُصمَتُ أعلاه */
  var rows=[]; for(i=0;i<=10;i++){ var h=186*i/10, b=fz(h); rows.push(sSq(h,b,b,1.0)); }
  sPush("fs",sLoft(rows,true,true),M);
  sPrism("steel",186,TOP,fz(186),fz(186),fz(TOP),fz(TOP),1.0,M,"roof");
  /* أعمدةُ الأركان: عريضةٌ بيضاءُ على الجسم، ثمّ قضبانٌ أرفعُ فوقَه إلى القمّة */
  [[1,1],[-1,1],[-1,-1],[1,-1]].forEach(function(q){
    var cp=[]; for(k=0;k<=12;k++){ var h1=TOP*k/12; cp.push([q[0]*half(h1),h1,q[1]*half(h1),1.35]); }
    sTube("conc",cp,"v",M);
    var up=[]; for(k=0;k<=8;k++){ var h2=TOP+(246-TOP)*k/8; up.push([q[0]*half(h2),h2,q[1]*half(h2),1.1]); }
    sTube("conc",up,"v",M); });
  /* العمودُ الأوسطُ وأحزمةُ الـ V أمامَ الواجهةِ كلُّها لا مغروسةً فيها: كان العمودُ مغروسًا فيلمعُ
     خطُّ التقائه بالواجهةِ نقاطًا (قِيسَ 32 نقطةً على طولِه)، وعلى أعماقٍ متباعدةٍ فيما بينها. */
  for(var f=0;f<4;f++){
    var ang=f*Math.PI/2, ca=Math.cos(ang), sa=Math.sin(ang);
    var P=function(u,h,dd){ var o=fz(h)+dd; return [ca*u+sa*o, h, -sa*u+ca*o]; };
    sBeam("conc",P(0,0,1.1),P(0,186,1.1),1.0,M);
    [186,152,104,54].forEach(function(ht){ var hb=ht-6;
      /* الأطرافُ تقفُ عند الحافّةِ الداخليّةِ لعمودِ الركن: كانت تدخلُه فتتنازعُ أوجهُهما */
      sBeam("conc",P(-half(ht)+2.0,ht,2.2),P(half(ht)-2.0,ht,2.2),0.95,M);   /* العارضة */
      sBeam("conc",P(-half(ht)+2.0,ht,3.4),P(0,hb,3.4),1.0,M);             /* ذراعا الـ V */
      sBeam("conc",P( half(ht)-2.0,ht,3.4),P(0,hb,3.4),1.0,M); });
  }
  /* منصّةُ المشاهدةِ وسياجُها */
  sPrism("steel",TOP,TOP+1.2,half(TOP)+0.4,half(TOP)+0.4,half(TOP)+0.4,half(TOP)+0.4,1.2,M,"conc");
  /* الكرة: وجوهٌ مثلّثة (عشرينيٌّ مقسَّم) — تلمعُ متفاوتةً كالكرةِ الحقيقيّة */
  var gl=new T.IcosahedronGeometry(12,2); gl=gl.index?gl.toNonIndexed():gl; gl.computeVertexNormals();
  gl.translate(0,TOP+1.2+12,0); sPush("gold",gl,M);
  /* الصاري الأوسط، والمنصّاتُ الخمس، والرأسُ المُصمَت، والسنّ */
  var ms=new T.CylinderGeometry(0.9,1.3,APEX-TOP-24,8); ms.translate(0,TOP+24+(APEX-TOP-24)/2,0); sPush("conc",ms,M);
  for(i=0;i<5;i++){ var hd=225+i*4.2, b2=half(hd)-0.9;
    sPrism("steel",hd,hd+2.0,b2,b2,b2,b2,0.6,M,"steel");
    sPrism("conc",hd+2.0,hd+2.5,b2+0.3,b2+0.3,b2+0.3,b2+0.3,0.6,M,null); }
  var tp=new T.ConeGeometry(half(246)*1.414+0.8,APEX-246,4,1); tp.rotateY(Math.PI/4); tp.translate(0,246+(APEX-246)/2,0); sPush("steel",tp,M);
  var nd=new T.ConeGeometry(0.9,10,6); nd.translate(0,APEX+5,0); sPush("steel",nd,M);
  /* قاعدةُ المجمّع */
  bx("fs",0,6,0,88,12,88,M,0); bx("roof",0,12.6,0,89,1.2,89,M,0);
}

/* ── برجُ صندوقِ الاستثماراتِ العامّة (KAFD) ──────────────────────────────
   الصورةُ نهارًا: برجٌ نحيلٌ رماديٌّ فضّيّ، أضلاعُه مطويّةٌ طيّاتٍ قُطريّةً كالبلّور، وتاجُه قطعٌ
   مائلٌ حادٌّ ينتهي برأسٍ مدبّب. فالمسقطُ مضلّعٌ «مطويّ» (60×40) يدورُ ±2.6° بين حزمةٍ وحزمة
   فتنكسرُ الأوجهُ مثلّثاتٍ حادّةَ الحوافّ، ثمّ تاجٌ ترتفعُ رؤوسُه متفاوتةً حتّى 385 م. */
function pifTower(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), HB=334, NB=12, i;
  function plan(h,tw){
    var k=1-0.16*h/HB, a=30*k, b=20*k, c=15*k, H6=[[a,0],[c,b],[-c,b],[-a,0],[-c,-b],[c,-b]], r=[];
    for(var j=0;j<6;j++){ var p=H6[j], q=H6[(j+1)%6];
      r.push([p[0],h,p[1]]); r.push([(p[0]+q[0])/2*0.93,h,(p[1]+q[1])/2*0.93]); }
    var ct=Math.cos(tw), st=Math.sin(tw);
    return r.map(function(p){ return [p[0]*ct-p[2]*st,p[1],p[0]*st+p[2]*ct]; });
  }
  var rows=[]; for(i=0;i<=NB;i++) rows.push(plan(HB*i/NB,(i%2?1:-1)*0.045));
  sPush("pif",sLoft(rows,true,true),M);
  var top=rows[NB], lift=[51,38,25,14,7,10,5,15,21,30,40,48], cr=[];
  for(i=0;i<12;i++) cr.push([top[i][0]*0.92,HB+lift[i],top[i][2]*0.92]);
  sPush("pif",sLoft([top,cr],true,true),M);
  var apex=[top[0][0]*0.40,385,top[0][2]*0.40], P=[], UV=[];
  for(i=0;i<12;i++){ var a2=cr[i], b2=cr[(i+1)%12]; P.push(apex[0],apex[1],apex[2], b2[0],b2[1],b2[2], a2[0],a2[1],a2[2]); }
  for(i=0;i<P.length/3;i++) UV.push(P[i*3]/TU,P[i*3+1]/TV);
  var gc=new T.BufferGeometry(); gc.setAttribute("position",new T.Float32BufferAttribute(P,3));
  gc.setAttribute("uv",new T.Float32BufferAttribute(UV,2)); gc.computeVertexNormals();
  sPush("pif",gc,M);
  bx("pif",0,8,0,90,16,64,M,0); bx("roof",0,16.6,0,91,1.2,65,M,0);
}

/* ── برجُ الساعةِ في مكّة (أبراجُ البيت) ────────────────────────────────────
   من الصورة: جسمٌ رمليٌّ مضلَّعٌ رأسيًّا يرتدُّ ارتدادين، ثمّ مكعّبُ الساعة (أوجهُها 43 م عند
   ≈450 م) بأبراجٍ صغيرةٍ ذهبيّةِ الرؤوسِ في أركانِه، ثمّ طبلةٌ وقبّةٌ خضراءُ داكنة، ثمّ سنٌّ ذهبيٌّ
   يعلوه هلالٌ ذهبيٌّ (قطرُه 21 م) حتّى 601 م. ووجوهُ الساعةِ هنا بلا كتابةٍ — علاماتٌ وعقربان. */
function clockTower(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc), i;
  sPrism("sand",0,236,50,36,50,36,3,M,"roof");
  sPrism("sand",236,332,32,32,31,31,3,M,"roof");
  sPrism("sand",334,418,27,27,27,27,2.5,M,null);
  bx("roof",0,333,0,64,2.4,64,M,0);
  sPrism("sand",418,478,30,30,30,30,2,M,"roof");
  bx("gold",0,418.8,0,63.6,1.6,63.6,M,0); bx("gold",0,477.4,0,63.6,1.6,63.6,M,0);
  for(var f=0;f<4;f++){                                /* الوجوهُ الأربعة وحلقاتُها الذهبيّة */
    var cf=new T.CircleGeometry(21.5,40); cf.translate(0,450,31.2); cf.rotateY(f*Math.PI/2); sPush("face",cf,M);
    var rg=new T.RingGeometry(21.3,23.6,40); rg.translate(0,450,31.3); rg.rotateY(f*Math.PI/2); sPush("ring",rg,M);
    var bk=new T.CylinderGeometry(23.6,23.6,1.3,40); bk.rotateX(Math.PI/2); bk.translate(0,450,30.6); bk.rotateY(f*Math.PI/2); sPush("sand",bk,M);
  }
  [[1,1],[-1,1],[-1,-1],[1,-1]].forEach(function(q){  /* أبراجُ الأركان */
    var t=new T.CylinderGeometry(2.6,2.6,16,8); t.translate(q[0]*27.5,486,q[1]*27.5); sPush("sand",t,M);
    var cn=new T.ConeGeometry(2.8,9,8); cn.translate(q[0]*27.5,498.5,q[1]*27.5); sPush("gold",cn,M); });
  sPrism("sand",478,494,22,22,20,20,4,M,null);
  var dr=new T.CylinderGeometry(15,17,12,16); dr.translate(0,500,0); sPush("sand",dr,M);
  var dm=new T.SphereGeometry(15,20,10,0,Math.PI*2,0,Math.PI/2); dm.scale(1,1.25,1); dm.translate(0,506,0); sPush("dome",dm,M);
  var sp=new T.CylinderGeometry(1.2,4.8,58,10); sp.translate(0,549,0); sPush("gold",sp,M);
  var bl=new T.SphereGeometry(3.2,12,8); bl.translate(0,579,0); sPush("gold",bl,M);
  /* الهلال: قوسٌ من حلقةٍ قرناه إلى أعلى */
  var cr=new T.TorusGeometry(8.6,1.9,8,28,Math.PI*1.3); cr.rotateZ(Math.PI*0.85);   /* فجوةُ القوسِ (مركزُها 1.65π) إلى أعلى */
  cr.scale(1,1.05,1); cr.translate(0,591,0); sPush("gold",cr,M);
}
/* برجٌ من أبراجِ البيتِ المحيطة: رمليٌّ مرتدٌّ برأسٍ هرميٍّ أخضرَ داكنٍ وأركانٍ مدبّبة */
function abrajFlank(x0,z0,ry,sc,H){
  var M=sMat(x0,z0,ry,sc);
  sPrism("sand",0,H*0.78,23,21,23,21,2.5,M,"roof");
  sPrism("sand",H*0.78,H-14,19,17,19,17,2.5,M,null);
  var py=new T.ConeGeometry(19,18,4,1); py.rotateY(Math.PI/4); py.scale(1,1,0.9); py.translate(0,H-5,0); sPush("dome",py,M);
  [[1,1],[-1,1],[-1,-1],[1,-1]].forEach(function(q){ var cn=new T.ConeGeometry(1.8,9,6); cn.translate(q[0]*18,H-9.5,q[1]*16); sPush("gold",cn,M); });
}

/* ── برجُ المجدول (الرياض) ─────────────────────────────────────────────────
   من الصورة: مسقطٌ مستطيلٌ مستديرُ الطرفين يلتوي نحوَ 110° على ارتفاعِه، وواجهتُه كاسراتٌ بيضاءُ
   كثيفة، وحافّتاه ضفيرتانِ بيضاوانِ تلتفّانِ معه (المجدول = المضفور)، ورأسُه مقطوعٌ مائلًا. */
function majdoul(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), H=236, N=26, NP=20, A=23.5, B=10.5, TW=1.95, i, j, rows=[];
  function ring(h,tw,tilt){ var r=[], ct=Math.cos(tw), st=Math.sin(tw);
    for(j=0;j<NP;j++){ var t=j/NP*Math.PI*2, c=Math.cos(t), s2=Math.sin(t);
      var x=A*Math.sign(c)*Math.pow(Math.abs(c),0.45), z=B*Math.sign(s2)*Math.pow(Math.abs(s2),0.45);
      r.push([x*ct-z*st, h+tilt*x/A, x*st+z*ct]); }
    return r; }
  for(i=0;i<=N;i++){ var h=H*i/N; rows.push(ring(h,TW*i/N,i===N?9:0)); }
  sPush("louver",sLoft(rows,true,false),M);
  sPush("roof",sCap(rows[N],true),M);
  [0,NP/2].forEach(function(e){                       /* الضفيرتان عند الطرفين */
    var bp=[]; for(i=0;i<=N;i++){ var p=rows[i][e], o=1.06; bp.push([p[0]*o,p[1],p[2]*o,1.7]); }
    sTube("conc",bp,"v",M); });
}

/* ── برجُ رافال (الرياض) ──────────────────────────────────────────────────
   من الصورة: بيضويٌّ زجاجيٌّ أخضرُ مزرقّ، في منتصفِ وجهِه شقٌّ رأسيٌّ يقسمُه فلقتين، وحافّةُ
   كلِّ فلقةٍ العليا مائلةٌ ترتفعُ نحوَ الخارج فيصيرُ أعلاه على هيئةِ V، وعلى الطرفين صاريان. */
function rafal(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), H0=254, i, j;
  [1,-1].forEach(function(sg){
    var rows=[], NP=18, cx=sg*14.8;
    for(i=0;i<=10;i++){ var r=[];
      for(j=0;j<NP;j++){ var t=j/NP*Math.PI*2, x=cx+13.2*Math.cos(t), z=19*Math.sin(t);
        var h=(i<10)?H0*i/10:H0+16*Math.max(0,sg*x/28.0)+2;
        r.push([x,h,z]); }
      rows.push(r); }
    sPush("glassBlue",sLoft(rows,true,false),M);
    sPush("roof",sCap(rows[10],true),M);
    var ms=new T.CylinderGeometry(1.1,1.5,38,6); ms.translate(sg*25,H0+18+19,0); sPush("steel",ms,M);
  });
  bx("steel",0,H0*0.5,0,5.2,H0,26,M,0);                /* قلبُ الشقّ الداكن */
  bx("stone",0,9,0,70,18,50,M,0);
}

/* ── برجُ التلفزيون (الرياض، 170 م) ────────────────────────────────────────
   من الصورة: جذعٌ خرسانيٌّ أبيضُ مستدقّ، ثمّ غرفةٌ كالكأسِ تتّسعُ إلى أعلى بشريطِ نوافذَ داكن،
   ثمّ صاري الهوائيِّ بحلقاتٍ حمراءَ وبيضاء. */
function tvTower(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S);
  var sh=new T.CylinderGeometry(3.4,6.0,128,14); sh.translate(0,64,0); sPush("conc",sh,M);
  var pts=[[3.4,126],[5,128],[8.6,133],[12.2,139],[13.9,144],[13.9,146],[10,147.6],[7.2,148.6],[7.2,152.4],[5.4,153.6],[3.4,155]].map(function(p){ return new T.Vector2(p[0],p[1]); });
  var pod=new T.LatheGeometry(pts,12); sPush("conc",pod,M);
  var wb=new T.CylinderGeometry(14.8,14.1,3.0,12); wb.translate(0,142,0); sPush("steel",wb,M);   /* 0.9 م فوقَ الغرفة: كان 0.05 فيتنازعان */
  for(var i=0;i<4;i++){ var sg2=new T.CylinderGeometry(1.8-0.1*(i+1),1.8-0.1*i,3.6,6); sg2.translate(0,157.3+i*3.6,0); sPush(i%2?"conc":"red",sg2,M); }
}

/* ── برجُ «المقرّ» في جدّة (236 م) ─────────────────────────────────────────
   من الصورة: زجاجٌ أزرقُ، وجهُه الأيسرُ رأسيٌّ والأيمنُ مائلٌ يلتقيان في رأسٍ ضيّق، وفوقَه قرص. */
function hqJeddah(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S), H=224, zf=15;
  function r(h,xL,xR){ return [[xR,h,zf],[xL,h,zf],[xL,h,-zf],[xR,h,-zf]]; }
  var rows=[r(0,-23,23),r(H,-23,-7)];
  sPush("glassDark",sLoft(rows,true,true),M);
  sPush("roof",sCap(rows[1],true),M);
  var dc=new T.CylinderGeometry(12.5,12.5,2.6,24); dc.translate(-13,H+8,0); sPush("steel",dc,M);
  var st=new T.CylinderGeometry(2.2,2.8,8,8); st.translate(-13,H+3.5,0); sPush("steel",st,M);
  bx("stone",0,8,0,56,16,40,M,0);
}

/* ── برجُ المياهِ في الخُبَر ────────────────────────────────────────────────
   من الصورة: جذعٌ رمليٌّ مستدقّ، يعلوه خزّانٌ متّسعٌ كزهرةٍ مضلّعة، ثمّ رأسٌ صغير. */
function khobarWater(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S);
  var pts=[[6,0],[4.6,30],[3.8,56],[5.5,60],[11,65],[15.5,71],[16.4,75],[14,78.5],[9,80.5],[5.2,82],[4.6,88],[2.4,90],[0.01,91]].map(function(p){ return new T.Vector2(p[0],p[1]); });
  var lt=new T.LatheGeometry(pts,12); sPush("sandp",lt,M);
  var wb=new T.CylinderGeometry(17.3,16.9,2.2,12); wb.translate(0,74.5,0); sPush("steel",wb,M);   /* 0.9 م فوقَ الخزّان */
}

/* ── للشاشاتِ العريضةِ وحدَها ─────────────────────────────────────────────
   برجا العليّا (203 و166 م): زجاجٌ داكنٌ برؤوسٍ مائلةٍ وصارٍ على الأطول. وبرجُ الظهران (200 م). */
function olayaTwin(x0,z0,ry,sc,H,spire){
  var M=sMat(x0,z0,ry,sc||SKY_S), hw=17, hd=13;
  bx("glassDark",0,H*0.5,0,hw*2,H,hd*2,M,x0*0.3);
  var top=[[hw,H,hd],[-hw,H,hd],[-hw,H,-hd],[hw,H,-hd]], up=[[hw,H+16,hd*0.9],[-hw,H+2,hd*0.9],[-hw,H+2,-hd*0.9],[hw,H+16,-hd*0.9]];
  sPush("glassDark",sLoft([top,up],true,true),M); sPush("roof",sCap(up,true),M);
  if(spire){ var s2=new T.ConeGeometry(1.2,34,6); s2.translate(hw-3,H+16+17,0); sPush("steel",s2,M); }
}
function dhahran(x0,z0,ry,sc){
  var M=sMat(x0,z0,ry,sc||SKY_S);
  sPrism("fs",0,168,15,12,15,12,3,M,"roof");
  sPrism("fs",168,186,11,9,11,9,2.5,M,"roof");
  var sp=new T.ConeGeometry(1.0,16,6); sp.translate(0,194,0); sPush("steel",sp,M);
}
