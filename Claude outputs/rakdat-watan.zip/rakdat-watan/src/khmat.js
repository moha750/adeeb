/* ══════════════════════════════════════════════════════════════
   خاماتُ البِذلة المنفوخة — قماشٌ مطّاطيٌّ مطفأ، لا فينيلٌ لامع
   ══════════════════════════════════════════════════════════════
   المرجعُ بِذلةُ نفخٍ من اللايكرا/النايلون: ضوءُها لطخةٌ عريضةٌ
   ليّنةٌ لا بريقٌ حادّ، وفيها ثنياتٌ داكنةٌ حيث تلتقي القِطَع،
   وحافّةٌ شاحبةٌ مضيئةٌ عند حَرْفِ الظلّ (خاصّيّةُ القماشِ لا اللدائن).

   وقيدُ المسألة: كلُّ قطعةٍ من الجسمِ كرةٌ مشوّهة، وإحداثيّاتُ
   الكرةِ (UV) تلتقي عند القطبين، فأيُّ خريطةٍ مبلّطةٍ تُظهِر دوّامةً
   فوقَ الرأسِ وأسفلَ القدم — وهذا ما أفشلَ محاولةَ الخريطةِ السابقة.
   فالحلُّ: لا نستعمل UV إطلاقًا. يُسقَط حقلُ الثنياتِ إسقاطًا
   ثلاثيَّ المستوياتِ (triplanar) من موضعِ الرأسِ في إطارِ القطعةِ
   المحلّيّ، ثمّ يُشتقُّ منه انحرافُ المستقيمِ العموديِّ بمشتقّاتِ
   الشاشة. ثلاثُ قراءاتٍ للخريطةِ وحدها — رخيصٌ على الجوّال.
   والإطارُ المحلّيُّ (لا العالميُّ) لئلّا يسبحَ النسيجُ مع الحركة. */

/* ── حقلُ الثنيات: ضجيجُ قيمٍ دوريٌّ يُبنى مرّةً واحدةً على لوحٍ ٢٥٦ ──
   دوريٌّ بالتمامِ فالتبليطُ بلا حدود، ومُشوَّهُ المجالِ فلا تبدو شبكتُه. */
function khNoise2(cx,cy,seed){
  var g=new Float32Array(cx*cy), s=(seed>>>0)||1;
  for(var i=0;i<g.length;i++){ s=(s*1664525+1013904223)>>>0; g[i]=s/4294967296; }
  return function(x,y){
    var fx=x*cx, fy=y*cy, x0=Math.floor(fx), y0=Math.floor(fy);
    var tx=fx-x0, ty=fy-y0;
    tx=tx*tx*tx*(tx*(tx*6-15)+10); ty=ty*ty*ty*(ty*(ty*6-15)+10);
    var i0=((x0%cx)+cx)%cx, i1=(i0+1)%cx, j0=((y0%cy)+cy)%cy, j1=(j0+1)%cy;
    var a=g[j0*cx+i0], b=g[j0*cx+i1], c=g[j1*cx+i0], d=g[j1*cx+i1];
    var p=a+(b-a)*tx, q=c+(d-c)*tx;
    return p+(q-p)*ty;
  };
}
function khFabricTex(){
  var N=256, cv=document.createElement('canvas'); cv.width=cv.height=N;
  var ctx=cv.getContext('2d'), img=ctx.createImageData(N,N), D=img.data;
  var wA=khNoise2(3,3,7),  wB=khNoise2(3,3,131);          /* تشويهُ المجالِ فلا تبدو الشبكة */
  var big=khNoise2(3,3,911);                               /* تموّجُ القماشِ العريضُ جِدًّا */
  var cA =khNoise2(9,2,4099),  cB=khNoise2(2,9,5233);      /* طيّاتٌ طويلةٌ متباعدة */
  var mkA=khNoise2(3,3,8291),  mkB=khNoise2(3,3,9377);     /* أين تتجمّع الطيّات */
  var fin=khNoise2(20,20,6151);                            /* حبيباتٌ للخشونةِ لا للنتوء */
  function ridge(n){ n=1-Math.abs(2*n-1); var q=n*n; return q*q*n; }  /* n^5 */
  function gate(n,a,b){ var m=(n-a)/b; m=m<0?0:(m>1?1:m); return m*m*(3-2*m); }
  var H=new Float32Array(N*N);
  for(var y=0;y<N;y++) for(var x=0;x<N;x++){
    var u=x/N, v=y/N;
    var uu=u+(wA(u,v)-0.5)*0.06, vv=v+(wB(u,v)-0.5)*0.06;
    /* المساحاتُ الواسعةُ من البِذلةِ مشدودةٌ ملساء، فالتموّجُ العامُّ خافتٌ جِدًّا */
    var soft=big(u,v);
    /* والطيُّ لا يعمُّ: قِناعٌ ذو أرضيّةٍ صِفر، فأكثرُ من نصفِ السطحِ بلا طيَّةٍ أصلًا.
       وللاتّجاهين قِناعان مختلفان عمدًا: لو تجمّعا في موضعٍ واحدٍ تقاطعا
       شبكةً مُبطَّنةً كاللِّحاف، وليس في البِذلةِ الحقيقيّةِ شيءٌ من ذلك. */
    var cr=0.80*gate(mkA(u,v),0.54,0.26)*ridge(cA(uu,vv))
          +0.20*gate(mkB(u,v),0.62,0.24)*ridge(cB(uu,vv));
    H[y*N+x]=0.5+0.22*(soft-0.5)-0.30*cr+0.012*(fin(u,v)-0.5);
  }
  /* الميلُ يُحسَب هنا مرّةً ويُخزَّن في القناتين الخضراءِ والزرقاء.
     وهذا هو بيتُ القصيد: لو اشتُقَّ الميلُ في المُظلِّل بمشتقّاتِ الشاشة
     (dFdx) لجاء ثابتًا داخلَ كلِّ مثلّثٍ فيقفز عند حوافِّ المثلّثات،
     فتظهر خطوطٌ رأسيّةٌ باهتةٌ على الجذعِ تتبع تثليثَ الكرة. */
  var gmax=1e-6, GU=new Float32Array(N*N), GV=new Float32Array(N*N);
  for(var y2=0;y2<N;y2++) for(var x2=0;x2<N;x2++){
    var xm=(x2+N-1)%N, xp=(x2+1)%N, ym=(y2+N-1)%N, yp=(y2+1)%N;
    var gu=(H[y2*N+xp]-H[y2*N+xm])*0.5, gv=(H[yp*N+x2]-H[ym*N+x2])*0.5;
    GU[y2*N+x2]=gu; GV[y2*N+x2]=gv;
    var a=Math.abs(gu); if(a>gmax) gmax=a;
    a=Math.abs(gv);     if(a>gmax) gmax=a;
  }
  var k=0.5/gmax;
  for(var q2=0;q2<N*N;q2++){
    var o=q2*4;
    var hh=H[q2]; hh=hh<0?0:(hh>1?1:hh);
    D[o]  =(hh*255)|0;
    D[o+1]=((0.5+GU[q2]*k)*255)|0;
    D[o+2]=((0.5+GV[q2]*k)*255)|0;
    D[o+3]=255;
  }
  ctx.putImageData(img,0,0);
  var t=new T.CanvasTexture(cv);
  t.wrapS=t.wrapT=T.RepeatWrapping;
  t.minFilter=T.LinearMipmapLinearFilter; t.magFilter=T.LinearFilter;
  t.anisotropy=4;
  return t;
}
var KH_FAB=null;
function khFab(){ if(!KH_FAB) KH_FAB=khFabricTex(); return KH_FAB; }

/* ── حقنُ الإسقاطِ الثلاثيِّ والخياطاتِ في مُظلِّلِ three القياسيّ ──
   الموضعُ والمستقيمُ العموديُّ في إطارِ القطعة، ومنهما تُقرأ الخريطةُ ثلاثَ
   مرّاتٍ وتُمزَج بمربّعِ المستقيم. والميلُ يُقرأ مخزَّنًا من الخريطةِ نفسِها
   لا يُشتَقُّ بمشتقّاتِ الشاشة، لأنّ المشتقّةَ ثابتةٌ داخلَ كلِّ مثلّثٍ
   فتقفز عند حوافِّه فتظهر خطوطٌ باهتةٌ تتبع تثليثَ الكرة. ثمّ يُدار
   المستقيمُ في فضاءِ القطعةِ ويُنقَل بـ normalMatrix.
   والخياطاتُ فوقَ ذلك تُرسَم على عقدِ kh.js (khAx/khRd/khId) لا على UV. */
function khCloth(m,o){
  o=o||{};
  var U={
    khFab:{value:khFab()},
    khFrq:{value:(o.frq===undefined?46.0:o.frq)},    /* بلاطةٌ لكلِّ ١/٤٦ وحدةٍ محلّيّة */
    khBmp:{value:(o.bmp===undefined?0.75:o.bmp)},    /* قوّةُ النتوء (مضروبةٌ في ميلٍ مخزَّن) */
    khCre:{value:(o.cre===undefined?0.07:o.cre)},    /* غَمقُ قاعِ الطيَّة */
    khRgv:{value:(o.rgv===undefined?0.07:o.rgv)},    /* تموّجُ الخشونة */
    khSm :{value:(o.sm ===undefined?0.022:o.sm)},    /* قوّةُ الخياطة */
    khHd :{value:(o.hd ===undefined?0.22:o.hd)},     /* قوّةُ طيّاتِ القلنسوة */
    khFan:{value:(o.fan===undefined?1.7:o.fan)},     /* كثافةُ المِروحة */
    khFanO:{value:(o.fano===undefined?0.12:o.fano)}  /* إزاحةُ مركزِها خلفَ السطح */
  };
  m.userData.khU=U;
  m.customProgramCacheKey=function(){ return 'khCloth'; };
  m.onBeforeCompile=function(sh){
    for(var k in U) sh.uniforms[k]=U[k];
    sh.vertexShader=sh.vertexShader
      .replace('#include <common>', [
        '#include <common>',
        'varying vec3 vKhP; varying vec3 vKhN;',
        'attribute float khAx; attribute vec2 khRd; attribute float khId;',
        'varying float vKhA; varying vec2 vKhR; varying float vKhI;'].join('\n'))
      .replace('#include <beginnormal_vertex>',
        '#include <beginnormal_vertex>\n\tvKhN = objectNormal;')
      .replace('#include <begin_vertex>', [
        '#include <begin_vertex>',
        '\tvKhP = transformed;',
        '\tvKhA = khAx; vKhR = khRd; vKhI = khId;'].join('\n'));
    sh.fragmentShader=sh.fragmentShader
      .replace('#include <common>', [
        '#include <common>',
        'varying vec3 vKhP; varying vec3 vKhN;',
        'varying float vKhA; varying vec2 vKhR; varying float vKhI;',
        'uniform mat3 normalMatrix;',   /* يربطه three تلقائيًّا متى أُعلِن */
        'uniform sampler2D khFab;',
        'uniform float khFrq;',
        'uniform float khBmp;',
        'uniform float khCre;',
        'uniform float khRgv;',
        'uniform float khSm;',
        'uniform float khHd;',
        'uniform float khFan;',
        'uniform float khFanO;',
        'float khH; vec3 khG;',
        /* ── الثنياتُ العشوائيّة ──────────────────────────────────────────
           إسقاطٌ ثلاثيُّ المستويات: ثلاثُ قراءاتٍ فقط، ومنها يُجمَع الارتفاعُ
           والميلُ معًا. ولكلِّ مستوٍ محوراه في فضاءِ القطعة.               */
        'void khSample(vec3 p, vec3 n){',
        '  vec3 b = n*n; b /= (b.x+b.y+b.z+1e-5);',
        '  vec3 tx = texture2D(khFab, p.yz).rgb;',   /* u→Y  v→Z */
        '  vec3 ty = texture2D(khFab, p.zx).rgb;',   /* u→Z  v→X */
        '  vec3 tz = texture2D(khFab, p.xy).rgb;',   /* u→X  v→Y */
        '  khH = tx.r*b.x + ty.r*b.y + tz.r*b.z;',
        '  khG = b.x*vec3(0.0, tx.g-0.5, tx.b-0.5)',
        '      + b.y*vec3(ty.b-0.5, 0.0, ty.g-0.5)',
        '      + b.z*vec3(tz.g-0.5, tz.b-0.5, 0.0);',
        '}',
        /* ── الخياطاتُ المرسومةُ على عقدِ kh.js ───────────────────────────
           الخياطةُ وادٍ رفيعٌ ليّنٌ مقطعُه ‎(1−d²)²، لا خطٌّ مرسوم. وتُعاد
           مشتقّتُه لا قيمتُه، لأنّ النتوءَ كلَّه يُبنى من الميلِ لا الارتفاع.
           والمعامل 2.6 يجعل ذروةَ المشتقّةِ تساوي A، فتُقاس قوّةُ الخياطةِ
           بمقياسِ الثنياتِ نفسِه.                                          */
        'float khWeld(float t, float t0, float w, float A, inout float h){',
        '  float d = (t-t0)/w, q = 1.0 - d*d;',
        '  if(q <= 0.0) return 0.0;',
        '  h -= A*q*q*0.35;',
        '  return A*2.6*d*q;',
        '}',
        /* خريطةُ العُقَد: ١ جذع، ٢ قلنسوة، ٣ كُمّ، ٤ فخذ، ٥ ساق، ٦ كفٌّ وقدم،
           ٧ كتف، ٨ ياقة. وما لا رقمَ له (الشرطيُّ مثلًا) يصل صفرًا فلا يُخاط.
           khAx: ١ عند الكتفِ في الجذع، وعند الرُّسغِ في الكُمّ، وعند الوركِ
           في الفخذ، وعند الرُّكبةِ في الساق — مقيسةٌ لا مُقدَّرة.            */
        'void khSeam(inout vec3 g, inout float h){',
        '  float id = vKhI, ax = vKhA;',
        '  if(id < 0.5) return;',
        '  float d = 0.0;',
        '  vec3 L = (id > 2.5 && id < 3.5) ? vec3(0.0,1.0,0.0) : vec3(0.0,0.0,1.0);',
        '  if(id < 1.5){',                       /* الجذع: حزامُ الخَصْرِ بحرفين */
        /* خياطةٌ واحدةٌ لا اثنتان، وعند حدِّ الإدراكِ لا فوقَه.
           والقياسُ على البناءِ المشحونِ بإطارٍ مُجمَّد (نفسُ الوَقفةِ بقيمتين،
           فالفرقُ خامةٌ خالصةٌ لا اختلافُ حركة)، والشخصيّةُ ٩٤ بكسلًا:
             ٠٫٠٩٠ → ذروةُ الفرقِ ١٨/٢٥٥ و٤٪ من البكسلاتِ فوقَ ٤ — شريطٌ يُعَدّ
             ٠٫٠٤٥ → ٩/٢٥٥ و٠٫٨٪ — ما يزال يُلتقَط
             ٠٫٠٢٢ → ٤/٢٥٥ ولا بكسلَ فوقَ ٤ — عند العتبةِ فلا يُعَدّ
           والظهرُ هو الحَكَم: هو الوجهُ الوحيدُ الذي يراه اللاعب، وهو في
           الظلِّ هنا فقربَ حدِّ الظلّ يُضخَّم أثرُ انحرافِ المستقيمِ العموديِّ
           تضخيمًا لا يُرى على البطنِ المُضاء. */
        '    d += khWeld(ax, 0.396, 0.060, khSm, h);',
        '  } else if(id < 2.5){',
        /* ── القلنسوة ──────────────────────────────────────────────────
           القماشُ غشاءٌ مشدود: يمسُّ أرنبةَ الأنفِ والحاجبَ والذقنَ ثمّ يمتدُّ
           بينها مستويًا، فمحاجرُ العينِ تختفي اختفاءً تامًّا — المسحُ الضوئيُّ
           عرضَ خطِّ العينِ في الصور يتغيّر أقلَّ من ٥ من ٢٥٥. فلا تُنحَت
           ملامحُ، بل تُنمذَج الطيّاتُ وحدَها: مِروحةٌ تشعُّ من شريطِ الحاجبِ
           والعينِ نزولًا وخروجًا نحوَ الفكّ. والنِّسَبُ من أعلى الرأس:
           حاجبٌ ٠٫٤٠ وعينٌ ٠٫٤٨ وأنفٌ ٠٫٦٦ وفمٌ ٠٫٨٣ وذقنٌ ٠٫٩٢،
           و khAx يعكسها (١ عند القِمّة) فالشريطُ عند ٠٫٥٧ والفكُّ عند ٠٫١٠. */
        '    float th = atan(vKhR.y, vKhR.x);',
        '    float aR = 0.545 - ax;',
        '    float fr = smoothstep(-0.10, 0.50, vKhR.x);',
        '    float dB = khWeld(ax, 0.575, 0.080, khHd*1.60*fr, h);',
        '    d += dB*0.30;',
        '    float gt = smoothstep(0.03,0.15,aR)*smoothstep(0.09,0.26,ax)*fr;',
        '    if(gt > 0.001){',
        '      float aP  = aR + khFanO;',
        /* مركزُ المِروحةِ يُزاح خلفَ السطح: لو أشعَّت من نقطةٍ واحدةٍ
           لالتقت الطيّاتُ كلُّها في وميضٍ نجميٍّ تحتَ النظّارةِ مباشرةً،
           وليس في القماشِ الحقيقيِّ التقاءٌ — بل تتباعد كلَّما نزلت. */
        '      float den = max(th*th + aP*aP, 0.02);',
        '      float ph  = atan(th, aP)*khFan;',
        '      float t   = fract(ph + 0.5) - 0.5;',
        /* الطيّاتُ ليست متساويةَ العمق: يُعطى كلُّ طيَّةٍ وزنًا قارًّا من
           تجزئةِ رقمِها، وإلّا قُرئت مُضلَّعًا كالقطيفةِ المُضلَّعة. */
        '      float jt  = 0.30 + 0.70*fract(sin(floor(ph+0.5)*12.9898)*43758.5453);',
        '      vec3  dir = normalize(vec3(vKhR.x,vKhR.y,0.0)*(aP/den)',
        '                          + vec3(0.0,0.0,1.0)*(th/den) + vec3(1e-5));',
        '      g += khWeld(t, 0.0, 0.34, khHd*gt*jt, h) * dir;',
        '    }',
        '    d += khWeld(ax, 0.220, 0.050, khHd*0.90*smoothstep(0.0,0.50,-vKhR.x), h);',
        '  } else if(id > 2.5 && id < 3.5){',    /* الكُمّ: سِوارُ الرُّسغ */
        '    d += khWeld(ax, 0.865, 0.062, khSm*0.80, h);',
        '  } else if(id > 4.5 && id < 5.5){',    /* الساق: حلقةُ الكاحل */
        '    d += khWeld(ax, 0.225, 0.058, khSm*0.80, h);',
        '  }',
        '  g += d*L;',
        /* الخياطةُ الرأسيّة: أمامًا وخلفًا معًا حيث |جا θ| = ٠، بلا التفافٍ
           ولا انقطاع. وتخفت عند القطبين حيث الزاويةُ غيرُ موثوقة. */
        '  if(id < 1.5){',
        '    float fade = smoothstep(0.08,0.24,ax)*smoothstep(0.03,0.20,1.0-ax);',
        '    float hs = 0.0;',
        '    float ds = khWeld(abs(vKhR.y), 0.0, 0.072, khSm*0.55*fade, hs);',
        '    h += hs;',
        '    g += ds*sign(vKhR.y)*vKhR.x*vec3(vKhR.x, vKhR.y, 0.0);',
        '  }',
        '}'].join('\n'))
      .replace('#include <map_fragment>', [
        '\tkhSample(vKhP*khFrq, normalize(vKhN));',
        '\tkhSeam(khG, khH);',
        '#include <map_fragment>',
        '\tdiffuseColor.rgb *= 1.0 + khCre*(khH-0.55);'].join('\n'))
      .replace('#include <roughnessmap_fragment>',
        '#include <roughnessmap_fragment>\n\troughnessFactor = clamp(roughnessFactor - khRgv*(khH-0.5), 0.05, 1.0);')
      .replace('#include <normal_fragment_maps>', [
        '#include <normal_fragment_maps>',
        '\t{ vec3 No = normalize(vKhN);',
        '\t  vec3 gr = khG - dot(khG, No)*No;',       /* الميلُ على السطحِ وحدَه */
        '\t  normal = normalize(normalMatrix * normalize(No - khBmp*gr)); }'].join('\n'));
  };
  return m;
}

/* ── النظّارةُ المبكسَلة: ٢٤×٧ بكسلًا تُكبَّر بلا تنعيم ── */
function khGlassTex(){
  var W=24,H=7;
  var c=document.createElement('canvas'); c.width=W; c.height=H;
  var g=c.getContext('2d'); g.imageSmoothingEnabled=false;
  g.clearRect(0,0,W,H);
  g.fillStyle="#0B0C0F";
  g.fillRect(1,1,22,4);                 /* الشريطُ الأسودُ الواحد */
  g.fillRect(0,2,1,2); g.fillRect(23,2,1,2);
  g.clearRect(11,4,2,1);                /* فتحةُ الأنفِ أسفلَ الوسط */
  g.clearRect(1,1,1,1); g.clearRect(22,1,1,1);
  g.fillStyle="#39445A"; g.fillRect(2,2,8,1); g.fillRect(14,2,8,1);
  g.fillStyle="#93A4BE"; g.fillRect(3,2,2,1); g.fillRect(15,2,2,1);
  var t=new T.CanvasTexture(c);
  t.magFilter=T.NearestFilter; t.minFilter=T.NearestFilter;
  t.generateMipmaps=false; return t;
}

function khMats(){
  /* اللونُ معايَرٌ على بكسلاتِ العدّاءِ في اللعبةِ المبنيّةِ نفسِها، لا في
     معاينةٍ مستقلّة — وهذا هو الفرق: بيئةُ الانعكاسِ (PMREM لسماءٍ زرقاءَ
     ساطعة) هي معظمُ الإضاءةِ المحيطة، وهي التي تغسل الإشباع. قياسًا على
     العدّاءِ في إطارٍ حيّ: إشباعُ ٠٫٥٨ قبلَ الرفع و٠٫٧٥ بعدَه، مقابلَ ٠٫٧٨
     في الصورةِ الخارجيّة، والدرجةُ ٩٧ مقابلَ ٩٦، بلا بكسلٍ واحدٍ محترق.
     ورُفع الإشباعُ في اللونِ الأساسِ وحدَه (٠٫٨٤ ← ٠٫٩٥) والدرجةُ لم تُمَسّ.
     specularIntensity منخفضةٌ (٠٫٢٨) لأنّ معاملَ فرينل للقماشِ أقلُّ
     من اللدائن — وهذا وحدَه يمحو نصفَ مظهرِ البلاستيك.
     sheen هو خاصّيّةُ القماش: لمعانٌ رجعيٌّ عند الزوايا المائلة
     يُضيء حَرْفَ الظلِّ كما في الصورةِ الخارجيّة. ولا clearcoat:
     هي طبقةُ الوَرنيشِ التي كانت تجعل البِذلةَ تُقرأ فينيلًا لامعًا. */
  var suit=new T.MeshPhysicalMaterial({
    color:0x1FC50D, roughness:0.88, metalness:0.0,
    envMapIntensity:0.45,
    specularIntensity:0.28, specularColor:new T.Color(0xFFFFFF),
    sheen:0.60, sheenColor:new T.Color(0x62CC4E), sheenRoughness:0.55});
  khCloth(suit,{frq:46.0, bmp:0.75, cre:0.07, rgv:0.07});

  /* اليدان والقدمان: طبقةٌ واحدةٌ من القماشِ لا طبقتان، فهي أرقُّ
     فأفتحُ وأصفرُ قليلًا، وثنياتُها أنعمُ لأنّها مشدودةٌ على العضو. */
  var hand=new T.MeshPhysicalMaterial({
    color:0x33D416, roughness:0.90, metalness:0.0,
    envMapIntensity:0.50,
    specularIntensity:0.24, specularColor:new T.Color(0xFFFFFF),
    sheen:0.70, sheenColor:new T.Color(0x7AD85C), sheenRoughness:0.48});
  khCloth(hand,{frq:110.0, bmp:0.45, cre:0.05, rgv:0.05});

  var glass=new T.MeshBasicMaterial({map:khGlassTex(),transparent:true,alphaTest:0.4,
    side:T.DoubleSide,toneMapped:false});
  /* البِذلةُ خضراءُ كاملةً: القلنسوةُ والياقةُ والوجهُ من قماشِ البِذلةِ نفسِه */
  return {suit:suit,hand:hand,sock:hand,hood:suit,rim:suit,face:hand,glass:glass};
}
function ofMats(){
  return { uni:new T.MeshStandardMaterial({color:0x6E7A54,roughness:0.78}),
           unid:new T.MeshStandardMaterial({color:0x5C6746,roughness:0.80}),
           cap:new T.MeshStandardMaterial({color:0x38402C,roughness:0.72}),
           belt:new T.MeshStandardMaterial({color:0x2A2A2C,roughness:0.55}),
           boot:new T.MeshStandardMaterial({color:0x1D1E20,roughness:0.52}),
           skin:new T.MeshStandardMaterial({color:0xBE8A5C,roughness:0.74}) };
}
