/* ── خُضَيران: بِذلةٌ منفوخةٌ مبنيّةٌ على هيكلٍ متحرّكٍ احترافيّ ── */

/* شكلٌ فائقُ التربيع (superquadric) بأُسَّين منفصلين:
     ( |x/a|^r + |y/b|^r )^(e/r) + |z/c|^e = 1
   r يضبط مقطعَ العَرْض (٢ = دائرة)، و e يضبط الملمحَ على محورِ الطول.
   وهذا هو مربطُ الفرس: بأُسٍّ واحدٍ (كرة) يضمُر نصفُ القطرِ عند طرفَي كلِّ
   قطعةٍ فينشأ خَصْرٌ بين كلِّ قطعتين، فتُقرَأ الذراعُ سلسلةَ كُرات. وبرفعِ e
   إلى ٥ أو ٦ يبقى نصفُ القطرِ ممتلئًا حتّى الطرفِ ثمّ يُستدار — فتلتقي
   القطعتان بلا خَصْر، وتُقرَأ الذراعُ أنبوبًا واحدًا كما في البِذلةِ الحقيقيّة. */
function puffGeo(h,p,seg,o){
  o=o||{}; seg=seg||20;
  var g;
  if(o.openY){  /* كُرةٌ مفتوحةٌ للأمام (‎−Y محلّيّ): فتحةُ الوجه */
    g=new T.SphereGeometry(1,seg,Math.max(12,(seg>>1)+6),0,6.283185307,o.openY,3.141592653-o.openY);
    g.rotateX(3.141592653);
  } else g=new T.SphereGeometry(1,seg,Math.max(10,(seg>>1)+4));
  var a=g.attributes.position, v=new T.Vector3();
  var la=(o.la===undefined)?-1:o.la, e=o.pl||p;      /* محورُ الطولِ وأُسُّه */
  var axis=o.axis, pear=o.pear, ridge=o.ridge;
  /* ── عقدُ البيانات للخامة ──────────────────────────────────────────────
     khAx: موضعٌ ٠..١ يتزايد في اتّجاهِ المحورِ الموجب لا من المفصل — أي
           الجذعُ ١ عند الكتفِ و٠ عند الحوض، والفخذُ ١ عند الحوضِ و٠ عند
           الرُّكبة، والساقُ ١ عند الرُّكبةِ و٠ عند الكاحل، والكُمُّ وحدَه ١ عند
           الرُّسغِ لأنّ ‎+Y ينزل مع العظم.
     khRd: (جتا، جا) الزاويةِ حولَ محورِ الطول، الصفرُ نحوَ مقدَّمِ اللابس.
     khId: رقمُ صنفِ القطعة. بها تضع الخامةُ الخياطاتِ بلا إحداثيّاتِ نسيجٍ
     ولا انقطاعَ عند الالتفاف.                                             */
  var L=(la>=0)?la:((axis==="z")?2:1);
  var FS={0:[2,-1,1, 1],1:[2,-1,0,-1],2:[1,-1,0, 1]}[L];   /* [محورُ الأمام، إشارتُه، محورُ الجنب، إشارتُه] */
  var kAx=new Float32Array(a.count), kRd=new Float32Array(a.count*2);
  var kId=new Float32Array(a.count); var idv=(o.id||0);
  for(var i=0;i<a.count;i++){
    v.fromBufferAttribute(a,i);
    var c=[Math.abs(v.x),Math.abs(v.y),Math.abs(v.z)], n;
    if(la<0){                                        /* أُسٌّ واحدٌ لكلِّ المحاور */
      n=Math.pow(Math.pow(c[0],p)+Math.pow(c[1],p)+Math.pow(c[2],p),1/p);
    } else {                                         /* أُسٌّ للمقطعِ وآخرُ للطول */
      var i1=(la+1)%3, i2=(la+2)%3;
      var cs=Math.pow(c[i1],p)+Math.pow(c[i2],p);
      n=Math.pow(Math.pow(cs,e/p)+Math.pow(c[la],e),1/e);
    }
    if(n<1e-6) n=1e-6;
    var x=v.x/n, y=v.y/n, z=v.z/n;
    var P=[x,y,z];
    kAx[i]=(P[L]*0.5)+0.5;
    var fx=FS[1]*P[FS[0]], sx=FS[3]*P[FS[2]], m=Math.sqrt(fx*fx+sx*sx);
    if(m<1e-6){ kRd[i*2]=1; kRd[i*2+1]=0; } else { kRd[i*2]=fx/m; kRd[i*2+1]=sx/m; }
    kId[i]=idv;
    var u=(axis==="z")?z:y;                          /* محورُ التشكيلِ الطوليّ */
    if(pear){ var f=1-pear*(u*0.5+0.5)+pear*0.34;
      if(axis==="z"){ x*=f; y*=f; } else { x*=f; z*=f; } }
    if(ridge){ var w=1+ridge[1]*Math.cos(6.283185307*ridge[0]*(u*0.5+0.5)+(ridge[2]||0));
      if(axis==="z"){ x*=w; y*=w; } else { x*=w; z*=w; } }
    a.setXYZ(i, x*h[0], y*h[1], z*h[2]);
  }
  g.setAttribute("khAx",new T.BufferAttribute(kAx,1));
  g.setAttribute("khRd",new T.BufferAttribute(kRd,2));
  g.setAttribute("khId",new T.BufferAttribute(kId,1));
  g.computeVertexNormals(); return g;
}
function khNorm(n){
  n=n.replace(/_\d+$/,"");
  return n.replace(/^(Foot|Shoulder|Arm|Leg|LowerLeg|Hand)([LR])$/,"$1.$2");
}
function khBuild(root,mats,K){
  var P=K.P, X=K.X||[], J=K.J||{};
  /* إعادةُ نِسَبِ المفاصل. ونحفظ الفرقَ لأنّ بعضَ المفاصلِ تُحرَّك إزاحتُها في
     بعضِ اللقطاتِ دون بعض (الرأسُ في القفزةِ والموتِ لا في الركض)، فيكتب
     المازجُ فوقَ ما ضبطناه — فيُعاد جمعُ الفرقِ بعدَه. */
  root.traverse(function(o){ var t=J[o.name]; if(!t) return;
    o.userData.khD=new T.Vector3(t[0]-o.position.x,t[1]-o.position.y,t[2]-o.position.z);
    o.position.set(t[0],t[1],t[2]); });
  /* السطحُ الواحد: بديلُ الكُتَلِ كلِّها. ومسارُ الكُتَلِ خلفَ ‎?rig=parts‎ */
  if(K.skin && typeof KH_SKIN!=="undefined" && khSkinOn()) return khSkinBuild(root,mats,K);
  var groups={}, made={};
  root.traverse(function(o){
    if(!o.isMesh) return;
    if(o.isSkinnedMesh){ o.visible=false; return; }
    var k=khNorm(o.name); if(!P[k]) return;
    (groups[k]=groups[k]||[]).push(o);
  });
  Object.keys(groups).forEach(function(k){
    var list=groups[k], spec=P[k], par=list[0].parent, bb=new T.Box3();
    list.forEach(function(o){
      o.geometry.computeBoundingBox();
      var b2=o.geometry.boundingBox.clone();
      b2.applyMatrix4(new T.Matrix4().compose(o.position,o.quaternion,o.scale));
      bb.union(b2); o.visible=false;
    });
    if(spec.hide) return;                     /* أُخفيَ الأصلُ ويُبنى بديلُه في X */
    var c=bb.getCenter(new T.Vector3()), s=bb.getSize(new T.Vector3()), h, ai=-1;
    if(spec.fit){
      h=[s.x/2,s.y/2,s.z/2];
      ai=(h[0]>=h[1]&&h[0]>=h[2])?0:((h[1]>=h[2])?1:2);   /* المحورُ الطويل */
      h[ai]*=(spec.len||1);
      for(var i=0;i<3;i++) if(i!==ai) h[i]=spec.fat;
    } else h=spec.box.slice();
    var o3=spec.off||[0,0,0];
    var ng=puffGeo(h,spec.p,spec.seg,{pear:spec.pear,ridge:spec.ridge,openY:spec.openY,
                                     axis:spec.axis,pl:spec.pl,id:spec.id,
                                     la:(spec.la!==undefined?spec.la:ai)});
    ng.translate(c.x+o3[0],c.y+o3[1],c.z+o3[2]);
    var m=new T.Mesh(ng,mats[spec.mat]);
    m.castShadow=true; m.name="KH_"+k; par.add(m); made[k]=m;
  });
  var byName={}; root.traverse(function(o){ byName[o.name]=o; });
  X.forEach(function(x,i){
    var n=byName[x.node]; if(!n) return;
    var ng;
    if(x.cyl) ng=new T.CylinderGeometry(x.cyl[0],x.cyl[1],x.cyl[2],x.cyl[3]||16);
    else ng=puffGeo(x.box,x.p,x.seg,{ridge:x.ridge,axis:x.axis,pl:x.pl,la:x.la,id:x.id});
    if(x.rot) ng.rotateX(x.rot);
    ng.translate(x.off[0],x.off[1],x.off[2]);
    var m=new T.Mesh(ng,mats[x.mat]); m.castShadow=true; m.name="KHX_"+i; n.add(m);
    made["x"+i]=m;
  });
  if(K.face) K.face(byName,mats,made);
  made.__root=root;
  return made;
}
/* ── خُضَيران: بِذلةُ نفخٍ خضراءُ كاملةً — لا فتحةَ وجهٍ ولا أطرافٌ داكنة ──
   إطارُ الجذعِ والرأسِ المحلّيّ: +Z للأعلى، ‎−Y للأمام.
   إطارُ القدم: +Y نحو أصابعِ القدم، +Z للأعلى.
   إطارُ الساعد: +Y امتدادُ العظم.                                        */
/* ── خُضَيران: الكفُّ والقدم ──────────────────────────────────────────────
   الوحدةُ المحلّيّةُ الواحدة = 34.196 من وحداتِ المشهد، وطولُ الشخصيّةِ 2.05،
   فكسرُ الطولِ = القيمةُ المحلّيّة × 16.68 (مقيسٌ من البناءِ لا مُقدَّر).

   النِّسَبُ من الصور المرجعيّة (طولُ الشخصيّةِ في ورقةِ المنتج = 1468 بكسلًا):
     طولُ القدم 213 بكسلًا = 0.145 من الطول · أمامَ الكاحل 68% وخلفَه 32%
     سُمكُ القدمِ عند العَقِب 0.034 ومشطُها 0.023 وأطرافُها 0.014
     عرضُ الكاحل 57 بكسلًا = 0.039 · عرضُ القدم ≈ 0.052
     الكفُّ (من الرُّسغ إلى أطرافِ الأصابع) ≈ 0.103 · عرضُه 0.045 · سُمكُه 0.019

   إشارةُ pear (مقروءةٌ من puffGeo): f = 1 + pear·(0.34 − t) و t تتزايد مع
   المحورِ الموجب. فالموجبُ يُسمِن الطرفَ السالبَ ويُنحِف الموجب.
   القدم: +Y نحوَ الأصابع → pear موجبٌ = عَقِبٌ ممتلئٌ وأصابعُ مستدقّة.
   و X لا تقبل pear إطلاقًا (khBuild لا يمرّرها)، فرُسغُ الكفِّ يُنحَّف بـ
   ridge بنصفِ دورةٍ مُزاحةٍ π: w = 1 − A·cos(πt) — أضيقُ عند ‎−Y (الرُّسغ). */
/* خطُّ اليدِ والقدمِ في kh_hands.js — يُحقَن قبلَ هذا الملفِّ في البناء */


var KH_HANDS = {
 P:{
  /* القدم: قطعةٌ واحدة. p عالٍ فالمقطعُ مستطيلُ الاستدارةِ (نعلٌ مسطّحٌ لا
     حبّةُ فاصولياء)، و pl يقطع الطرفين فيصير مقدَّمُ القدمِ صندوقًا لا رأسَ
     دبّوس، و pear يُسمِن العَقِبَ ويُنحِف الأصابع، و ridge بدورةٍ كاملةٍ
     يحفر الأخمصَ بين العَقِبِ ومشطِ القدم. أُنزلت 0.0027 محلّيّةً عن مركزِ
     المفصل فتخرج من أسفلِ ساقِ البنطالِ المنفوخةِ لا من وسطِها. */
  "Foot.L": {id:6, mat:"hand", p:2.70, seg:16, la:1, pl:3.30, pear:0.55,
             ridge:[1.0,0.08,0.31], box:[0.00145,0.00500,0.00128],
             off:[0,-0.00110,-0.00265]},
  "Foot.R": {id:6, mat:"hand", p:2.70, seg:16, la:1, pl:3.30, pear:0.55,
             ridge:[1.0,0.08,0.31], box:[0.00145,0.00500,0.00128],
             off:[0,-0.00110,-0.00265]}
 },
 X:[
  /* الكفّ: قُفّازٌ بأصابعَ مضمومة — لوحٌ مفلطحٌ (السُّمكُ 0.032 من الطولِ
     والعرضُ 0.052) يضيق عند الرُّسغِ إلى 0.85 فيبدو خارجًا من كُمٍّ قطرُه
     0.127 — وهو التباينُ الذي تقوم عليه صورةُ البِذلةِ كلِّها. */
  {node:"LowerArmL", id:6, mat:"hand", p:2.60, seg:14, la:1, pl:3.20,
   ridge:[0.5,0.15,3.14159], box:[0.00095,0.00305,0.00155], off:[0,0.00620,0.00035]},
  {node:"LowerArmR", id:6, mat:"hand", p:2.60, seg:14, la:1, pl:3.20,
   ridge:[0.5,0.15,3.14159], box:[0.00095,0.00305,0.00155], off:[0,0.00620,0.00035]},
  /* الإبهام: مُزاحٌ إلى حرفِ الكفِّ الأماميِّ (+Z) وإلى الخارجِ قليلًا (±X)
     فيُرى من الأمامِ ومن الجنبِ معًا، ومُمالٌ بـ rot (دورانٌ حولَ X، وهو
     المستوى الذي يقع فيه الكفُّ) فينفرج عن الأصابعِ انفراجَ الإبهام. */
  {node:"LowerArmL", id:6, mat:"hand", p:2.30, seg:10, la:1, pl:2.60,
   box:[0.00058,0.00118,0.00058], rot:0.45, off:[-0.00060,0.00505,0.00150]},
  {node:"LowerArmR", id:6, mat:"hand", p:2.30, seg:10, la:1, pl:2.60,
   box:[0.00058,0.00118,0.00058], rot:0.45, off:[ 0.00060,0.00505,0.00150]}
 ]
};

var KH={
  /* النِّسَبُ مقيسةٌ من الصور المرجعيّةِ ككسورٍ من طولِ الشخصيّة (H=0.0479 محلّيًّا) */
  J:{ "ShoulderL":[ 0.0086,0.0090,0.0004], "ShoulderR":[-0.0086,0.0090,0.0004],
      "Neck":[0,0.0086,0], "Head":[0,0.0032,0] },
  P:{
   /* الجسم: كتلةٌ واحدةٌ عرضُها 0.52H وارتفاعُها 0.44H */
   "Torso":      {id:1, mat:"suit", p:2.30, seg:32, axis:"z", la:2, pl:2.8, box:[0.0108,0.0102,0.0132], pear:-0.26, off:[0,-0.0016,0.0034], ridge:[2.0,0.005]},
   "Head":       {id:2, mat:"suit", p:2.18, seg:24, axis:"z", la:2, pl:2.6, box:[0.0033,0.0034,0.0047], off:[0,-0.0003,0.0004]},
   "Shoulder.L": {id:7, mat:"suit", p:2.20, seg:16, box:[0.0052,0.0052,0.0044]},
   "Shoulder.R": {id:7, mat:"suit", p:2.20, seg:16, box:[0.0052,0.0052,0.0044]},
   "Arm.L":      {hide:1},   /* تُبنى الذراعُ كلُّها قطعةً واحدةً في X أدناه */
   "Arm.R":      {hide:1},
   "Leg.L":      {id:4, mat:"suit", p:2.35, seg:20, fit:1, pl:3.2, la:2, axis:"z", pear:-0.40, fat:0.0050, len:2.15},
   "Leg.R":      {id:4, mat:"suit", p:2.35, seg:20, fit:1, pl:3.2, la:2, axis:"z", pear:-0.40, fat:0.0050, len:2.15},
   "LowerLeg.L": {id:5, mat:"suit", p:2.40, seg:20, fit:1, pl:3.0, la:2, axis:"z", pear:-0.58, fat:0.0032, len:1.12, off:[0,0,0]},
   "LowerLeg.R": {id:5, mat:"suit", p:2.40, seg:20, fit:1, pl:3.0, la:2, axis:"z", pear:-0.58, fat:0.0032, len:1.12, off:[0,0,0]},
   /* القدم: جوربٌ نحيلٌ — طويلةٌ على Y، مسطّحةٌ على Z */
   "Foot.L":     {id:6, mat:"hand", p:2.55, seg:16, la:1, pl:3.4, box:[0.0018,0.0053,0.0016], off:[0,0.0006,-0.0002]},
   "Foot.R":     {id:6, mat:"hand", p:2.60, seg:16, box:[0.0018,0.0053,0.0016], off:[0,0.0006,-0.0002]}
  },
  X:[
   /* الذراعُ كلُّها قطعةٌ واحدة: من الكتفِ إلى الرُّسغ. العَضُدُ وحدَه طولُه ٠٫٨٨
      من قُطرِه فيُقرَأ كُرةً مهما فعلتُ؛ والذراعُ مجتمعةً ٢٫٥ فتُقرَأ أنبوبًا.
      ولا يضرُّ فقدُ ثَنيِ المِرفقِ، فكُمُّ البِذلةِ المنفوخةِ لا ينثني أصلًا. */
   {node:"UpperArmL", id:3, mat:"suit", p:2.35, seg:20, la:1, pl:3.6, ridge:[0.5,0.34,0], box:[0.0050,0.0062,0.0042], off:[0,0.0046,0]},
   {node:"UpperArmR", id:3, mat:"suit", p:2.35, seg:20, la:1, pl:3.6, ridge:[0.5,0.34,0], box:[0.0050,0.0062,0.0042], off:[0,0.0046,0]},
   /* كُرةُ الرُّكبةِ بنصفِ قطرِ الفخذِ نفسِه: تملأ الانحناءَ فيبقى الخطُّ متّصلًا */
   {node:"LowerLegL", id:9, mat:"suit", p:2.10, seg:14, box:[0.0040,0.0040,0.0040], off:[0,0,0]},
   {node:"LowerLegR", id:9, mat:"suit", p:2.10, seg:14, box:[0.0040,0.0040,0.0040], off:[0,0,0]},
   /* الكفُّ والإبهام */
   {node:"LowerArmL", id:6, mat:"hand", p:2.45, seg:14, la:1, pl:3.0, box:[0.0016,0.0030,0.0024], off:[0,0.0062,0.0004]},
   {node:"LowerArmR", id:6, mat:"hand", p:2.45, seg:14, la:1, pl:3.0, box:[0.0016,0.0030,0.0024], off:[0,0.0062,0.0004]},
   /* الإبهامُ كان مركزُه عند x=∓0.0013 وحافّةُ الكفِّ عند ∓0.0016، أي عند 81%
      من نصفِ عرضِه حيثُ المقطعُ الفائقُ قد ضمُرَ ضمورًا شديدًا — فكان الوصلُ
      بينهما شعرةً تنقطعُ بصريًّا متى رُئيت الذراعُ على خلفيّةِ الطريقِ بدلَ
      الجسد (وهو ما كشفَه إبعادُ الذراعين). فيُدفَعُ إلى لحمِ الكفِّ ويُغلَّظ. */
   {node:"LowerArmL", id:6, mat:"hand", p:2.20, seg:10, box:[0.0012,0.0018,0.0012], off:[-0.00085,0.0054,0.0006]},
   {node:"LowerArmR", id:6, mat:"hand", p:2.20, seg:10, box:[0.0012,0.0018,0.0012], off:[ 0.00085,0.0054,0.0006]},
   /* ياقةُ البِذلةِ عند الرقبة */
   {node:"Neck", id:8, mat:"suit", cyl:[0.0026,0.0080,0.0092,20], off:[0,-0.0044,0.0004]}
  ],
  /* النظّارةُ المبكسَلةُ فوقَ القلنسوة — لا فتحةَ وجهٍ إطلاقًا */
  face:function(byName,mats,made){
    var hd=byName["Head_1"]||byName["Head"]; if(!hd) return;
    /* مقاساتٌ مأخوذةٌ من الصورِ لا من التقدير (ارتفاعُ الرأسِ ‎H=0.0094 محلّيًّا):
       طرفُ الأنفِ عند ٠٫٦٦H نزولًا من القِمّة، وبروزُه ٠٫٠٦ من عمقِ الرأس.
       مؤخَّرُ الجمجمةِ يتدلّى خلفَ الرقبةِ بمقدار ٠٫١٢ من العمق.
       والمحاجرُ لا تُنقَر: القماشُ يَجسُرها، فلا نَنحتها.                       */
    /* لا نتوءَ أنفٍ هندسيّ: جُرِّب فقطع النظّارةَ بإسفينٍ أخضرَ ولا يُرى أصلًا
       على حجمِ الجوّال. والقياسُ من الصورِ يقول إنّ المحاجرَ يَجسُرها القماشُ
       ولا تُنقَر — فالوجهُ يُقرأ بتجاعيدِ الشدِّ لا بالنحت، وتلك في الخامة. */
    var bg=puffGeo([0.0024,0.0012,0.0016],2.20,14,{id:2});
    bg.translate(0,0.0027,-0.0026);
    var nape=new T.Mesh(bg,mats.suit); nape.castShadow=true; hd.add(nape);
    if(mats.glass){
      /* النظّارةُ في الصورةِ الحقيقيّةِ لاصقةٌ مسطّحةٌ تتجاوز حدَّ الرأسِ قليلًا،
         لا ملتفّةٌ عليه — فنصنعها كذلك. جرّبتُ قوسًا يلتفُّ على الجمجمةِ ثلاثَ
         مرّاتٍ فكانت النتيجةُ إمّا أن تبتلعه الجمجمةُ أو أن تنفرج أطرافُه
         خارجَ الظِّلّ؛ والمسطّحُ لا يتقاطع أصلًا وهو الأصدقُ للمرجع.
         العرضُ ٠٫٩٦ من عرضِ الرأسِ والارتفاعُ ٠٫١٩ منه، ومركزُه عند ٠٫٤٧
         نزولًا من القِمّةِ — كلُّها مقيسةٌ من الصورة.                        */
      var gl=new T.Mesh(new T.PlaneGeometry(0.0064,0.0018),mats.glass);
      gl.position.set(0,-0.00400,0.0018); gl.rotation.x=-1.570796327;
      hd.add(gl); made.glass=gl;
    }
  }
};
/* ══════════════════════════════════════════════════════════════════════════
   الشرطيّ: هيكلُ الروبوتِ نفسُه، بنِسَبٍ بشريّةٍ عاديّةٍ وزِيٍّ رسميٍّ عامّ
   ══════════════════════════════════════════════════════════════════════════
   وحدةُ الطولِ المحلّيّةُ الواحدة = 42.785 من وحداتِ المشهدِ بعدَ التطبيع
   (سُلَّمُ كلِّ العُقَدِ واحدٌ، قِيسَ ولم يُظَنّ). وطولُ الشخصيّةِ المبنيّةِ
   T = 1.356 من تلك الوحدات، فكلُّ كسرٍ من الطولِ = ‎(كسر × 1.356 ÷ 42.785).

   الأطرُ المحلّيّةُ (مقيسة):
     Torso  (عقدةٌ عند 0.939): ‎+Z أعلى، ‎−Y أمام، ‎+X يمين.
     Head_1 (يعلو عظمَ الرأسِ بـ 0.277): ‎+Z أعلى، ‎−Y أمام.
     Body   (عند 0.596): محاورُ العالمِ نفسُها.
     العظامُ الطرفيّة: ‎+Y امتدادُ العظم.   FootL/R: ‎+Y نحوَ الأصابع، ‎+Z أعلى.

   النِّسَبُ النهائيّةُ مقيسةٌ من البناءِ نفسِه، ككسورٍ من طولِ الشخصيّةِ المرئيّ:
     الجمجمةُ من الذقنِ إلى القِمّة 0.133 · مع القلنسوة 0.158 · الذقنُ عند 0.842
     عرضُ المنكبين 0.272 · ارتفاعُ مفصلِ الكتف 0.777 · الحزامُ 0.583–0.611
     الوركُ 0.446 · الركبةُ 0.278 · ذَيلُ القميص 0.570 · ساقُ الجزمة 0.008–0.139
     الطولُ المرئيُّ = 1.356 من وحداتِ الصندوقِ المحيطِ الذي يُعاير عليه khBuild
     (وكان بناءُ الشرطيِّ السابقُ 1.775 والعدّاءُ 1.759) — فليُرفَع وسيطُ Rig
     للشرطيِّ من 1.95 إلى نحوِ 2.55 ليبقى حجمُه على الشاشةِ كما كان.           */
/* دمجُ خطِّ اليدِ والقدمِ الذي قاسه الوكيلُ من الصور.
   القديمُ يُزال بالتصفيةِ لا بحذفِ الأسطر، فلا يُكسَر البناءُ النصّيّ. */
Object.assign(KH.P, KH_HANDS.P);
KH.X = KH.X.filter(function(x){ return x.mat!=="hand"; }).concat(KH_HANDS.X);

var OF={
  J:{
   /* المنكبان: الروبوتُ عريضُهما عرضًا كرتونيًّا (0.375 من الطول) فيُضَمّان
      إلى 0.272، ويُرفَعان لأنّ الجذعَ صار بشريًّا قصيرًا. */
   "ShoulderL":[ 0.00260, 0.00509, 0.00040],
   "ShoulderR":[-0.00260, 0.00509, 0.00040],
   "Neck":[0, 0.00588, 0],
   /* عظمُ الرأسِ ينزل إلى مستوى الفكّ، فيصير محورُ الالتفاتةِ في الرقبةِ
      لا فوقَ الجمجمةِ كما في النموذجِ الأصليّ. */
   "Head":[0, 0.00199, 0],
   /* الوركانِ والقدمان: مسافةُ ما بين الفخذين في النموذجِ 0.395 من الطول —
      ضعفُ البشريّ — فتَبقى الساقانِ معلّقتينِ خارجَ الجذعِ مهما وُسِّع.
      يُنقَلانِ معًا بالمقدارِ نفسِه (الوركُ والقدمُ) فتنتقلُ الساقُ كتلةً
      واحدةً ولا تنكسرُ اللقطةُ المخبوزة. إزاحةُ الوركِ لا تكتبها لقطة،
      وإزاحةُ القدمِ تكتبها — و khPost يعيد جمعَ الفرقِ (khD) بعدَ المازج. */
   "UpperLegL":[ 0.00288, 0.00096,-0.00183],
   "UpperLegR":[-0.00297, 0.00096,-0.00183],
   "FootL":[ 0.00293, 0.00031, 0.00057],
   "FootR":[-0.00292, 0.00031, 0.00057]
  },
  P:{
   /* القميص: من 0.593 إلى 0.818 من الطول. مقطعٌ مستطيلُ الاستدارة (p=2.55)
      لا بيضاويّ — فيُقرأ ثوبًا لا بالونًا — و pear سالبٌ فيتّسع عند الصدرِ
      ويضيق عند الوسطِ حيث الحزام. */
   "Torso":      {mat:"uni",  p:2.55, pl:5.00, la:2, seg:28, axis:"z",
                  box:[0.00292,0.00195,0.00397], off:[0,0.00004,0.00209], pear:-0.14},
   /* الرأس: بيضةٌ قائمةٌ عريضةٌ قليلًا (0.095 من الطول عرضًا) — القلنسوةُ
      تبتلع قِمّتَها كاملةً فلا يُرى منها إلّا الفكُّ ومؤخّرُ الجمجمة. */
   "Head":       {mat:"skin", p:2.20, pl:2.60, la:2, seg:22, axis:"z",
                  box:[0.00152,0.00183,0.00206], off:[0,0.00033,-0.00779], pear:-0.06},
   /* رأسا المنكبين: كتلتانِ مفلطحتانِ لا كُرتان — عريضتانِ على محورِ الكتف،
      رقيقتانِ على محورِ العَضُد. هما كلُّ ما يصنع خطَّ الكتفِ من الخلف. */
   "Shoulder.L": {mat:"uni",  p:2.35, seg:18, box:[0.00147,0.00112,0.00126], off:[0,0.00040,0]},
   "Shoulder.R": {mat:"uni",  p:2.35, seg:18, box:[0.00147,0.00112,0.00126], off:[0,0.00040,0]},
   /* الذراعانِ تُبنيانِ في X: صندوقا ArmL و ArmR في النموذجِ غيرُ متماثلين
      (نصفُ طولٍ 0.0041 مقابل 0.0038) فيخرجُ الكُمّانِ مختلفَي الطول. */
   "Arm.L":      {hide:1},
   "Arm.R":      {hide:1},
   /* البنطال: أغمقُ من القميص، يضيق نحوَ الركبةِ ثمّ نحوَ ساقِ الجزمة. */
   "Leg.L":      {mat:"cap" , p:2.40, pl:3.20, seg:16, fit:1, fat:0.00145, len:0.971, off:[0,-0.00085,0], pear:0.18},
   "Leg.R":      {mat:"cap" , p:2.40, pl:3.20, seg:16, fit:1, fat:0.00145, len:0.971, off:[0,-0.00085,0], pear:0.18},
   "LowerLeg.L": {mat:"cap" , p:2.40, pl:3.20, seg:16, fit:1, fat:0.00126, len:1.12, off:[0,-0.00202,0.00037], pear:0.24},
   "LowerLeg.R": {mat:"cap" , p:2.40, pl:3.20, seg:16, fit:1, fat:0.00126, len:1.12, off:[0,-0.00202,0.00037], pear:0.24},
   /* الجزمة: مقطعٌ صندوقيّ (p=2.8) وطرفانِ مقطوعانِ (pl=4) — لا كرة. */
   "Foot.L":     {mat:"boot", p:2.80, pl:4.00, la:1, seg:16, box:[0.00102,0.00250,0.00106], off:[0,-0.00239,-0.00030], pear:0.14},
   "Foot.R":     {mat:"boot", p:2.80, pl:4.00, la:1, seg:16, box:[0.00102,0.00250,0.00106], off:[0,-0.00239,-0.00030], pear:0.14}
  },
  X:[
   /* ─── الحوضُ والبنطال: قطعةٌ مستقلّةٌ معلّقةٌ على Body (لا على الجذع) فتتبع
        الوركينِ لا انحناءَ الظهر. وهي التي تفصل القميصَ عن البنطالِ عند
        الحزامِ فلا يُقرأ الجسمُ كيسًا واحدًا. ridge بنصفِ دورةٍ يجعلها
        ضيّقةً من فوقُ (تختفي تحتَ القميص) عريضةً من تحت. ─── */
   {node:"Body", mat:"cap" , p:2.30, pl:2.90, la:1, seg:22,
    box:[0.00290,0.00304,0.00202], ridge:[0.5,0.10,0], off:[0,0.00395,-0.00129]},
   /* ─── الذراعان ─── */
   {node:"UpperArmL", mat:"uni",  p:2.30, pl:3.40, la:1, seg:18, box:[0.00126,0.00300,0.00126], off:[0,0.00320,0]},
   {node:"UpperArmR", mat:"uni",  p:2.30, pl:3.40, la:1, seg:18, box:[0.00126,0.00300,0.00126], off:[0,0.00320,0]},
   {node:"LowerArmL", mat:"uni",  p:2.10, seg:12, box:[0.00120,0.00120,0.00120], off:[0,0,0]},   /* مِرفق */
   {node:"LowerArmR", mat:"uni",  p:2.10, seg:12, box:[0.00120,0.00120,0.00120], off:[0,0,0]},
   /* الساعدُ يُقصَّر بصرًا: عظمُ ساعدِ النموذجِ ٢٫٨ أضعافِ البشريّ. */
   {node:"LowerArmL", mat:"uni",  p:2.40, pl:3.40, la:1, seg:16, box:[0.00108,0.00230,0.00108], off:[0,0.00250,0]},
   {node:"LowerArmR", mat:"uni",  p:2.40, pl:3.40, la:1, seg:16, box:[0.00108,0.00230,0.00108], off:[0,0.00250,0]},
   {node:"LowerArmL", mat:"skin", p:2.20, seg:12, box:[0.00092,0.00125,0.00080], off:[0,0.00575,0.00005]},
   {node:"LowerArmR", mat:"skin", p:2.20, seg:12, box:[0.00092,0.00125,0.00080], off:[0,0.00575,0.00005]},
   /* ─── الركبةُ وساقُ الجزمة ─── */
   {node:"LowerLegL", mat:"cap" , p:2.10, seg:12, box:[0.00126,0.00126,0.00126], off:[0,0,0]},
   {node:"LowerLegR", mat:"cap" , p:2.10, seg:12, box:[0.00126,0.00126,0.00126], off:[0,0,0]},
   /* ساقُ الجزمةِ تبتلع ذَيلَ البنطال: البنطالُ عند طرفِه 0.00099 والجزمةُ 0.00120 */
   {node:"LowerLegL", mat:"boot", p:2.50, pl:4.00, la:1, seg:16, box:[0.00124,0.00190,0.00124], off:[0,0.00738,0.00037]},
   {node:"LowerLegR", mat:"boot", p:2.50, pl:4.00, la:1, seg:16, box:[0.00124,0.00190,0.00124], off:[0,0.00738,0.00037]},
   /* ─── الرقبةُ والياقة ─── */
   {node:"Neck", mat:"skin", cyl:[0.00080,0.00098,0.00173,14], off:[0,0.00082,-0.00008]},
   {node:"Neck", mat:"unid", cyl:[0.00112,0.00175,0.00129,18], off:[0,0.00018,0]},
   /* ─── الحزام: شريحةٌ مسطّحةٌ بمقطعِ القميصِ نفسِه لا أسطوانةٌ دائريّة ─── */
   {node:"Torso", mat:"belt", p:2.55, pl:6.00, la:2, seg:26, axis:"z",
    box:[0.00274,0.00188,0.00048], off:[0,-0.00004,-0.00196]},
   /* ─── القلنسوة: شريطٌ أسودُ يغطّي فوقَ الأذنين، ثمّ تاجٌ يتّسع للأعلى
        (ridge بنصفِ دورةٍ مُزاحةٍ π يعطي الاتّساعَ لأنّ X لا يقبل pear)،
        ثمّ رفرفٌ مائلٌ إلى الأمامِ والأسفل. ─── */
   /* ─── شَعرٌ قصيرٌ داكنٌ يغطّي مؤخّرَ الجمجمةِ وجانبَيها: هو ما يمنع
        الرأسَ أن يُقرأ كُرةً لحميّةً تحتَ قلنسوة. مُزاحٌ إلى الخلفِ فيبقى
        الوجهُ مكشوفًا، و pl عالٍ فيظلُّ عريضًا حتّى تحتِ حرفِ القلنسوة. ─── */
   {node:"Head_1", mat:"belt", p:2.10, pl:3.00, la:2, seg:22, axis:"z",
    box:[0.00170,0.00148,0.00115], off:[0,0.00068,-0.00486]},
   {node:"Head_1", mat:"cap",  p:2.60, pl:8.00, la:2, seg:24, axis:"z",
    box:[0.00184,0.00208,0.00049], off:[0,0,-0.00376]},
   {node:"Head_1", mat:"cap",  p:2.65, pl:3.00, la:2, seg:26, axis:"z",
    box:[0.00207,0.00232,0.00090], ridge:[0.5,0.115,3.14159], off:[0,0,-0.00293]},
   {node:"Head_1", mat:"belt", p:2.30, pl:3.40, la:2, seg:22,
    box:[0.00158,0.00094,0.00023], rot:0.32, off:[0,-0.00205,-0.00455]},
   /* ─── نظّارةٌ داكنةٌ واحدة: علامةٌ عامّةٌ لا شعارَ فيها ولا كتابة ─── */
   {node:"Head_1", mat:"belt", p:2.40, pl:6.00, la:2, seg:20,
    box:[0.00140,0.00102,0.00030], off:[0,-0.00088,-0.00505]}
  ]
};

/* البِذلةُ المنفوخةُ تدفع الذراعين إلى الخارج، والعدّاءُ يلتفت ليرى مَن خلفَه.
   كلاهما إضافةٌ فوقَ ما تكتبه اللقطة، وتُطبَّق بعد المازج.

   فخٌّ مهمّ: `rotateY` تضرب في الدوران القائم. فإن كان العظمُ ممّا لا تكتبه
   اللقطةُ — و`Torso` لا تكتبه أيُّ لقطةٍ في هذا النموذج، و`UpperArm` لا تكتبه
   لقطتا السكونِ والموت — تراكمَ الدورانُ إطارًا بعد إطارٍ حتّى يلتوي الجسمُ كلُّه.
   فلا بدّ من إعادةِ كلِّ عظمٍ غيرِ مكتوبٍ إلى وضعِه الأصليِّ قبلَ الإضافة. */
var khFTm=new T.Matrix4(), khFTv=new T.Vector3();   /* مؤقّتاتُ ربطِ القدم */
function khPost(bones,rest,driven,splay,look,opt){
  var restP=(opt&&opt.restP)||{}, drivenP=(opt&&opt.drivenP)||{},
      pinP=(opt&&opt.pinP)||null;
  /* أعِدْ فرقَ النِّسَبِ لكلِّ مفصلٍ كتبت اللقطةُ إزاحتَه.

     فخّانِ هنا، كلاهما مقيسٌ لا مُقدَّر:

     ١) المازجُ لا يكتبُ كلَّ إطار. ‎PropertyMixer.apply‎ في ثري لا يستدعي
        ‎setValue‎ إلّا إذا اختلفتِ القيمةُ المتراكمةُ عن قيمةِ الإطارِ السابق.
        ولقطةُ الموتِ ‎LoopOnce+clampWhenFinished‎: متى بلغت آخرَها ثبتت قيمتُها،
        فيتوقّفُ المازجُ عن الكتابةِ أصلًا — ويبقى ما تركناه نحن. فجمعُ ‎khD‎
        حينئذٍ يتراكمُ إطارًا بعد إطارٍ بلا نهاية (قِيس: ‎+1.01e-4‎ لكلِّ إطارٍ
        على عظمِ الرأس، أي ‎+0.003‎ من وحداتِ المشهدِ لكلِّ إطار، فلا يقفُ عند حدّ).
        فنحفظُ بصمةَ ما خرجنا به (‎khOut‎) وقيمةَ اللقطةِ الأخيرة (‎khIn‎): إن
        وجدنا الإزاحةَ كما تركناها بحرفِها فالمازجُ لم يكتبْ، فنستعيدُ ‎khIn‎
        قبلَ الجمع. فلا يتراكمُ شيءٌ مهما طالَ المشهدُ ومهما ارتفعَ معدّلُ الإطارات.

     ٢) ‎pinP‎ — عظامٌ تُثبَّتُ إزاحتُها عند وضعِ الراحةِ ولو كتبتها اللقطة.
        لقطةُ ‎Death‎ في هيكلِ الروبوتِ ترفعُ عظمَ ‎Head‎ من ‎0.0031‎ إلى ‎0.0287‎
        (‎×9.25‎): رأسُ الروبوتِ يطيرُ عن جسدِه — وهو مشهدٌ يليقُ بآلةٍ لا ببشريٍّ
        في بِذلةٍ منفوخة. فتُثبَّتُ إزاحةُ الرأسِ في الموتِ وحدَه، ويبقى دورانُها
        كما كتبته اللقطةُ فيميلُ الرأسُ ولا ينفصل. */
  for(var n in bones){
    if(!drivenP[n]) continue;
    var o=bones[n], ud=o.userData, ot=ud.khOut;
    if(ot && ot.x===o.position.x && ot.y===o.position.y && ot.z===o.position.z)
      o.position.copy(ud.khIn);
    (ud.khIn||(ud.khIn=new T.Vector3())).copy(o.position);
    if(pinP && pinP[n] && restP[n]) o.position.copy(restP[n]);
    else if(ud.khD) o.position.add(ud.khD);
  }
  function put(n,fn,amt){
    var o=bones[n]; if(!o) return;
    if(!driven[n] && rest[n]) o.quaternion.copy(rest[n]);
    if(amt) fn(o,amt);
  }
  put("Body",     function(o,a){ o.rotateX(a); },(opt&&opt.lean)||0);      /* ميلُ الركض */
  /* تمايُلٌ جانبيٌّ كمِشيةِ البطريق: الكتلةُ ثقيلةٌ فتتأرجح مع كلِّ خطوةٍ يمنةً
     ويسرة. دورةٌ واحدةٌ لكلِّ خطوتين، ومنزاحةٌ رُبعَ دورةٍ عن وقعِ القدم. */
  var rol=(opt&&opt.roll)||0;
  if(rol && bones.Body) bones.Body.rotateZ(rol);
  /* تضخيمُ التأرجح: البِذلةُ تُخفي حركةَ الذراعِ فتبدو مشلولة. نأخذ دورانَ
     اللقطةِ ونُكبّر زاويتَه حولَ وضعِ الراحةِ بمعامِلٍ ثابت — أي نُطيل القوسَ
     نفسَه لا نخترع حركةً جديدة، فيبقى التوقيتُ توقيتَ المُحرِّك. */
  var amp=(opt&&opt.armAmp), cap=(opt&&opt.armCap)||0, ref=(opt&&opt.armRef)||null;
  if(amp===undefined||amp===null) amp=0;
  if(amp>0 && (amp!==1 || cap>0)){
    ["UpperArmL","UpperArmR"].forEach(function(n){
      var o=bones[n], r=rest[n]; if(!o||!r) return;
      /* ما لا تكتبه اللقطةُ يُردُّ إلى الراحةِ ولا يُضخَّم. لولا ذلك لضُرِبَتْ
         زاويةُ الإطارِ السابقِ في المعامِلِ إطارًا بعدَ إطارٍ حتّى تلتويَ الذراع
         (وهي علّةُ التراكمِ نفسُها التي يحرسُ منها put). */
      if(!driven[n]){ o.quaternion.copy(r); return; }
      /* المرجعُ الذي نُضخِّمُ حولَه. وضعيّةُ الراحةِ ليست منتصفَ القوس:
         قوسُ الذراعِ اليمنى في المقطعِ يمتدُّ من ‎+33° إلى ‎−94° عن الراحة،
         فالتضخيمُ حولَ الراحةِ يُطيلُ الطرفَ الطويلَ وحدَه فترتفعُ الذراعُ
         في الهواء. المرجعُ الصحيحُ منتصفُ القوسِ (armRef)، وعندَه يصيرُ
         التضخيمُ متناظرًا حولَ وسطِ الأرجحةِ لا حولَ طرفِها. */
      var R=r;
      if(ref && ref[n]){ var v=ref[n]; R=new T.Quaternion(v[0],v[1],v[2],v[3]); }
      var d=R.clone().invert().multiply(o.quaternion);
      /* القوسُ الأقصر: الرباعيُّ يغطّي كلَّ دورانٍ مرّتين بإشارتين. فإن خرج
         w سالبًا قرأتِ الزاويةُ 294° بدلَ 66° وانقلبَ المحورُ معها — وهو ما
         كان يجعلُ ذراعًا واحدةً تقفزُ قفزةً شاذّةً في سُدسِ الدورةِ ثمّ تعود.
         نُوحّدُ الإشارةَ قبلَ أيِّ حساب. */
      if(d.w<0){ d.x=-d.x; d.y=-d.y; d.z=-d.z; d.w=-d.w; }
      var w=d.w; if(w>1) w=1;
      var ang=2*Math.acos(w), sn=Math.sqrt(1-w*w);
      if(sn>1e-5 && ang>1e-5){
        var ax=d.x/sn, ay=d.y/sn, az=d.z/sn, na=ang*amp;
        /* سقفُ المدى: الركضُ لا يرفعُ الكفَّ فوقَ الكتفِ إلّا قليلًا. */
        if(cap>0 && na>cap) na=cap;
        var h=na*0.5, sh=Math.sin(h);
        d.set(ax*sh,ay*sh,az*sh,Math.cos(h));
        o.quaternion.copy(R).multiply(d);
      }
    });
  }
  /* انفراجُ الذراعين. المقطعُ نفسُه غيرُ متناظر: مركزُ قوسِ الذراعِ اليمنى
     يبعدُ 30° عن راحتِها بينما اليسرى 3° فقط، فتبدو اليمنى ملتصقةً بالجسدِ
     واليسرى منفرجة. splayBias يفرِّقُ بين الجانبين فيُعيدُ التناظر. */
  var sb=(opt&&opt.splayBias)||0;
  put("UpperArmL",function(o,a){ o.rotateZ(-a); },splay+sb);
  put("UpperArmR",function(o,a){ o.rotateZ( a); },splay-sb);
  /* إبعادُ الذراعِ عن الجسد. محورُ أرجحةِ الكتفِ في هذا الهيكلِ هو Z المحلّيُّ
     تقريبًا، فالدورانُ حولَه (splay) يُزيحُ القوسَ ولا يُبعِدُ الذراع؛ والإبعادُ
     الحقيقيُّ حولَ X المحلّيّ. armOut=[يسار, يمين] بالتقدير الدائريّ. */
  var ao=(opt&&opt.armOut);
  if(ao){ if(bones.UpperArmL&&ao[0]) bones.UpperArmL.rotateX(ao[0]);
          if(bones.UpperArmR&&ao[1]) bones.UpperArmR.rotateX(ao[1]); }
  put("Torso_1",  function(o,a){ o.rotateY(a*0.50); },look);
  put("Neck",     function(o,a){ o.rotateY(a*0.52); },look);
  put("Head",     function(o,a){ o.rotateY(a*0.72); o.rotateX(a*0.13); },look);
  /* البِذلةُ المنفوخةُ لا تدع المِرفقَ ينطوي انطواءً كاملًا: تُقرَّب زاويتُه
     نحوَ وضعِ الراحةِ بنسبةٍ ثابتة. والرُّكبةُ أخفُّ لأنّ الركضَ يحتاجها. */
  var st=(opt&&opt.stiff);
  if(st){
    for(var bn in st){
      var o=bones[bn], r=rest[bn];
      if(o && r) o.quaternion.slerp(r, st[bn]);
    }
  }
  /* البطنُ المنفوخةُ تدفع الفخذين للخارج: إزاحةٌ جانبيّةٌ للوركين وللقدمين معًا
     حتّى لا ينفصل الساقُ عن قدمِه (القدمان تُحرَّك إزاحتُهما في اللقطة). */
  var w=(opt&&opt.stance)||0;
  function putP(n,dx){
    var o=bones[n]; if(!o) return;
    /* الفخذُ لا تُحرَّك إزاحتُه في أيِّ لقطة، فلو جمعنا عليه تراكمَ حتّى ينفرطَ
       الجسم. والقدمُ تُحرَّك إزاحتُها فيُعاد كتابتُها كلَّ إطارٍ فالجمعُ عليها سليم. */
    if(!drivenP[n] && restP[n]) o.position.copy(restP[n]);
    o.position.x += dx;
  }
  if(w){ putP("UpperLegL", w); putP("UpperLegR",-w);
         putP("FootL",     w); putP("FootR",    -w); }
  /* ── ربطُ القدمِ بساقِها ────────────────────────────────────────────────
     عظما FootL/FootR في هذا الهيكلِ معلّقانِ بجذرِ الهيكل (Bone) لا بعظمِ
     الساق — فهما مِرقابانِ (IK effectors) تكتبُ اللقطةُ موضعَهما مباشرةً.
     ولقطاتُ الروبوتِ الأصليّةُ مؤلّفةٌ على أطوالِ عظامِه؛ وسيقانُ خُضَيران
     مبنيّةٌ بـ fit وطولٍ 2.15 للفخذِ و1.12 للساقِ — أي أطولُ بكثيرٍ من العظم.
     فما دامتِ اللقطةُ هي التي تُحرّكُ الساقَ والقدمَ معًا بقيتا متوافقتين
     (قِيس: فجوةٌ صفرٌ في الركضِ والقفزِ عبرَ 200 إطار)؛ فإذا تدخّلنا نحن
     في دورانِ الساقِ (stiff في الانزلاق) أو مالَ الجذعُ فدارتِ الساقُ تحتَه
     (لقطةُ الموت) بقيتِ القدمُ مغروسةً حيثُ غرستْها اللقطةُ وانفصلتْ عن ساقِها.

     العلاجُ: يُقيَّدُ موضعُ الكاحلِ في إطارِ عظمِ الساقِ داخلَ الكرةِ التي
     تتحرّكُ فيها في الركضِ والقفزِ نفسِهما — لا أكثر. فما كان داخلَها لا
     يُمَسُّ ألبتّة (وهو كلُّ الركضِ والقفز)، وما خرجَ منها يُردُّ إلى حافّتِها
     فتتبعُ القدمُ ساقَها. المركزُ ونصفُ القطرِ مقيسانِ من اللعبةِ نفسِها
     (ft2.mjs): يسارًا 0.002862 ويمينًا 0.003382، وأُخِذَ كلٌّ منهما ×1.06. */
  var ft=(opt&&opt.footTie);
  if(ft){
    for(var fi=0;fi<2;fi++){
      var fbn=fi?"FootR":"FootL", sbn=fi?"LowerLegR":"LowerLegL", cf=ft[fbn];
      var fo=bones[fbn], so=bones[sbn];
      if(!fo||!so||!cf) continue;
      so.updateWorldMatrix(true,false); fo.updateWorldMatrix(true,false);
      khFTm.copy(so.matrixWorld).invert();
      khFTv.setFromMatrixPosition(fo.matrixWorld).applyMatrix4(khFTm);
      var ax=khFTv.x-cf[0], ay=khFTv.y-cf[1], az=khFTv.z-cf[2];
      var al=Math.sqrt(ax*ax+ay*ay+az*az);
      if(al>cf[3]){
        var ak=cf[3]/al;
        khFTv.set(cf[0]+ax*ak, cf[1]+ay*ak, cf[2]+az*ak).applyMatrix4(so.matrixWorld);
        khFTm.copy(fo.parent.matrixWorld).invert();
        fo.position.copy(khFTv.applyMatrix4(khFTm));
        if(ft.hit) ft.hit(fbn,al);
      }
    }
  }
  /* بصمةُ الخروج: بها وحدَها يُعرَفُ في الإطارِ التالي أكتبَ المازجُ أم تخطّى.
     تُؤخَذُ بعدَ كلِّ إضافةٍ (ومنها إزاحةُ ‎stance‎ على القدمين) وإلّا تراكمتْ
     تلك الإضافاتُ هي الأخرى متى تخطّى المازجُ الكتابة. */
  for(var pn in bones){
    if(!drivenP[pn]) continue;
    var po=bones[pn], pud=po.userData;
    (pud.khOut||(pud.khOut=new T.Vector3())).copy(po.position);
  }
}
/* ═══════════════════════════════════════════════════════════════════════════
   khJiggle — حركةٌ ثانويّةٌ حقيقيّةٌ للبِذلةِ المنفوخة (بديلُ الجيبِ المصنوع)
   ───────────────────────────────────────────────────────────────────────────
   CALL CONTRACT for g3.html  (this is the ONLY change needed at the call site)

   REPLACE these three lines in loop(), inside `if(rigKh.ready){ ... }`:

       var aR=rigKh.act.Running;
       if(aR&&aR.getClip()) khJiggle(rigKh.parts["Torso"],
         (aR.time/aR.getClip().duration)%1, 0.050*aR.getEffectiveWeight());

   WITH:

       var aR=rigKh.act.Running, aC=aR&&aR.getClip();
       khJiggle(rigKh.parts["Torso"], dt, {
         body : rigKh.bones["Body"],
         root : rigKh.g,
         phase: aC ? (aR.time/aC.duration)%1 : -1,
         run  : aR ? aR.getEffectiveWeight() : 0,
         air  : air
       });

   POSITION IN THE FRAME: exactly where the old call was — i.e. AFTER
   `rigKh.mix.update(dt)` and AFTER `khPost(...)`, so the Body bone already
   holds this frame's final pose.  (Optional, strictly better: move the two
   lines `rigKh.g.rotation.x=...` and `rigKh.g.position.y=...` ABOVE this
   call, so the slide tilt is this frame's rather than last frame's.  The
   difference is one frame of a slow ramp; leaving them below is fine.)

   ARGUMENTS
     mesh   — rigKh.parts["Torso"].  Its local +Z is UP (as the old code
              assumed).  The function only ever WRITES mesh.scale, absolutely,
              never incrementally — so it cannot drift.
     dt     — the loop's already-clamped frame time in seconds.  Clamped again
              internally to 0.1 s.  dt<=0 is safe (state is held, nothing
              integrates).
     o      — options, all optional:
       o.body  the "Body" bone (read-only).  The drive signal.  Omitting it
               leaves the springs driven by footfall/landing events only.
       o.root  rigKh.g — the rig root.  MUST be an ancestor of o.body.  Its
               world Y is subtracted from the bone's, which removes the game's
               jump `lift` and the slide drop from the drive, leaving only the
               vertical motion the ANIMATION itself produces.  (Feeding the
               game's lift in would inject a ±11 m/s velocity STEP at takeoff
               and touchdown — the render lift is not C1 — and swamp
               everything else.  Takeoff/landing are handled as explicit
               events instead, from o.air, which is both tamer and tunable.)
       o.phase run-cycle phase 0..1, or -1/undefined when there is no run
               clip.  Used ONLY to place footfalls (two per stride, at phase
               0.0 and 0.5); it is never used as a waveform.
       o.run   the Running action's effective weight, 0..1.  Scales the
               footfall impulses, so footsteps vanish during Jump/Death.
       o.air   sim.s.air (seconds of jump window left).  Its falling edge
               through o.airT is the LANDING event; its rising edge is the
               takeoff.  No separate flag is needed from the caller.
       o.airT  the loop's AIR_T.  Default 0.12 — keep in sync if you change it.
       o.reset truthy for one frame to hard-zero all state (call it on
               start()/restart if you want a guaranteed-clean run; the
               velocity clamp already handles respawn pops without it).

   RETURN VALUE  (optional to use; ignoring it is perfectly fine)
     The amount the TOP of the torso sank this frame, in the rig's local
     units — the same units as `rigKh.parts["Head"].position`.  Positive =
     the suit is compressed and its shoulder line has dropped.  To let the
     head ride the suit instead of floating over it:

         var sink = khJiggle(rigKh.parts["Torso"], dt, {...});
         if(rigKh.parts["Head"]) rigKh.parts["Head"].position.z = -sink*0.5;

     (+Z is up in the Head's local frame too.  It is an absolute write, so it
     self-neutralises.  0.5 is a taste factor; 1.0 glues the head to the
     shoulder line, 0 disables it.  Verified numerically and in the renderer,
     but it is a small effect — leave it out if you dislike it.)
     `khJiggle.q` is also set each frame to the raw signed squash
     (+ = compressed, clamped to ±0.16) if you want to drive anything else.

   DETERMINISM: render-only.  Reads mesh.geometry (once), o.body's matrices,
   and its own module state.  Writes mesh.scale and khJiggle.q.  It never
   touches sim, and it uses Math.exp/cos/sin/sqrt freely — which is allowed
   here because nothing it computes feeds back into the core.
   ═══════════════════════════════════════════════════════════════════════════

   THE MODEL — two analytic damped springs, no explicit integration
   ---------------------------------------------------------------
   The suit's air volume has a centre that trails the wearer.  Let e be that
   centre's offset from the body along the vertical.  With the body moving,
   e obeys  e'' + 2ζω e' + ω² e = −(body's vertical acceleration).  Written
   this way the forcing is pure acceleration, so it is applied as a velocity
   IMPULSE each frame: v −= Δ(body velocity).  Between impulses the equation
   is homogeneous and is stepped with its CLOSED-FORM solution

       d  = e^(−ζω·dt),   ωd = ω√(1−ζ²)
       e₁ = d·( e₀·cos(ωd·dt) + ((v₀+ζω e₀)/ωd)·sin(ωd·dt) )
       v₁ = d·( v₀·cos(ωd·dt) − ((ω² e₀+ζω v₀)/ωd)·sin(ωd·dt) )

   — exact for any dt, and unconditionally stable because every term is
   bounded by d ≤ 1.  An explicit-Euler spring at ω=34 rad/s needs
   dt < 2/ω ≈ 0.06 s and detonates at the 0.1 s clamp; this one simply
   lands further along the same analytic curve.

   TWO modes, because one linear oscillator rings at ONE frequency no matter
   how hard you hit it — and the brief calls for a landing that wobbles
   BIGGER and SLOWER than a footstep, which a single mode cannot give:
     · BULK   1.35 Hz, ζ=0.18 — the whole air mass sloshing.  Fed mostly by
       the landing.  ~3 visible swings, gone in ~1.9 s.
     · RIPPLE 5.40 Hz, ζ=0.32 — the surface slap.  Fed mostly by footfalls.
       Gone in ~0.35 s, so consecutive steps read as separate slaps instead
       of one locked-in sine.  Both are deliberately detuned from the footfall
       rate, which is 2.15/s at the base timeScale and 3.3/s at top speed —
       the bulk mode sits below it, the ripple well above it, so neither can
       phase-lock back into the thing we just removed.

   MEASURED, not guessed (RUNNER_GLB "Running", timeScale 1.03 → 0.930 s per
   cycle, sampled at 1/120 s inside the live page — see the numbers below):
     · the Body bone rises and falls 0.276 m peak-to-peak, |v|max 3.5 m/s;
     · its two minima — the footfalls — are at phase 0.343 and 0.827, NOT at
       0.0 and 0.5.  The old sine peaked at 0.0/0.5, i.e. it squashed the suit
       when the pelvis was at its HIGHEST.  KHJ.foot carries the real values.
     · Σ Δv over one cycle = 0 exactly, so the drive injects no net energy and
       cannot drift; standing still ⇒ Δv=0, no footfalls, both modes decay,
       a dead-band snaps them to exactly 0 and the scale is written (1,1,1).

   MEASURED RESPONSE (real drive, forced jump, animation frozen at t=9 s):
     dt        run |q|   land |q|   ratio   settle to exact neutral
     1/60      0.0442    0.1222     2.8x    2.37 s
     1/30      0.0408    0.0952     2.3x    2.37 s
     1/15      0.0388    0.0988     2.5x    2.40 s
     0.10      0.0431    0.0830     1.9x    2.00 s
   (For comparison the sine it replaces was a flat ±0.050 at every rate.)
   An explicit-Euler spring at the ripple frequency reaches Inf within 300
   steps at dt=0.10; this one decays monotonically at every dt tested,
   including 40 s of randomly jittered 8–100 ms frames.
   ═══════════════════════════════════════════════════════════════════════════ */

/* الثوابت — ترددٌ بالهرتز، ونسبةُ تخميد، وقوةُ كلِّ حدثٍ مُعبَّرٌ عنها مباشرةً
   بذروةِ الانضغاطِ التي يُحدثها (فالحالةُ محفوظةٌ بوحداتِ الانضغاطِ نفسِها). */
var KHJ = {
  bF:1.35, bZ:0.18,        /* النمطُ الكتليُّ: بطيءٌ كبير  */
  rF:5.40, rZ:0.32,        /* نمطُ التموُّج: سريعٌ صغير    */
  /* طورُ وقعِ القدمِ في لقطةِ الركضِ — مقيسٌ من أدنى نقطتَي عظمِ Body في
     الدورةِ (٠٫٣٤٣ و٠٫٨٢٧) لا مظنونٌ عند الصفرِ والنصف. */
  foot:[0.343, 0.827],
  step:{b:0.0130, r:0.0358},/* وقعُ القدم  → ذروةُ انضغاط  */
  land:{b:0.1050, r:0.0220},/* الهبوطُ من القفزة           */
  lift:{b:-0.0340,r:-0.0120},/* الإقلاعُ: شدٌّ لا انضغاط    */
  drv :{b:0.0195, r:0.0081},/* من كلِّ متر/ثانيةٍ من تغيُّرِ سرعةِ الجسد */
  vMax:12.0,               /* حِرزٌ ضدَّ نقلةِ الولادةِ المفاجئة (م/ث) */
  qMax:0.16,               /* أقصى انضغاطٍ مسموح           */
  eps :8.0e-4              /* عتبةُ السكونِ التامّ           */
};

var khJigS = { b0:0, b1:0, r0:0, r1:0, by:0, bv:0, have:0, ph:-1, air:0, top:0 };

/* خطوةٌ تحليليّةٌ مضبوطةٌ لنابضٍ مخمَّدٍ حرّ — حلٌّ مغلقٌ لا تكاملٌ صريح،
   فلا ينفجر مهما كبرت الخطوة. تُعيد [x,v] في مصفوفةٍ مُعادِ استعمالُها. */
var khJigTmp = [0,0];
function khSpring(x, v, f, z, dt){
  if(!(dt>0)){ khJigTmp[0]=x; khJigTmp[1]=v; return khJigTmp; }
  var w  = 6.283185307*f;
  var wd = w*Math.sqrt(1-z*z);
  var d  = Math.exp(-z*w*dt);
  var c  = Math.cos(wd*dt), s = Math.sin(wd*dt);
  khJigTmp[0] = d*( x*c + ((v + z*w*x)/wd)*s );
  khJigTmp[1] = d*( v*c - ((w*w*x + z*w*v)/wd)*s );
  return khJigTmp;
}

function khJiggle(mesh, dt, o){
  if(!mesh) return 0;
  o = o || {};
  var S = khJigS, K = KHJ;

  if(o.reset){ S.b0=S.b1=S.r0=S.r1=0; S.have=0; S.ph=-1; S.air=0; }
  if(!(dt>0)) dt=0; else if(dt>0.1) dt=0.1;

  /* ── ١ · القيادة: تغيُّرُ السرعةِ الرأسيّةِ لعظمِ Body كما تنتجه اللقطةُ فعلًا.
     فرقٌ أوّلٌ واحدٌ فقط (لا ثانٍ) — فالحدُّ القاسرُ عجلةٌ، وهي تُطبَّق دفعةً
     على السرعةِ النسبيّة. ومجموعُ الدفعاتِ على دورةٍ كاملةٍ صفرٌ، فلا تراكم. */
  var bd = o.body, dv = 0;
  if(bd && dt>0){
    bd.updateWorldMatrix(true,false);          /* يُحدِّث الآباءَ ومنهم الجذر */
    var y = bd.matrixWorld.elements[13];
    if(o.root) y -= o.root.matrixWorld.elements[13];
    if(S.have){
      var vy = (y - S.by)/dt;
      if(vy >  K.vMax) vy =  K.vMax; else if(vy < -K.vMax) vy = -K.vMax;
      dv = vy - S.bv;
      S.bv = vy;
    } else { S.have = 1; S.bv = 0; }
    S.by = y;
  }

  /* ── ٢ · وقعُ القدم: حدثٌ يُستنبَط من عبورِ الطورِ لا من موجةٍ مرسومة.
     ضربتان في الدورة عند الطورَين المقيسَين في KHJ.foot. والعدُّ بعبورِ
     العتبةِ لا بالقُربِ منها، فيصحُّ عند عشرِ لقطاتٍ في الثانيةِ حيث يقفز
     الطورُ نصفَ دورةٍ في إطارٍ واحدٍ فلا يُرى الطورُ عند العتبةِ قطّ. */
  var run = (o.run===undefined ? 1 : o.run);
  var ph  = (o.phase===undefined ? -1 : o.phase);
  var ft  = o.foot || K.foot;
  var hits = 0;
  if(ph>=0 && run>0.02){
    if(S.ph>=0){
      var d = ph - S.ph; if(d<0) d += 1; if(d>0.75) d = 0.75;
      for(var fi=0; fi<ft.length; fi++){
        var u = (S.ph - ft[fi]) % 1; if(u<0) u += 1;
        if(u + d >= 1) hits++;
      }
    }
    S.ph = ph;
  } else S.ph = -1;

  /* ── ٣ · الإقلاعُ والهبوط: حافّتا نافذةِ الطيران. لا يحتاج النّادي علَمًا. */
  var airT = (o.airT===undefined ? 0.12 : o.airT);
  var air  = o.air || 0;
  var land = (S.air > airT && air <= airT) ? 1 : 0;
  var off  = (S.air <= airT && air >  airT) ? 1 : 0;
  S.air = air;

  /* ── ٤ · الدفعات. v₀ = ذروةٌ مطلوبةٌ × ω  (لأنّ ذروةَ نابضٍ خفيفِ التخميدِ
     بعد دفعةٍ تساوي v₀/ω تقريبًا). الإشارة: الجسدُ يُعجَّل صُعُدًا ⇒ البِذلةُ
     تتخلّف ⇒ الانضغاطُ موجب. */
  var wB = 6.283185307*K.bF, wR = 6.283185307*K.rF;
  var jb = 0, jr = 0;
  if(hits){ jb += hits*K.step.b*run*wB; jr += hits*K.step.r*run*wR; }
  if(land){ jb += K.land.b*wB;          jr += K.land.r*wR; }
  if(off ){ jb += K.lift.b*wB;          jr += K.lift.r*wR; }
  if(dv)  { jb += dv*K.drv.b*wB;        jr += dv*K.drv.r*wR; }
  S.b1 += jb; S.r1 += jr;

  /* ── ٥ · خطوتان تحليليّتان. */
  var t = khSpring(S.b0, S.b1, K.bF, K.bZ, dt); S.b0=t[0]; S.b1=t[1];
  t     = khSpring(S.r0, S.r1, K.rF, K.rZ, dt); S.r0=t[0]; S.r1=t[1];

  /* شبكةُ أمانٍ: لو تسلّلت NaN من مصدرِ القيادةِ، عُد إلى الحياد بدلَ التجمُّد. */
  if(!(S.b0===S.b0 && S.b1===S.b1 && S.r0===S.r0 && S.r1===S.r1)){
    S.b0=S.b1=S.r0=S.r1=0; S.have=0;
  }
  /* السكونُ التامّ: تحت العتبةِ تُصفَّر الحالةُ تصفيرًا حقيقيًّا فلا يبقى زحفٌ
     أُسّيٌّ إلى الأبد ولا مقياسٌ يخالف الواحدَ في المنزلةِ العاشرة. */
  if(Math.abs(S.b0)<K.eps && Math.abs(S.r0)<K.eps &&
     Math.abs(S.b1)<K.eps*wB && Math.abs(S.r1)<K.eps*wR){
    S.b0=S.b1=S.r0=S.r1=0;
  }

  /* ── ٦ · التطبيق: انضغاطٌ رأسيٌّ يقابله انتفاخٌ أفقيٌّ يحفظ الحجمَ بالضبط
     (س×س×ع = ١ ⇒ س = ١/√ع)، لا تقريبًا خطّيًّا. الكتابةُ مطلقةٌ دائمًا. */
  var q = S.b0 + S.r0;
  if(q >  K.qMax) q =  K.qMax; else if(q < -K.qMax) q = -K.qMax;
  khJiggle.q = q;
  if(q === 0){ mesh.scale.set(1,1,1); return 0; }
  var sz = 1 - q, sxy = 1/Math.sqrt(sz);
  mesh.scale.set(sxy, sxy, sz);           /* إطارُ الجذعِ المحلّيّ: Z هو الارتفاع */

  /* ── ٧ · القيمةُ المُعادة: كم نزل أعلى الجذع، بوحداتِ الهيكلِ المحلّيّة. */
  if(!S.top){
    var g = mesh.geometry;
    if(g){ if(!g.boundingBox) g.computeBoundingBox();
           S.top = (g.boundingBox && g.boundingBox.max.z) || 0; }
  }
  return q*S.top;
}
khJiggle.q = 0;


/* منحنى الالتفاتة: صعودٌ ليّنٌ ثمّ ثباتٌ يكفي للنظرِ ثمّ عودةٌ أبطأ.
   الذروةُ نحوُ مئةِ درجةٍ — التفاتُ كتفٍ بشريّ، لا دورانُ بومة. */
function khLook(u){
  if(u<0.45){ var a=u/0.45;            return a*a*(3-2*a); }
  if(u<0.95)                            return 1;
  if(u<1.70){ var c=1-(u-0.95)/0.75;   return c*c*(3-2*c); }
  return 0;
}

/* ═══════════════════════════════════════════════════════════════════════════
   خُضَيران: السطحُ الواحدُ المتّصل (بديلُ مسارِ الكُتَل)
   ───────────────────────────────────────────────────────────────────────────
   الشكلُ يُولَّدُ وقتَ البناءِ في khbake.mjs من دالّةِ مسافةٍ مُشارَةٍ باتّحادٍ
   ناعم، ويُستخرَجُ بمسيرِ المكعّبات، وتُحسَبُ أعرافُه من تدرّجِ الدالّةِ لا من
   المثلّثات، وتُكسى رؤوسُه على العظامِ نفسِها. وهنا لا يبقى إلّا فكُّ الترميزِ
   والربط — لا حسابَ وقتَ التحميلِ ألبتّة.

   ولماذا سطحٌ واحد: سطحانِ محدَّبانِ متقاطعانِ يُنتجانِ حرفًا بحكمِ التعريفِ لا
   بسوءِ ضبط؛ والاتّحادُ الناعمُ يُذيبُ الملتقى رياضيًّا، وهو عينُه ما يُنتجُ
   مظهرَ البِذلةِ المنفوخة.

   قرارُ محمّدٍ بعدَ المعاينة: مسارُ الكُتَلِ هو الافتراضيُّ المعتمَد.
   والسطحُ الواحدُ باقٍ خلفَ رايةِ ‎?rig=skin‎ للمقارنةِ لا غير.
   ═══════════════════════════════════════════════════════════════════════════ */
function khSkinOn(){
  try{ return /[?&]rig=skin(&|$)/.test(location.search); }catch(e){ return false; }
}
var KH_SKIN_G=null;
function khSkinGeo(){
  if(KH_SKIN_G) return KH_SKIN_G;
  var D=KH_SKIN, bin=atob(D.d), n=bin.length, u=new Uint8Array(n);
  for(var i=0;i<n;i++) u[i]=bin.charCodeAt(i);
  var b=u.buffer, o=0, N=D.n, T3=D.t*3;
  var pos=new Float32Array(b,o,N*3); o+=N*12;
  var nor=new Float32Array(b,o,N*3); o+=N*12;
  var kax=new Float32Array(b,o,N);   o+=N*4;
  var krd=new Float32Array(b,o,N*2); o+=N*8;
  var kid=new Float32Array(b,o,N);   o+=N*4;
  var si =new Uint8Array  (b,o,N*4); o+=N*4;
  var sw =new Float32Array(b,o,N*4); o+=N*16;
  var ix =new Uint16Array (b,o,T3);
  var g=new T.BufferGeometry();
  g.setAttribute("position",   new T.BufferAttribute(pos,3));
  g.setAttribute("normal",     new T.BufferAttribute(nor,3));
  g.setAttribute("khAx",       new T.BufferAttribute(kax,1));
  g.setAttribute("khRd",       new T.BufferAttribute(krd,2));
  g.setAttribute("khId",       new T.BufferAttribute(kid,1));
  g.setAttribute("skinIndex",  new T.BufferAttribute(si,4));
  g.setAttribute("skinWeight", new T.BufferAttribute(sw,4));
  g.setIndex(new T.BufferAttribute(ix,1));
  g.computeBoundingSphere();
  return (KH_SKIN_G=g);
}
/* ── ترقيعُ المُظلِّل: المستقيمُ العموديُّ في khmat.js يُقرأُ من وضعيّةِ الراحةِ
   (vKhN قبلَ الكساء) وهو الصوابُ للنسيج، لكنّ الإضاءةَ تحتاجُ المستقيمَ بعدَ
   الكساء. فنمرِّرُ مصفوفةَ الكساءِ الثلاثيّةَ متغيّرًا ونضربُ بها بعدَ إضافةِ
   النتوء. وفي مسارِ الكُتَلِ تبقى المصفوفةُ الوحدةَ فلا يتغيّرُ شيء.
   (لا يُمَسُّ khmat.js — يُلَفُّ onBeforeCompile لفًّا.)                    */
function khSkinMat(m){
  if(!m || m.__khSkin) return m;
  m.__khSkin=1;
  var base=m.onBeforeCompile, ck=m.customProgramCacheKey;
  var DEC="varying vec3 vKhS0; varying vec3 vKhS1; varying vec3 vKhS2;";
  m.onBeforeCompile=function(sh,rnd){
    if(base) base.call(this,sh,rnd);
    sh.vertexShader=sh.vertexShader
      .replace("#include <common>", "#include <common>\n"+DEC)
      .replace("#include <beginnormal_vertex>",
        "#include <beginnormal_vertex>\n\tvKhS0=vec3(1.0,0.0,0.0); vKhS1=vec3(0.0,1.0,0.0); vKhS2=vec3(0.0,0.0,1.0);")
      .replace("#include <skinnormal_vertex>",
        "#include <skinnormal_vertex>\n#ifdef USE_SKINNING\n\tvKhS0=skinMatrix[0].xyz; vKhS1=skinMatrix[1].xyz; vKhS2=skinMatrix[2].xyz;\n#endif");
    sh.fragmentShader=sh.fragmentShader
      .replace("#include <common>", "#include <common>\n"+DEC)
      .replace("normal = normalize(normalMatrix * normalize(No - khBmp*gr));",
               "normal = normalize(normalMatrix * (mat3(vKhS0,vKhS1,vKhS2) * normalize(No - khBmp*gr)));");
  };
  m.customProgramCacheKey=function(){ return (ck?ck.call(this):"")+"|khSkin"; };
  m.needsUpdate=true;
  return m;
}
function khSkinBuild(root,mats,K){
  root.updateMatrixWorld(true);
  var byName={}; root.traverse(function(o){ byName[o.name]=o; });
  root.traverse(function(o){ if(o.isMesh) o.visible=false; });
  /* ── عظما الإبطِ المساعدان ───────────────────────────────────────────────
     يُزرَعانِ عندَ مفصلِ الكتفِ بإطارِ العَضُدِ نفسِه في وضعيّةِ الراحة، فمعكوسُ
     كلٍّ منهما عندَ الربطِ هو معكوسُ العَضُد. ثمّ يُدارانِ كلَّ إطارٍ نصفَ
     دورانِ العَضُدِ (khSkinFrame)، فيحملانِ ما كان متقاسَمًا بين الكُمِّ والجذعِ
     على إطارٍ واحدٍ لا على متوسّطِ إطارين — وذاك المتوسّطُ هو الذي كان يَسحَقُ
     الكُمَّ نصلًا رفيعًا في أطوارِ الأرجحة. */
  var half=[];
  [["KHHalfL","UpperArmL","ShoulderL"],["KHHalfR","UpperArmR","ShoulderR"],
   ["KHHipL","UpperLegL","Body"],      ["KHHipR","UpperLegR","Body"]].forEach(function(t){
    var ua=byName[t[1]], par=byName[t[2]];
    if(!ua||!par) return;
    var hb=new T.Bone(); hb.name=t[0];
    hb.position.copy(ua.position); hb.quaternion.copy(ua.quaternion); hb.scale.copy(ua.scale);
    par.add(hb); byName[hb.name]=hb;
    half.push({b:hb, a:ua, r:ua.quaternion.clone(), p:ua.position.clone()});
  });
  root.updateMatrixWorld(true);
  var bones=[], i;
  for(i=0;i<KH_SKIN.b.length;i++){
    var bn=byName[KH_SKIN.b[i]];
    if(!bn) throw new Error("khSkin: missing bone "+KH_SKIN.b[i]);
    bones.push(bn);
  }
  /* تردُّدُ النسيجِ: vKhP في مسارِ الكُتَلِ محلّيُّ العُقدةِ (سُلَّمُ العظمِ ١٠٠)،
     وهنا في فضاءِ الجذرِ — فيُقسَمُ التردُّدُ على ١٠٠ ليبقى حجمُ البلاطةِ كما هو. */
  var mat=khSkinMat(mats.suit);
  if(mat.userData && mat.userData.khU) mat.userData.khU.khFrq.value=0.46;
  var m=new T.SkinnedMesh(khSkinGeo(), mat);
  m.name="KH_Skin"; m.castShadow=true; m.frustumCulled=false;
  /* مِرساةُ التطبيع: Rig.mount يُعاير القامةَ على صندوقِ كلِّ ما تحتَ الجذر،
     وفيه شبكاتٌ مخفيّةٌ من النموذجِ الأصليِّ صندوقُها يختلفُ بين المسارين،
     فتختلفُ القامةُ على الشاشةِ ٧٪ بلا سبب. نُثبّتُ الصندوقَ صراحةً على
     صندوقِ مسارِ الكُتَلِ المقيسِ فتتطابقُ المعايرةُ تطابقًا تامًّا.
     (الشبكةُ خارجَ الانتقاءِ المخروطيِّ أصلًا: frustumCulled=false) */
  if(KH_SKIN.fit){ var F=KH_SKIN.fit;
    m.geometry.boundingBox=new T.Box3(new T.Vector3(F[0],F[1],F[2]),new T.Vector3(F[3],F[4],F[5])); }
  root.add(m); root.updateMatrixWorld(true);
  m.bind(new T.Skeleton(bones));          /* المعكوساتُ من وضعيّةِ الراحةِ الحاليّة */
  var made={__root:root, __skin:m, __half:half, Torso:new T.Object3D()};
  if(K.face) K.face(byName,mats,made);
  return made;
}
/* ── الاهتزاز: في مسارِ الكُتَلِ يُضغَطُ جسمُ الجذعِ نفسُه؛ وهنا يُضغَطُ عظمُ
   البطنِ ويُعوَّضُ الصدرُ بعكسِه، فينزلُ الصدرُ والرأسُ مع الانضغاطِ ولا
   يتضخّمانِ معه. كتابةٌ مطلقةٌ كلَّ إطارٍ فلا تراكم.                        */
function khSkinFrame(rig,q){
  /* ١ · عظما الإبط: نصفُ دورانِ العَضُدِ — كتابةٌ مطلقةٌ فلا تراكم */
  var H=rig.parts&&rig.parts.__half;
  if(H) for(var k=0;k<H.length;k++){
    H[k].b.position.copy(H[k].p);
    H[k].b.quaternion.copy(H[k].r).slerp(H[k].a.quaternion, 0.5);
  }
  khSkinSquash(rig,q);
}
function khSkinSquash(rig,q){
  if(!rig||!rig.bones) return;
  var a=rig.bones.Abdomen||rig.g&&null, c=rig.bones.Torso_1;
  if(!a){ var r=rig.g; if(r) r.traverse(function(o){ if(o.isBone&&o.name==="Abdomen") a=o; }); rig.bones.Abdomen=a; }
  if(!a||!c) return;
  if(!(q>-1)) q=0;
  var sz=1-q; if(sz<0.5) sz=0.5;
  var sxy=1/Math.sqrt(sz);
  a.scale.set(sxy,sz,sxy);
  c.scale.set(1/sxy,1/sz,1/sxy);
}
