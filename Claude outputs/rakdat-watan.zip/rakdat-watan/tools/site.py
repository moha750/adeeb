# يبني نسخةَ موقع أدِيب من اللعبة، ولبَّها للخادم، **معًا** لأنّ بصمتَهما واحدة.
#   python3 tools/site.py <مسار v2/apps/web في مستودع أدِيب>
# يكتب:
#   public/watan/game.html   اللعبةُ بلا منفذ الفحص (window.RW)، تُلعَب على /watan/play
#   src/lib/watan/core.js    لبُّ اللعبة حرفًا بحرف، يعيد به الخادمُ كلَّ جولة
# ثمّ شغّل pnpm test هناك: إن تغيّر اللعبُ نفسُه سقطت الجولاتُ المحفوظة ووجب توليدُها.
import hashlib, os, subprocess, sys, tempfile
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if len(sys.argv) != 2: print(__doc__ or "python3 tools/site.py <v2/apps/web>"); sys.exit(2)
web = os.path.abspath(sys.argv[1])
game = os.path.join(web, "public", "watan", "game.html")
core = os.path.join(web, "src", "lib", "watan", "core.js")
os.makedirs(os.path.dirname(game), exist_ok=True)
tmp = tempfile.mktemp(suffix=".js")
subprocess.run([sys.executable, os.path.join(R, "src", "build.py")], check=True,
               env={**os.environ, "SITE": "1", "OUT": game, "CORE_OUT": tmp})
body = open(tmp, encoding="utf-8").read(); os.remove(tmp)
ver = hashlib.sha256(body.encode("utf-8")).hexdigest()[:12]
HEAD = '/* eslint-disable */\n// @ts-nocheck\n/**\n * **لبُّ «ركضة وطن» — مولَّدٌ من اللعبة نفسِها، فلا يُحرَّر هنا بيد.**\n *\n * هذا هو القلبُ الحتميُّ للّعبة كما يجري في جوّال اللاعب حرفًا بحرف: البذرةُ\n * والعوائقُ والحروفُ والمصّاصُ والخصائصُ والتصادم. والخادمُ يُعيد به الجولةَ من\n * بذرتها وضغطاتها وحدَها، فالنتيجةُ ما يحسبه هو لا ما يقوله الجهاز.\n *\n * **ولا شيءَ فيه غيرُ + − × ÷ و`Math.floor` والمقارنات** (قاعدةٌ في اللعبة من يومها\n * الأوّل): هذه وحدَها مضمونةُ النتيجة بالبِت في كلّ محرّك JavaScript، في سفاري\n * الآيفون وفي كروم وفي Node على الخادم. ودوالُّ مثل `sin` و`sqrt` و`pow` تختلف\n * خانتُها الأخيرة بين المحرّكات، فتفترق الجولتان بعد دقيقة.\n *\n * **النسخة `{VER}`** بصمةُ هذا النصّ (sha256، أوّلُ ١٢ خانة). واللعبةُ ترسل بصمتَها\n * مع كلّ جولة، فإن اختلفتا رُدّت الجولةُ بطلب تحديث الصفحة: لبّان مختلفان يعطيان\n * لنفس الضغطات مسافتين مختلفتين، والخادمُ لا يحكم بلبٍّ غيرِ الذي لُعب به.\n *\n * والتوليدُ: `python3 tools/site.py <v2/apps/web>` في حزمة اللعبة، يبني معه `public/watan/game.html`\n * بالبصمة نفسِها. ويُقتطع اللبُّ من قالب اللعبة (`g3.html`) من `var STEP=1/60` إلى نهاية\n * `Sim.prototype.score`، ولا يُمَسّ منه حرف.\n */\n'
TAIL = '\nexport const CORE_VERSION = "{VER}";\nexport { STEP, SLOT, Sim, PW_T, WORDS };\n'
open(core, "w", encoding="utf-8").write(HEAD.replace("{VER}", ver) + body + TAIL.replace("{VER}", ver))
print("core", ver, "→", core)
