import { chromium } from 'playwright';
const b=await chromium.launch({...(process.env.CHROMIUM?{executablePath:process.env.CHROMIUM}:{}),
  args:['--use-gl=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage({viewport:{width:440,height:900},deviceScaleFactor:2});
const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
await p.goto(process.env.GAME_URL||'http://127.0.0.1:8098/index.html');
await p.evaluate(()=>document.fonts.ready);
await p.waitForTimeout(1500);
const det = await p.evaluate(()=>{
  const {Sim}=window.RW;
  const script=[[40,3],[95,2],[160,4],[230,1],[300,3],[380,2],[460,4],[560,3]];
  function run(seed){ const s=new Sim(seed); let j=0;
    for(let i=0;i<1500;i++){ while(j<script.length&&script[j][0]===i){s.input(script[j][1]);j++;} s.tick(); }
    return {score:s.score(),dist:+s.s.dist.toFixed(6),log:s.log.slice()}; }
  const a=run(123456), b=run(123456);
  const s1=new Sim(123456); let j=0;
  for(let i=0;i<1500;i++){ while(j<script.length&&script[j][0]===i){s1.input(script[j][1]);j++;} s1.tick(); }
  const r=new Sim(123456); let m=0; const lg=s1.log;
  for(let i=0;i<1500;i++){ while(m<lg.length&&lg[m][0]===i){r.input(lg[m][1]);m++;} r.tick(); }
  return {same:a.score===b.score&&a.dist===b.dist, replay:r.score()===s1.score(), score:a.score};
});
console.log('determinism:',JSON.stringify(det));
await (await p.$('.frame')).screenshot({path:'t3a.png'});
await p.click('#go'); await p.waitForTimeout(3000);
await (await p.$('.frame')).screenshot({path:'t3b.png'});
console.log('fps:', await p.$eval('#fps',e=>e.textContent));
console.log('errors:', errs.length?errs.slice(0,6).join(' | '):'none');
await b.close();
