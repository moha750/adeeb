/* حتميّةٌ وإعادةُ تشغيلٍ تحتَ ضغطٍ كثيفٍ يُشغِّلُ المخزونَ فعلًا */
const P=process.argv[2]; const M=await import(P);
const {Sim,SLOT}=M;
function mk(x0){ let x=x0>>>0||1;
  return ()=>{ x^=x<<13;x>>>=0; x^=x>>>17; x^=x<<5;x>>>=0; return x/4294967296; }; }
let bad=0, buffered=0, fired=0, cases=0, scoreSum=0, candySum=0, pwSum=0, brkSum=0;
for(let c=0;c<400;c++){
  const rng=mk(0xC0FFEE+c), seed=(c*2654435761)>>>0;
  const script=[]; let t=0;
  while(t<1200){ t+=1+Math.floor(rng()*14); script.push([t,1+Math.floor(rng()*4)]); }
  function run(){ const s=new Sim(seed); let j=0; let b=0,f=0;
    for(let i=0;i<1400;i++){
      while(j<script.length&&script[j][0]===i){ const pre=s.s.bufA; s.input(script[j][1]);
        if(!pre&&s.s.bufA) b++; j++; }
      const a0=s.s.air,l0=s.s.slide,ba=s.s.bufA; s.tick();
      if(ba&&!s.s.bufA&&(s.s.air>a0+1e-9||s.s.slide>l0+1e-9)) f++;
      if(!s.s.alive) s.s.alive=true;              /* بعثٌ حتّى يطولَ الاختبار */
    }
    return {sc:s.score(), c:s.candies(), pw:s.s.pwN, brk:s.s.brkAt, d:+s.s.dist.toFixed(9), log:s.log.slice(), b, f}; }
  const A=run(), B=run();
  /* الإعادةُ من السجلِّ وحدَه — كما يفعلُ الخادم */
  const r=new Sim(seed); let m=0;
  for(let i=0;i<1400;i++){ while(m<A.log.length&&A.log[m][0]===i){ r.input(A.log[m][1]); m++; }
    r.tick(); if(!r.s.alive) r.s.alive=true; }
  if(A.sc!==B.sc||A.d!==B.d||A.c!==B.c||A.pw!==B.pw) bad++;
  /* الخادمُ يعيدُ المسافةَ والمصّاصَ والخصائصَ كلَّها من السجلِّ وحدَه */
  if(r.score()!==A.sc||+r.s.dist.toFixed(9)!==A.d||r.candies()!==A.c||r.s.pwN!==A.pw||r.s.brkAt!==A.brk) bad++;
  buffered+=A.b; fired+=A.f; cases++; scoreSum+=A.sc; candySum+=A.c; pwSum+=A.pw; brkSum+=(A.brk>=0?1:0);
}
/* الخصائصُ الأطولُ كلماتٍ نادرًا ما تكتملُ بضغطٍ عشوائيّ، فتُحقَنُ في أوّلِ الجولةِ حقنًا متطابقًا في
   التشغيلين وفي الإعادة: تحليقٌ وتمهّلٌ (سرعةٌ تدخلُ وتخرج) ومغناطيسٌ ودرع، كلٌّ في ٥٠ جولة */
let pwBad=0, pwDist=0, pwCandy=0; const KEYS=['pwS','pwF','pwM','pwW'];
for(let c=0;c<200;c++){
  const rng=mk(0xFEED+c), seed=(c*2246822519+11)>>>0, key=KEYS[c%4], T0=M.PW_T[c%4];
  const script=[]; let t=0;
  while(t<1100){ t+=3+Math.floor(rng()*20); script.push([t,1+Math.floor(rng()*4)]); }
  function run2(log){ const s=new Sim(seed); s.s[key]=T0; let j=0; const src=log||script;
    for(let i=0;i<1200;i++){ while(j<src.length&&src[j][0]===i){ s.input(src[j][1]); j++; } s.tick(); if(!s.s.alive) s.s.alive=true; }
    return s; }
  const A=run2(), B=run2(), R=run2(A.log);
  const f=x=>[x.score(),x.candies(),x.s.picked,x.s.pwN,x.s.brkAt,+x.s.dist.toFixed(9)].join(',');
  if(f(A)!==f(B) || f(R)!==f(A)) pwBad++;
  pwDist+=A.score(); pwCandy+=A.candies();
}
console.log(JSON.stringify({cases,mismatches:bad,pressesBuffered:buffered,bufferedThenFired:fired,checksum:scoreSum,candies:candySum,powerups:pwSum,shieldRuns:brkSum,
  pwCases:200,pwMismatches:pwBad,pwChecksum:pwDist,pwCandies:pwCandy}));
