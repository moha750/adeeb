# يدمجُ قالبَ اللعبةِ مع أصولِها ويُخرِجُ ملفًّا واحدًا قائمًا بذاته.
#   cd src && python3 build.py            ← يكتبُ ../index.html
# يحتاجُ three@0.149.0 في node_modules (npm install في جذرِ المستودع).
import json, os, re, sys
S = os.path.dirname(os.path.abspath(__file__))
R = os.path.dirname(S)                       # جذرُ المستودع
W = os.path.join(R, "data")
src = open(os.environ.get("G3", os.path.join(S, "g3.html")), encoding="utf-8").read()

def rd(p):
    return open(p, encoding="utf-8").read()

three = os.path.join(R, "node_modules", "three", "build", "three.min.js")
if not os.path.exists(three):
    print("!! three.min.js غيرُ موجود — شغّل npm install في جذرِ المستودع"); sys.exit(1)
sub = {
    "/*__FACE__*/": rd(f"{S}/face.css"),
    "__ASSETS__":   rd(f"{S}/assets.json"),
    "__FLAG__":     rd(f"{S}/flagdata.txt").strip(),
    "__SKY__":      rd(f"{W}/sky.json"),
    "__TEX__":      rd(f"{W}/tex/tex.json"),
    "__PROPS__":    rd(f"{W}/props.json"),
    "__MODELS__":   rd(f"{W}/models.json"),
    "/*__SND__*/":  rd(f"{S}/snd.js"),
    "/*__CARS3D__*/": rd(f"{S}/cars3d.js"),
    "/*__SKY3D__*/":  rd(f"{S}/sky3d.js"),
    "/*__KH__*/":   rd(f"{S}/khmat.js") + "\n" + rd(f"{S}/khskin.js") + "\n" + rd(f"{S}/kh.js"),
    "__RUNNERGLB__": rd(f"{S}/runner_glb.txt").strip(),
    "<!--__GLTF__-->": "<script>" + rd(f"{S}/gltfloader.js")
                        .replace("</"+"script>", "<\\/"+"script>") + "</" + "script>",
    "<!--__THREE__-->": "<script>" + rd(three)
                        .replace("</"+"script>", "<\\/"+"script>") + "</" + "script>",
}
for k, v in sub.items():
    if k not in src: print("!! missing placeholder", k); sys.exit(1)
    src = src.replace(k, v)
assert "__" not in re.sub(r'[A-Za-z0-9+/]{40,}', '', src[:2000]), "placeholder left"
out = os.environ.get("OUT", os.path.join(R, "index.html"))
open(out, "w", encoding="utf-8").write(src)
print("wrote", out, f"{os.path.getsize(out)/1024/1024:.2f} MB")
