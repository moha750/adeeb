/* ══ صوتُ «ركضة وطن» ═════════════════════════════════════════════════════
   كلُّ صوتٍ يُركَّبُ في المتصفِّحِ تركيبًا (Web Audio) ولا يُجلَبُ ملفًّا:
   فلا وزنَ يُضافُ إلى الصفحة، ولا طلبَ شبكةٍ تمنعُه سياسةُ الأمانِ الصارمة.

   والسياقُ لا يُفتَحُ إلّا بلمسةِ المستخدمِ (زرُّ «ابدأ») لأنّ الجوّالَ يمنعُ
   غيرَ ذلك. وكلُّ نداءٍ قبلَها يسقطُ صامتًا بلا خطأ.

   ولا شيءَ ممّا هنا يمسُّ اللبَّ الحتميّ: الصوتُ يُقرَأُ من فروقِ الحالةِ في
   حلقةِ الرسمِ ولا يُستدعى من داخلِ المحاكاة. */
var SND=(function(){
  var ctx=null, mst=null, noise=null, on=true, ready=false;

  try{ var v=localStorage.getItem("rw_snd"); if(v==="0") on=false; }catch(e){}

  function mkNoise(){
    var n=Math.floor(ctx.sampleRate*0.5), b=ctx.createBuffer(1,n,ctx.sampleRate), d=b.getChannelData(0);
    /* ضوضاءٌ ورديّةٌ تقريبًا: أليَنُ من البيضاءِ وأشبهُ بالاحتكاكِ الحقيقيّ */
    var b0=0,b1=0,b2=0;
    for(var i=0;i<n;i++){
      var w=Math.random()*2-1;
      b0=0.99765*b0+w*0.0990460; b1=0.96300*b1+w*0.2965164; b2=0.57000*b2+w*1.0526913;
      d[i]=(b0+b1+b2+w*0.1848)*0.28;
    }
    return b;
  }

  function init(){
    if(ready) return true;
    var AC=window.AudioContext||window.webkitAudioContext;
    if(!AC) return false;
    try{
      ctx=new AC();
      mst=ctx.createGain(); mst.gain.value=on?0.55:0; mst.connect(ctx.destination);
      noise=mkNoise(); ready=true;
    }catch(e){ return false; }
    return true;
  }
  function wake(){ if(ctx&&ctx.state==="suspended") ctx.resume(); }

  function env(g,t,a,d,peak){
    g.gain.setValueAtTime(0.0001,t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002,peak),t+a);
    g.gain.exponentialRampToValueAtTime(0.0001,t+a+d);
  }
  function tone(type,f0,f1,a,d,peak,dest){
    if(!ready) return;
    var t=ctx.currentTime, o=ctx.createOscillator(), g=ctx.createGain();
    o.type=type; o.frequency.setValueAtTime(f0,t);
    if(f1!==f0) o.frequency.exponentialRampToValueAtTime(Math.max(1,f1),t+a+d);
    env(g,t,a,d,peak); o.connect(g); g.connect(dest||mst);
    o.start(t); o.stop(t+a+d+0.02);
  }
  function puff(dur,peak,type,f0,f1,q){
    if(!ready) return;
    var t=ctx.currentTime, s=ctx.createBufferSource(), f=ctx.createBiquadFilter(), g=ctx.createGain();
    s.buffer=noise; s.loop=true;
    f.type=type||"lowpass"; f.frequency.setValueAtTime(f0,t);
    if(f1&&f1!==f0) f.frequency.exponentialRampToValueAtTime(Math.max(40,f1),t+dur);
    if(q) f.Q.value=q;
    env(g,t,0.008,dur,peak);
    s.connect(f); f.connect(g); g.connect(mst);
    s.start(t); s.stop(t+dur+0.03);
  }

  var lastStep=0;
  return {
    init:function(){ var r=init(); wake(); return r; },
    enabled:function(){ return on; },
    toggle:function(){
      on=!on; if(mst) mst.gain.value=on?0.55:0;
      try{ localStorage.setItem("rw_snd",on?"1":"0"); }catch(e){}
      return on;
    },
    /* وقعُ القدم: ثقلٌ منخفضٌ وحفيفٌ قصير. يُخفَّفُ كي لا يُتعِبَ في دورةٍ طويلة */
    step:function(spd){
      if(!ready) return; var t=ctx.currentTime;
      if(t-lastStep<0.09) return; lastStep=t;
      var v=0.10+0.05*Math.min(1,(spd||18)/34);
      tone("sine",88,54,0.006,0.09,v);
      puff(0.055,v*0.55,"lowpass",900,360);
    },
    /* القفزة: اندفاعٌ صاعدٌ ونفخةُ بذلة */
    jump:function(){
      tone("triangle",210,560,0.012,0.15,0.20);
      puff(0.13,0.10,"bandpass",700,1700,3);
    },
    /* الهبوط: ارتطامٌ ثمّ ارتجاجُ البذلةِ المنفوخة */
    land:function(){
      tone("sine",150,52,0.006,0.24,0.26);
      puff(0.10,0.15,"lowpass",1200,260);
      tone("triangle",320,190,0.03,0.20,0.055);
    },
    /* الانزلاق: احتكاكٌ عريضٌ يهبطُ ترددُه */
    slide:function(){ puff(0.42,0.17,"bandpass",1500,320,1.6); },
    /* التقاطُ حرف: نغمةٌ تعلو مع تتابعِ الحروفِ فتُحسُّ تقدّمًا */
    letter:function(i){
      var f=[523.25,659.25,783.99][(i||0)%3];
      tone("triangle",f,f*1.5,0.008,0.17,0.17);
      tone("sine",f*2,f*2,0.006,0.09,0.05);
    },
    /* اكتمالُ كلمة: ثلاثُ نغماتٍ صاعدة */
    word:function(){
      if(!ready) return;
      [0,0.075,0.15].forEach(function(dt,k){
        var f=[783.99,987.77,1174.66][k];
        setTimeout(function(){ tone("triangle",f,f,0.008,0.24,0.19); }, dt*1000);
      });
    },
    /* الاصطدام: ضجّةٌ ثمّ هبوطٌ ثقيل */
    crash:function(){
      tone("sawtooth",190,42,0.01,0.55,0.24);
      puff(0.30,0.24,"lowpass",2600,220);
    },
    /* الإمساك: كفٌّ تقعُ على كتفٍ — ضربةٌ خافتةٌ ونغمةٌ هابطةٌ قصيرة */
    grab:function(){
      puff(0.11,0.13,"lowpass",1400,300);
      tone("triangle",300,150,0.012,0.22,0.11);
    },
    /* تبديلُ المسار: حفيفٌ خفيفٌ جدًّا */
    lane:function(){ puff(0.09,0.055,"bandpass",1100,2100,2.2); }
  };
})();
