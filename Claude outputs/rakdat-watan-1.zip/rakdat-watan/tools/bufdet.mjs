/* حتميّةٌ وإعادةُ تشغيلٍ تحتَ ضغطٍ كثيفٍ يُشغِّلُ المخزونَ فعلًا */
const P=process.argv[2]; const M=await import(P);
const {Sim,SLOT}=M;
function mk(x0){ let x=x0>>>0||1;
  return ()=>{ x^=x<<13;x>>>=0; x^=x>>>17; x^=x<<5;x>>>=0; return x/4294967296; }; }
let bad=0, buffered=0, fired=0, cases=0, scoreSum=0;
for(let c=0;c<400;c++){
  const rng=mk(0xC0FFEE+c), seed=(c*2654435761)>>>0;
  const script=[]; let t=0;
  while(t<1200){ t+=1+Math.floor(rng()*14); script.push([t,1+Math.floor(rng()*4)]); }
  function run(){ const s=new Sim(seed); let j=0; let b=0,f=0;
    for(let i=0;i<1400;i++){
      while(j<script.length&&script[j][0]===i){ const pre=s.s.bufA; s.input(script[j][1]);
        if(!pre&&s.s.bufA) b++; j++; }
      const a0=s.s.air,l0=s.s.slide,ba=s.s.bufA; s.tick();
      if(ba&&!s.s.bufA&&(s.s.air>a0+1e-9||s.s.slide>l0+1e-9)) f++;
      if(!s.s.alive) s.s.alive=true;              /* بعثٌ حتّى يطولَ الاختبار */
    }
    return {sc:s.score(), d:+s.s.dist.toFixed(9), log:s.log.slice(), b, f}; }
  const A=run(), B=run();
  /* الإعادةُ من السجلِّ وحدَه — كما يفعلُ الخادم */
  const r=new Sim(seed); let m=0;
  for(let i=0;i<1400;i++){ while(m<A.log.length&&A.log[m][0]===i){ r.input(A.log[m][1]); m++; }
    r.tick(); if(!r.s.alive) r.s.alive=true; }
  if(A.sc!==B.sc||A.d!==B.d) bad++;
  if(r.score()!==A.sc||+r.s.dist.toFixed(9)!==A.d) bad++;
  buffered+=A.b; fired+=A.f; cases++; scoreSum+=A.sc;
}
console.log(JSON.stringify({cases,mismatches:bad,pressesBuffered:buffered,bufferedThenFired:fired,checksum:scoreSum}));
