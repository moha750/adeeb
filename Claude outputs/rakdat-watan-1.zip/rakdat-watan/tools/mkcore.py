import sys,re,os
D=os.path.dirname(os.path.abspath(__file__))
src=open(os.path.join(D,'..','src','g3.html'),encoding='utf-8').read()
a=src.index('var STEP=1/60')
m='Sim.prototype.score=function(){'
b=src.index(m); b=src.index('};',b)+2
core=src[a:b]
out=sys.argv[1] if len(sys.argv)>1 else f'{D}/core_x.mjs'
for kv in sys.argv[2:]:
    k,v=kv.split('=')
    core=re.sub(r'(var JUMP_D=)[0-9.]+(, SLIDE_D=)[0-9.]+(, BUF_W=)[0-9.]+',
                lambda mm: mm.group(0), core)
    core=re.sub(rf'\b{k}=[0-9.]+', f'{k}={v}', core, count=1)
core+='\nexport {STEP,SLOT,GRACE,LANE_STEPS,JUMP_D,SLIDE_D,BUF_W,Sim,slotOf,rawSlot,spanOf,HITW,GRABW,letterAt,trafficLane};\n'
open(out,'w',encoding='utf-8').write(core)
